# SGIA Connect – Prototype Handover

_Prepared 19 Oct 2026. DEMO prototype; synthetic data only._

## 1. Status at a glance
| Item | State |
|---|---|
| Application code (all 5 milestones' features) | Built; builds cleanly, typechecks, lints |
| Automated tests | 14 unit + 88 end-to-end checks passing (`docs/test-evidence/`) |
| Public HTTPS URL | **Not deployed yet – needs account-owner approval** (see §12) |
| Physical-device tests (iPhone/Android camera, real push) | **Not yet done – requires a deployed HTTPS URL and real phones** (see §10) |

## 2. Deployment architecture
```
Phone / desktop browser (PWA, service worker)
        │ HTTPS
        ▼
Next.js app on Vercel (pages + /api route handlers; all authorisation here)
        │ DATABASE_URL (TLS)                      │ web-push (VAPID) ──► browser push services (FCM / Mozilla / Apple)
        ▼                                         
Managed PostgreSQL (e.g. Supabase or Neon)        Scheduler (Vercel Cron, daily 01:00 UTC = 09:00 SGT) ─► /api/cron/expiry-check (Bearer CRON_SECRET)
```
* No privileged DB credentials in browser code; the database is only reachable from the server.
* Sessions: random 256-bit token in an HttpOnly, SameSite=Lax cookie; only its SHA-256 hash is stored. Staff/admin 12 h, members/committee 30 days.
* Uploads (images/PDF ≤ 2 MB) are validated by file signature and stored in the database; served with `nosniff` and a sandbox CSP.
* The live **sgia.sg WordPress site and its DNS are not touched**.

## 3. Roles (enforced server-side)
Member · Verification Staff (`staff`) · SGIA Administrator (`admin`) · Management Committee (`committee`, member features + read-only admin dashboards + feedback). Every API handler declares its allowed roles; pages also redirect, but the API is the control.

## 4. Demo credentials
Generated randomly by `npm run db:reset`; stored only in `.secrets/demo-credentials.md` (git-ignored, mode 600). **Hand over through a password manager or a secure channel – never by email/chat in plain text.** Login IDs: `SGIA-DEMO-0001…0043` (members), `SGIA-STAFF-01/02`, `SGIA-ADMIN-01`, `SGIA-COMM-01/02/03`. No passwords or hashes appear in any export.

Showcase members: 0001 Arun Kumar (active, expires 31 Dec 2026) · 0002 Life member · 0003/0004/0005 expiring in 30/15/7 days · 0006 expires today · 0007/0008 expired · 0009 suspended · 0010–0012 a family · 0013 senior.

## 5. Admin demonstration guide (sign in as SGIA-ADMIN-01)
1. **Dashboard** – counts of members, active/expired, renewals due, announcements, events, push attempts, QR check-ins.
2. **Members → Manage** – edit expiry (quick buttons: +30/+15/+7/today/yesterday), suspend/reinstate, deactivate, reset password (temporary password shown once), regenerate QR. Add a member (email must be `@example.com`), import/export CSV.
3. **Live status demo** – on a phone sign in as staff and scan Arun's card; in another window suspend Arun; scan again → RED.
4. **Announcements** – create draft / publish now / schedule (Singapore time) / archive; choose audience; attach an image or PDF.
5. **Events** – create/hide/delete; members' registrations and capacity appear.
6. **Notification log** – every in-app, push and (simulated) email attempt with outcome; send an administrative notice.
7. **Dashboard → “Run expiry reminder check now”** – sends 30/15/7/0/−1-day reminders once per expiry date (re-runs send nothing; changing an expiry re-arms it).
8. **Renewal requests** – approve (+1 year) or decline. **Audit log** and **Feedback** pages.

## 6. Member demonstration guide (e.g. SGIA-DEMO-0003)
Home (renewal warning, days left, latest announcements, events) → Membership (DEMO card, QR, **Save QR as image**) → Events (register/cancel) → Notifications (unread dots, test panel) → Profile (details, family, push settings, change password, logout) → Renewal (DEMO request).

## 7. QR scanning test procedure
1. Member signs in on phone A, opens **Membership**.
2. Staff signs in on phone B (or desktop), opens **Scan**, taps **Start camera scan**, allows camera.
3. Expected: GREEN “Active”, AMBER “Expiring soon” (≤ 30 days), RED “Expired/Suspended/Deactivated”; shows name, ID, category, validity, last check-in.
4. Tap **Record check-in** (refused for red statuses; repeat within 2 min refused).
5. Admin changes expiry/suspends; scan the *same* QR again → status updates.
6. Camera blocked/unavailable? Use **Manual lookup** by Membership ID.
7. Scanning the QR with an ordinary phone camera opens `/verify/<token>`: signed-out visitors see no member data.

## 8. Push notification testing
1. Open the deployed URL over HTTPS on the phone and sign in as a member.
2. **iPhone/iPad:** Safari → Share → *Add to Home Screen*, open from the Home Screen (iOS 16.4+). Web push does not work from a normal Safari tab.
3. **Android/desktop Chrome:** Notifications page → **Turn on notifications** → Allow.
4. Press **Send me a test notification**; the screen shows the delivery attempt result.
5. Admin → Notification log shows the attempt. “Sent” means the push service accepted it; it does **not** prove display. Notifications cannot bypass Silent Mode, Focus/Do Not Disturb or disabled notifications. Everything also appears in the in-app Notification centre; email fallback is simulated only (no provider configured).

## 9. Mobile installation
Android Chrome: menu → *Install app*. iPhone Safari: Share → *Add to Home Screen*. Desktop Chrome/Edge: install icon in the address bar. Icons are derived from the supplied SGIA seal. (A custom iOS splash image is not yet generated; iOS shows a plain splash.)

## 10. Testing evidence and gaps
* `docs/test-evidence/e2e-run-2026-10-19.txt` – 88 passed / 0 failed: login, lockout, cookie flags, CSRF, role matrix, member isolation, QR decode/uniqueness/live status/rotation, uploads, events, CSV, audit, reminders (idempotent), cron secret, push logging, PWA manifest.
* **Cannot be verified automatically – needs physical devices / a browser:** camera scanning on iPhone Safari & Android Chrome; real push delivery and permission prompts; iOS Home-Screen install behaviour; visual layout/legibility on phone, tablet, desktop Chrome/Safari/Edge; screen-reader and large-text checks; session expiry after 12 h/30 days; behaviour with denied notification permission or no camera (code paths exist; UI messages not yet seen on a device).
* The build environment had no browser, so **no screenshots have been reviewed yet**.

## 11. Security & limitations
Implemented: bcrypt hashing, lockout after 5 failures (15 min), per-IP and per-action rate limits (DB-backed), generic login errors, server-side RBAC, Origin check on state-changing calls, HttpOnly cookies, security headers, input validation (zod), parameterised SQL, audit log, QR = random token only, signed-out `/verify` leaks nothing, upload signature checks, CSV formula-injection guard, no secrets in the repo, synthetic-email enforcement for new records.
Known limitations / to harden before production: rate-limit IP comes from `X-Forwarded-For` (fine behind Vercel, spoofable elsewhere); no email-based password reset or 2FA for staff/admin; push/email via real provider not production-tested; DB TLS uses `rejectUnauthorized:false` for convenience – pin the provider CA in production; attachments stored in DB (use object storage at scale); no malware scanning of uploads; no PDPA consent/retention workflow; no payments (by design); accessibility audit outstanding; Vercel Hobby is “non-commercial, personal” – the account owner must confirm it is acceptable for an association pilot, otherwise use Pro.

## 11a. Estimated production costs (≈1,000 members; verify at purchase)
| Item | Estimate |
|---|---|
| Hosting (Vercel Pro, 1 seat) | from US$20/month |
| Database (Supabase Pro) | from US$25/month (Free plan pauses after 1 week inactive; 500 MB) |
| Apple Developer Program (for native iOS) | US$99/year |
| Google Play registration (native Android) | US$25 one-time |
| Email (reminder fallback) | free tier likely sufficient (<3k/month) |
| Domain / DNS | existing sgia.sg |
| Push | no per-message cost (web push); native push via FCM/APNs free |
| **Run cost ≈** | **US$45/month ≈ US$540/year + US$99/year Apple** |
| Native app development, PDPA review, pen-test | one-off; to be quoted |
Sources: [Supabase pricing](https://supabase.com/pricing.md), [Vercel Hobby plan terms](https://vercel.com/docs/plans/hobby). Not legal/financial advice.

## 12. Migration plan to production
1. Committee feedback on prototype → freeze requirements; map real membership categories (edit `members-constants.ts` / DB).
2. Legal: PDPA review – purpose, consent, retention, DPO, breach process, data-processing agreements with hosting/DB vendors; choose region (Singapore).
3. Create production accounts owned by SGIA (not an individual); separate staging and production projects.
4. Replace demo identity: proper member import (cleansed), invite/activation + email-based password reset, 2FA for staff/admin, remove `@example.com` rule.
5. Real email provider for reminders; custom domain (e.g. connect.sgia.sg) via a new subdomain record only after approval.
6. Harden items in §11; add object storage for uploads; monitoring/alerts; backups and restore drill.
7. Accessibility and device test matrix; pilot with a small member group.
8. Decide PWA-only vs native (Capacitor wrapper reuses this web app; or native rebuild); app-store accounts and review.
9. Launch with rollback plan; decommission prototype and delete its data.

## 13. Deploying the prototype (needs approval) and shutting it down
**Deploy (requires the account owner):** create a Postgres project (Supabase/Neon free tier) → copy its connection string; create a Vercel project from this repo → set env vars `APP_URL` (the Vercel URL), `DATABASE_URL`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, `VAPID_SUBJECT`, `CRON_SECRET` → deploy → run `DATABASE_URL=… npm run db:seed` once from a trusted machine → hand over credentials securely. Protect the URL (Vercel Deployment Protection or keep it unlisted).
**Shut down:** delete the Vercel project (removes URL + cron) → delete the database project → revoke VAPID keys by deleting env vars → securely delete `.secrets/` and any credential copies → remove the repo if not needed.
