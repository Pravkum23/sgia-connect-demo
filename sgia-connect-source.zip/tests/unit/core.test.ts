import { describe, it, expect } from "vitest";
import { computeStatus, daysBetween, addDays } from "@/lib/status";
import { csvCell } from "@/lib/validate";
import { extractToken } from "@/components/Scanner";
import { passwordProblem } from "@/lib/auth";
import { newToken, newPassword } from "@/lib/tokens";

const T = "2026-10-19";
describe("membership status", () => {
  it("active when far from expiry", () => expect(computeStatus({ status: "active", expiry_date: "2027-06-01" }, T)).toBe("active"));
  it("expiring within 30 days, including today", () => {
    expect(computeStatus({ status: "active", expiry_date: addDays(T, 30) }, T)).toBe("expiring");
    expect(computeStatus({ status: "active", expiry_date: T }, T)).toBe("expiring");
  });
  it("31 days is still active", () => expect(computeStatus({ status: "active", expiry_date: addDays(T, 31) }, T)).toBe("active"));
  it("expired the day after expiry", () => expect(computeStatus({ status: "active", expiry_date: addDays(T, -1) }, T)).toBe("expired"));
  it("suspended overrides dates; deactivated overrides suspended", () => {
    expect(computeStatus({ status: "suspended", expiry_date: "2030-01-01" }, T)).toBe("suspended");
    expect(computeStatus({ status: "suspended", expiry_date: "2030-01-01", deactivated: true }, T)).toBe("inactive");
  });
  it("date maths crosses month/year/leap boundaries", () => {
    expect(daysBetween("2026-12-31", "2027-01-01")).toBe(1);
    expect(addDays("2028-02-28", 1)).toBe("2028-02-29");
    expect(daysBetween("2026-10-19", "2026-10-19")).toBe(0);
  });
});
describe("csv safety", () => {
  it("neutralises spreadsheet formula injection", () => {
    for (const bad of ["=cmd|' /C calc'!A0", "+1+1", "-2+3", "@SUM(A1)"]) expect(csvCell(bad).replace(/^"/, "").startsWith("'")).toBe(true);
  });
  it("quotes commas and quotes", () => expect(csvCell('a,"b"')).toBe('"a,""b"""'));
});
describe("QR payload parsing", () => {
  const tok = "A".repeat(43);
  it("extracts token from verify URL", () => expect(extractToken(`https://x.example/verify/${tok}`)).toBe(tok));
  it("accepts bare token and trims", () => expect(extractToken(`  ${tok} `)).toBe(tok));
  it("leaves unrelated text untouched", () => expect(extractToken("hello")).toBe("hello"));
});
describe("passwords & tokens", () => {
  it("policy", () => {
    expect(passwordProblem("short1", "X")).toBeTruthy();
    expect(passwordProblem("alllettersonly", "X")).toBeTruthy();
    expect(passwordProblem("GoodPassw0rdHere", "SGIA-1")).toBeNull();
    expect(passwordProblem("xSGIA-DEMO-0001x1", "SGIA-DEMO-0001")).toBeTruthy();
  });
  it("tokens are 43 chars, unique, url-safe", () => {
    const s = new Set(Array.from({ length: 2000 }, () => newToken()));
    expect(s.size).toBe(2000);
    for (const t of s) expect(t).toMatch(/^[A-Za-z0-9_-]{43}$/);
  });
  it("generated passwords avoid ambiguous characters", () => expect(newPassword(200)).not.toMatch(/[0O1lI]/));
});
