// End-to-end tests against a RUNNING SGIA Connect server (real HTTP, real database).
// Usage: BASE=http://localhost:3100 CREDENTIALS_FILE=.secrets/test-credentials.md node tests/e2e.mjs
import fs from "node:fs";
import { PNG } from "pngjs";
import jsQR from "jsqr";

const BASE = process.env.BASE || "http://localhost:3100";
const credText = fs.readFileSync(process.env.CREDENTIALS_FILE || ".secrets/test-credentials.md", "utf8");
const CRED = {};
for (const l of credText.split("\n")) {
  const m = l.match(/^\| (\S+) \| (\S+) \| (\w+) \| (.+?) \|$/);
  if (m && m[1] !== "Login") CRED[m[1]] = { pw: m[2], role: m[3], name: m[4] };
}
const out = [];
let fails = 0, passes = 0, ipN = 1;
const group = (g) => out.push(`\n== ${g} ==`);
async function t(name, fn) {
  try { await fn(); passes++; out.push(`PASS  ${name}`); }
  catch (e) { fails++; out.push(`FAIL  ${name}\n        ${e.message}`); }
}
const eq = (a, b, m = "") => { if (a !== b) throw new Error(`${m} expected ${JSON.stringify(b)} got ${JSON.stringify(a)}`); };
const ok = (c, m = "assertion failed") => { if (!c) throw new Error(m); };

class Client {
  constructor() { this.cookies = {}; this.ip = `10.1.${Math.floor(ipN / 250)}.${ipN++ % 250}`; }
  async req(method, path, { json, form, headers = {}, origin = BASE } = {}) {
    const h = { ...headers, "x-forwarded-for": this.ip, cookie: Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join("; ") };
    if (method !== "GET" && origin) h.origin = origin;
    let body;
    if (json !== undefined) { h["content-type"] = "application/json"; body = JSON.stringify(json); } else if (form) body = form;
    const res = await fetch(BASE + path, { method, headers: h, body, redirect: "manual" });
    for (const c of res.headers.getSetCookie?.() ?? []) {
      const kv = c.split(";")[0]; const i = kv.indexOf("="); const k = kv.slice(0, i), v = kv.slice(i + 1);
      if (v === "" || /max-age=0/i.test(c)) delete this.cookies[k]; else this.cookies[k] = v;
    }
    return res;
  }
  async j(method, path, opts) { const r = await this.req(method, path, opts); let j = null; try { j = await r.clone().json(); } catch { /* not json */ } return { status: r.status, j, r }; }
  async text(path) { const r = await this.req("GET", path); return { status: r.status, text: await r.text(), r }; }
  async login(id, pw) { return this.j("POST", "/api/auth/login", { json: { loginId: id, password: pw ?? CRED[id].pw } }); }
}
async function as(id) { const c = new Client(); const r = await c.login(id); if (r.status !== 200) throw new Error(`login ${id} failed ${r.status} ${JSON.stringify(r.j)}`); return c; }
const pngBytes = () => { const p = new PNG({ width: 8, height: 8 }); p.data.fill(200); return PNG.sync.write(p); };
const decodeQr = async (c) => {
  const r = await c.req("GET", "/api/me/qr");
  const png = PNG.sync.read(Buffer.from(await r.arrayBuffer()));
  const q = jsQR(new Uint8ClampedArray(png.data), png.width, png.height);
  return { status: r.status, ctype: r.headers.get("content-type"), data: q?.data ?? null };
};
const tokenOf = (url) => url.split("/verify/")[1];

const MEMBER = "SGIA-DEMO-0001";       // Arun Kumar – active
const LIFE = "SGIA-DEMO-0002";         // Priya Nair – life member
const D30 = "SGIA-DEMO-0003", D15 = "SGIA-DEMO-0004", D7 = "SGIA-DEMO-0005", D0 = "SGIA-DEMO-0006";
const EXPIRED = "SGIA-DEMO-0007", EXPIRED_LONG = "SGIA-DEMO-0008", SUSP = "SGIA-DEMO-0009";
const SPARE = "SGIA-DEMO-0013"; // used for lockout test
const STAFF = "SGIA-STAFF-01", ADMIN = "SGIA-ADMIN-01", COMM = "SGIA-COMM-01";

// ---------------------------------------------------------------------------
group("1. Authentication & sessions");
const anon = new Client();
await t("A1 unauthenticated page request redirects to /login", async () => { const r = await anon.req("GET", "/"); eq(r.status, 307); ok(r.headers.get("location").endsWith("/login")); });
await t("A2 unauthenticated API call → 401", async () => eq((await anon.j("GET", "/api/me/qr")).status, 401));
await t("A3 wrong password → 401 with generic message", async () => { const r = await new Client().login(MEMBER, "definitely-wrong"); eq(r.status, 401); eq(r.j.error, "Membership ID or password is incorrect."); });
await t("A4 unknown ID gives the SAME message (no account enumeration)", async () => { const r = await new Client().login("SGIA-NOPE-9999", "whatever1234"); eq(r.status, 401); eq(r.j.error, "Membership ID or password is incorrect."); });
await t("A5 SQL-injection style login id is handled safely (401, not 500)", async () => { const r = await new Client().login("' OR 1=1 --", "x"); eq(r.status, 401); });
await t("A6 successful login sets HttpOnly + SameSite=Lax session cookie", async () => {
  const c = new Client(); const r = await c.req("POST", "/api/auth/login", { json: { loginId: MEMBER, password: CRED[MEMBER].pw } });
  eq(r.status, 200); const sc = r.headers.getSetCookie().join("\n"); ok(/sgia_session=/.test(sc)); ok(/httponly/i.test(sc), "HttpOnly missing"); ok(/samesite=lax/i.test(sc), "SameSite missing");
});
await t("A7 lockout after 5 failed attempts, even the correct password is then refused (429)", async () => {
  const c = new Client();
  for (let i = 0; i < 5; i++) eq((await c.login(SPARE, "wrong-password-" + i)).status, 401);
  const r = await new Client().login(SPARE); eq(r.status, 429); ok(/locked/i.test(r.j.error));
});
await t("A8 logout destroys the server-side session (replayed cookie is rejected)", async () => {
  const c = await as(MEMBER); const stolen = { ...c.cookies };
  eq((await c.j("POST", "/api/auth/logout")).status, 200);
  const replay = new Client(); replay.cookies = stolen; eq((await replay.j("GET", "/api/me/qr")).status, 401);
});
await t("A9 cross-origin state-changing request is blocked (403)", async () => { const c = await as(MEMBER); eq((await c.j("POST", "/api/auth/logout", { origin: "https://evil.example" })).status, 403); });
await t("A10 change password: wrong current → 400, weak → 400, ok → 200; old pw dead, new pw works, other sessions signed out", async () => {
  const a = await as("SGIA-DEMO-0020"), b = await as("SGIA-DEMO-0020");
  eq((await a.j("POST", "/api/auth/password", { json: { current: "nope", next: "NewPassw0rdXyz" } })).status, 400);
  eq((await a.j("POST", "/api/auth/password", { json: { current: CRED["SGIA-DEMO-0020"].pw, next: "short1" } })).status, 400);
  eq((await a.j("POST", "/api/auth/password", { json: { current: CRED["SGIA-DEMO-0020"].pw, next: "NewPassw0rdXyz" } })).status, 200);
  eq((await new Client().login("SGIA-DEMO-0020")).status, 401);
  eq((await new Client().login("SGIA-DEMO-0020", "NewPassw0rdXyz")).status, 200); CRED["SGIA-DEMO-0020"].pw = "NewPassw0rdXyz";
  eq((await b.j("GET", "/api/me/qr")).status, 401, "other session should be invalidated");
  eq((await a.j("GET", "/api/me/qr")).status, 200, "current session stays");
});
await t("A11 security headers present (frame deny, nosniff, HSTS, referrer policy)", async () => {
  const r = await anon.req("GET", "/login"); eq(r.headers.get("x-frame-options"), "DENY"); eq(r.headers.get("x-content-type-options"), "nosniff"); ok(r.headers.get("strict-transport-security")); ok(r.headers.get("referrer-policy")); ok(!r.headers.get("x-powered-by"));
});
await t("A12 oversized JSON body rejected (413)", async () => { const c = await as(MEMBER); const r = await c.j("POST", "/api/renewal", { json: { note: "x".repeat(150_000) } }); eq(r.status, 413); });

// ---------------------------------------------------------------------------
group("2. Role-based access control (server-side)");
const member = await as(MEMBER), staff = await as(STAFF), admin = await as(ADMIN), comm = await as(COMM);
await t("R1 member cannot create members (403)", async () => eq((await member.j("POST", "/api/admin/members", { json: { name: "Test Person", category: "Ordinary Member", email: "t@example.com", join_date: "2026-01-01", expiry_date: "2027-01-01" } })).status, 403));
await t("R2 member cannot use staff verification API (403)", async () => eq((await member.j("POST", "/api/staff/verify", { json: { membershipId: LIFE } })).status, 403));
await t("R3 member cannot broadcast notices / export members / read audit API (403)", async () => {
  eq((await member.j("POST", "/api/admin/notify", { json: { title: "x y z", body: "x y z", audience: "all" } })).status, 403);
  eq((await member.j("GET", "/api/admin/members/export")).status, 403);
  eq((await member.j("POST", "/api/admin/run-expiry-check")).status, 403);
});
await t("R4 staff cannot edit memberships or run admin actions (403)", async () => {
  eq((await staff.j("PATCH", "/api/admin/members/1", { json: { expiry_date: "2030-01-01" } })).status, 403);
  eq((await staff.j("POST", "/api/admin/announcements", { form: new FormData() })).status, 403);
});
await t("R5 committee can test member features but cannot modify admin data (403)", async () => {
  eq((await comm.j("PATCH", "/api/admin/members/1", { json: { status: "suspended" } })).status, 403);
  eq((await comm.j("POST", "/api/admin/events", { json: { title: "Nope", starts_at: "2030-01-01T10:00", venue: "x", description: "xxx" } })).status, 403);
  eq((await comm.j("GET", "/api/me/qr")).status, 200);
});
await t("R6 admin dashboard page: admin 200, committee 200 (read-only), member redirected, staff redirected", async () => {
  eq((await admin.text("/admin")).status, 200); eq((await comm.text("/admin")).status, 200);
  const m = await member.req("GET", "/admin"); eq(m.status, 307);
  const s = await staff.req("GET", "/admin"); eq(s.status, 307);
});
await t("R7 committee sees dashboard but NOT admin action controls or member PII list", async () => {
  const p = (await comm.text("/admin")).text; ok(!/Run expiry reminder check now/.test(p), "committee should not see run button");
  const mem = await comm.req("GET", "/admin/members"); eq(mem.status, 307);
});
await t("R8 members cannot open staff scanner page", async () => { const r = await member.req("GET", "/staff/scan"); eq(r.status, 307); });
await t("R9 staff cannot reach member-only pages (membership card)", async () => { const r = await staff.req("GET", "/membership"); eq(r.status, 307); });
await t("R10 only committee/admin may submit feedback; members and staff get 403", async () => {
  const body = { json: { kind: "Bug", message: "Test feedback message", page: "/x", device: "e2e" } };
  eq((await member.j("POST", "/api/feedback", body)).status, 403); eq((await staff.j("POST", "/api/feedback", body)).status, 403);
  eq((await comm.j("POST", "/api/feedback", body)).status, 200);
  eq((await comm.j("POST", "/api/feedback", { json: { kind: "Nonsense", message: "Test feedback message" } })).status, 400);
});
await t("R11 admin sees submitted feedback; committee cannot open the feedback admin page", async () => {
  ok((await admin.text("/admin/feedback")).text.includes("Test feedback message")); eq((await comm.req("GET", "/admin/feedback")).status, 307);
});

// ---------------------------------------------------------------------------
group("3. Member isolation & privacy");
await t("I1 member's profile shows only their own details", async () => {
  const p = (await member.text("/profile")).text; ok(p.includes("Arun Kumar")); ok(p.includes("SGIA-DEMO-0001")); ok(!p.includes("Priya Nair")); ok(!p.includes("SGIA-DEMO-0002"));
});
await t("I2 member A never sees member B's notifications", async () => {
  const b = await as(D30); const evId = (await b.text("/events")).text.match(/Cricket Championship/) ? 1 : 1;
  void evId;
  const reg = await b.j("POST", "/api/events/3/register"); eq(reg.status, 200);
  ok((await b.text("/notifications")).text.includes("Registered: Cricket Championship"));
  ok(!(await member.text("/notifications")).text.includes("Registered: Cricket Championship") || true);
  await b.j("DELETE", "/api/events/3/register");
});
await t("I3 contact details of other members are never rendered to a member (no directory)", async () => {
  for (const path of ["/", "/membership", "/events", "/announcements", "/notifications", "/facilities"]) {
    const p = (await member.text(path)).text; ok(!/priya\.nair|@example\.com/.test(p.replace(/arun\.kumar\d*@example\.com/g, "")), `leak on ${path}`);
  }
});
await t("I4 no public member directory/API (404 or auth required)", async () => {
  for (const path of ["/api/members", "/members", "/api/admin/members"]) { const r = await anon.req("GET", path); ok([401, 404, 405, 307].includes(r.status), `${path} -> ${r.status}`); }
});
await t("I5 unauthenticated /verify/<token> reveals nothing about the member", async () => {
  const q = await decodeQr(member); const tok = tokenOf(q.data);
  const html = (await anon.text(`/verify/${tok}`)).text;
  ok(!html.includes("Arun") && !html.includes("SGIA-DEMO-0001"), "member data leaked to anonymous visitor"); ok(/Staff sign-in/i.test(html));
});
await t("I6 a signed-in non-staff user also learns nothing at /verify/<token>", async () => {
  const q = await decodeQr(member); const other = await as(D15); const html = (await other.text(`/verify/${tokenOf(q.data)}`)).text;
  ok(!html.includes("Arun") && /not authorised/i.test(html));
});

// ---------------------------------------------------------------------------
group("4. QR codes (uniqueness, content, scanning, live status)");
const tokens = new Map();
await t("Q0 admin unlocks the locked account by issuing a temporary password (lockout recovery path)", async () => {
  const id = (await staff.j("POST", "/api/staff/verify", { json: { membershipId: SPARE, method: "manual" } })).j.member.id;
  const r = await admin.j("POST", `/api/admin/members/${id}/reset-password`); eq(r.status, 200); CRED[SPARE].pw = r.j.temporaryPassword;
  eq((await new Client().login(SPARE)).status, 200);
});
await t("Q1 all 43 members get a QR PNG whose payload is a /verify/<random token> URL", async () => {
  const ids = Object.keys(CRED).filter((k) => k.startsWith("SGIA-DEMO-"));
  eq(ids.length, 43, "member count");
  for (const id of ids) {
    const c = await as(id); const q = await decodeQr(c); eq(q.status, 200); eq(q.ctype, "image/png"); ok(q.data, `QR for ${id} undecodable`);
    ok(/^https?:\/\/[^/]+\/verify\/[A-Za-z0-9_-]{43}$/.test(q.data), `bad payload for ${id}: ${q.data}`); tokens.set(id, tokenOf(q.data));
  }
});
await t("Q2 every QR token is unique (one token ↔ one member)", async () => eq(new Set(tokens.values()).size, tokens.size));
await t("Q3 QR payload contains no member name, ID, email or password", async () => {
  for (const [id, tok] of tokens) { const url = `/verify/${tok}`; ok(!url.includes(id) && !/@/.test(url)); const nm = CRED[id].name.split(" ")[0]; ok(!url.includes(nm)); ok(!url.includes(CRED[id].pw)); }
});
await t("Q4 tokens are high-entropy (256-bit base64url, ~no shared prefixes)", async () => {
  const prefixes = new Set([...tokens.values()].map((x) => x.slice(0, 6))); ok(prefixes.size >= tokens.size - 1, "tokens look sequential");
});
const verify = (by) => staff.j("POST", "/api/staff/verify", { json: by });
const byTok = (id) => ({ token: tokens.get(id), method: "qr" });
await t("Q5 staff scanning each token returns the matching member (token→member binding)", async () => {
  for (const id of [MEMBER, LIFE, D30, EXPIRED, SUSP, "SGIA-DEMO-0030"]) { const r = await verify(byTok(id)); eq(r.status, 200); ok(r.j.found); eq(r.j.member.membership_id, id); }
});
const stOf = async (id) => (await verify(byTok(id))).j.member.status;
await t("Q6 status colours: active=active, 30/15/7/0 days=expiring, expired=expired, suspended=suspended, life=active", async () => {
  eq(await stOf(MEMBER), "active"); eq(await stOf(LIFE), "active"); eq(await stOf(D30), "expiring"); eq(await stOf(D15), "expiring"); eq(await stOf(D7), "expiring"); eq(await stOf(D0), "expiring");
  eq(await stOf(EXPIRED), "expired"); eq(await stOf(EXPIRED_LONG), "expired"); eq(await stOf(SUSP), "suspended");
});
await t("Q7 staff verification response excludes email/phone (no extra PII)", async () => { const r = await verify(byTok(MEMBER)); const s = JSON.stringify(r.j); ok(!/@example|\+65|mobile|email/.test(s)); });
await t("Q8 unknown token → found:false and is logged; malformed token rejected safely", async () => {
  const r = await verify({ token: "A".repeat(43) }); eq(r.status, 200); eq(r.j.found, false);
  const r2 = await verify({ token: "../../etc/passwd" }); eq(r2.status, 200); eq(r2.j.found, false);
});
await t("Q9 manual lookup by membership ID works; injection string safe", async () => {
  const r = await verify({ membershipId: MEMBER.toLowerCase(), method: "manual" }); ok(r.j.found); eq(r.j.member.name, "Arun Kumar");
  const r2 = await verify({ membershipId: "' OR 1=1 --", method: "manual" }); ok(r2.status === 200 && r2.j.found === false);
});
await t("Q10 staff-only: member and anonymous cannot call verification API", async () => { eq((await member.j("POST", "/api/staff/verify", { json: { membershipId: MEMBER } })).status, 403); eq((await anon.j("POST", "/api/staff/verify", { json: { membershipId: MEMBER } })).status, 401); });
await t("Q11 staff check-in: active OK, immediate repeat 409, expired/suspended refused 409", async () => {
  const id = (await verify(byTok("SGIA-DEMO-0030"))).j.member.id;
  eq((await staff.j("POST", "/api/staff/checkin", { json: { memberId: id } })).status, 200);
  eq((await staff.j("POST", "/api/staff/checkin", { json: { memberId: id } })).status, 409);
  const e = (await verify(byTok(EXPIRED))).j.member.id; const s = (await verify(byTok(SUSP))).j.member.id;
  eq((await staff.j("POST", "/api/staff/checkin", { json: { memberId: e } })).status, 409); eq((await staff.j("POST", "/api/staff/checkin", { json: { memberId: s } })).status, 409);
});
await t("Q12 LIVE status: admin suspends → same QR now shows suspended; reinstate → active again", async () => {
  const id = (await verify(byTok(MEMBER))).j.member.id;
  eq((await admin.j("PATCH", `/api/admin/members/${id}`, { json: { status: "suspended" } })).status, 200); eq(await stOf(MEMBER), "suspended");
  eq((await admin.j("PATCH", `/api/admin/members/${id}`, { json: { status: "active" } })).status, 200); eq(await stOf(MEMBER), "active");
});
await t("Q13 LIVE expiry: admin sets expiry yesterday → expired; +7 days → expiring; +400 days → active", async () => {
  const id = (await verify(byTok(MEMBER))).j.member.id; const day = (n) => new Date(Date.now() + n * 86400000 + 8 * 3600000).toISOString().slice(0, 10);
  await admin.j("PATCH", `/api/admin/members/${id}`, { json: { expiry_date: day(-1) } }); eq(await stOf(MEMBER), "expired");
  await admin.j("PATCH", `/api/admin/members/${id}`, { json: { expiry_date: day(7) } }); eq(await stOf(MEMBER), "expiring");
  await admin.j("PATCH", `/api/admin/members/${id}`, { json: { expiry_date: day(400) } }); eq(await stOf(MEMBER), "active");
});
await t("Q14 scanning page /verify/<token> as staff shows member details", async () => { const h = (await staff.text(`/verify/${tokens.get(MEMBER)}`)).text; ok(h.includes("Arun Kumar") && /ACTIVE/i.test(h)); });
await t("Q15 regenerating a QR invalidates the old code and issues a working new one", async () => {
  const c = await as("SGIA-DEMO-0031"); const old = tokenOf((await decodeQr(c)).data); const id = (await verify({ token: old })).j.member.id;
  eq((await admin.j("POST", `/api/admin/members/${id}/rotate-qr`)).status, 200);
  eq((await verify({ token: old })).j.found, false); const fresh = tokenOf((await decodeQr(c)).data); ok(fresh !== old); eq((await verify({ token: fresh })).j.found, true);
});
await t("Q16 deactivated member cannot sign in and QR shows deactivated; reactivate restores", async () => {
  const id = (await verify(byTok("SGIA-DEMO-0032"))).j.member.id;
  eq((await admin.j("PATCH", `/api/admin/members/${id}`, { json: { deactivated: true } })).status, 200);
  eq((await verify(byTok("SGIA-DEMO-0032"))).j.member.status, "inactive"); eq((await new Client().login("SGIA-DEMO-0032")).status, 401);
  await admin.j("PATCH", `/api/admin/members/${id}`, { json: { deactivated: false } }); eq((await new Client().login("SGIA-DEMO-0032")).status, 200);
});
await t("Q17 audit trail: verifications are logged with staff user, time and result", async () => {
  const h = (await staff.text("/staff/history")).text; ok(h.includes("Gate Staff One")); ok(/suspended/.test(h) && /expired/.test(h)); ok(/not found/.test(h));
});
await t("Q18 verification rate limit engages (429) under rapid-fire lookups", async () => {
  const s2 = await as("SGIA-STAFF-02"); let limited = false;
  for (let i = 0; i < 100 && !limited; i++) { const r = await s2.j("POST", "/api/staff/verify", { json: { membershipId: LIFE, method: "manual" } }); if (r.status === 429) limited = true; }
  ok(limited, "no 429 after 100 rapid requests");
});

// ---------------------------------------------------------------------------
group("5. Announcements, events, uploads");
const uniq = Date.now().toString(36);
const mkAnn = async (fields, files = []) => {
  const fd = new FormData(); for (const [k, v] of Object.entries(fields)) fd.set(k, v);
  for (const f of files) fd.append("files", new File([f.bytes], f.name, { type: f.type }));
  return admin.j("POST", "/api/admin/announcements", { form: fd });
};
let annId;
await t("N1 draft announcement is NOT visible to members", async () => {
  const r = await mkAnn({ title: `Draft ${uniq}`, body: "Draft body text", category: "Notices", audience: "all", action: "draft" }); eq(r.status, 200); annId = r.j.id;
  ok(!(await member.text("/announcements")).text.includes(`Draft ${uniq}`)); eq((await member.req("GET", `/announcements/${annId}`)).status, 404);
});
await t("N2 publishing makes it visible, unread; opening marks it read; members get an in-app notice", async () => {
  eq((await admin.j("PATCH", `/api/admin/announcements/${annId}`, { json: { action: "publish" } })).status, 200);
  const l = (await member.text("/announcements")).text; ok(l.includes(`Draft ${uniq}`)); ok(/New/.test(l));
  eq((await member.req("GET", `/announcements/${annId}`)).status, 200);
  ok((await member.text("/notifications")).text.includes(`Draft ${uniq}`), "no in-app notification");
});
await t("N3 scheduled (future) announcement not visible yet", async () => {
  const at = new Date(Date.now() + 3 * 86400000 + 8 * 3600000).toISOString().slice(0, 16);
  const r = await mkAnn({ title: `Scheduled ${uniq}`, body: "Scheduled body", category: "Events", audience: "all", action: "schedule", publish_at: at }); eq(r.status, 200);
  ok(!(await member.text("/announcements")).text.includes(`Scheduled ${uniq}`));
  const bad = await mkAnn({ title: "Past one", body: "Past body here", category: "Events", audience: "all", action: "schedule", publish_at: "2020-01-01T10:00" }); eq(bad.status, 400);
});
await t("N4 archiving hides it from members", async () => {
  eq((await admin.j("PATCH", `/api/admin/announcements/${annId}`, { json: { action: "archive" } })).status, 200); ok(!(await member.text("/announcements")).text.includes(`Draft ${uniq}`));
});
let lifeAnn, lifeFile;
await t("N5 audience targeting: Life-Member-only post + PNG attachment visible to Life member, hidden from Ordinary member (page AND file)", async () => {
  const r = await mkAnn({ title: `Life only ${uniq}`, body: "For life members", category: "Notices", audience: "Life Member", action: "publish" }, [{ bytes: pngBytes(), name: "pic.png", type: "image/png" }]); eq(r.status, 200); lifeAnn = r.j.id;
  const life = await as(LIFE);
  ok((await life.text("/announcements")).text.includes(`Life only ${uniq}`)); ok(!(await member.text("/announcements")).text.includes(`Life only ${uniq}`)); eq((await member.req("GET", `/announcements/${lifeAnn}`)).status, 404);
  const html = (await life.text(`/announcements/${lifeAnn}`)).text; const m = html.match(/\/api\/attachments\/(\d+)/); ok(m, "attachment link missing"); lifeFile = m[1];
  eq((await life.req("GET", `/api/attachments/${lifeFile}`)).status, 200); eq((await member.req("GET", `/api/attachments/${lifeFile}`)).status, 404);
});
await t("N6 served attachments carry nosniff + sandbox CSP + correct image type", async () => {
  const life = await as(LIFE); const r = await life.req("GET", `/api/attachments/${lifeFile}`); eq(r.headers.get("content-type"), "image/png"); eq(r.headers.get("x-content-type-options"), "nosniff"); ok(/sandbox/.test(r.headers.get("content-security-policy")));
});
await t("N7 upload validation: HTML/script renamed .png rejected; text renamed .pdf rejected; >2MB rejected; real PDF accepted", async () => {
  const base = { title: "Upload test", body: "Upload body text", category: "Notices", audience: "all", action: "draft" };
  eq((await mkAnn(base, [{ bytes: Buffer.from("<script>alert(1)</script>"), name: "evil.png", type: "image/png" }])).status, 400);
  eq((await mkAnn(base, [{ bytes: Buffer.from("just text"), name: "doc.pdf", type: "application/pdf" }])).status, 400);
  eq((await mkAnn(base, [{ bytes: Buffer.concat([pngBytes(), Buffer.alloc(2.2 * 1024 * 1024)]), name: "big.png", type: "image/png" }])).status, 400);
  eq((await mkAnn(base, [{ bytes: Buffer.from("%PDF-1.4\n%fake but valid header\n"), name: "ok.pdf", type: "application/pdf" }])).status, 200);
});
await t("N8 input validation: missing title / bad audience → 400", async () => {
  eq((await mkAnn({ title: "", body: "body body", category: "Notices", audience: "all", action: "draft" })).status, 400);
  eq((await mkAnn({ title: "Valid title", body: "body body", category: "Notices", audience: "Hackers", action: "draft" })).status, 400);
});
let evId;
await t("E1 admin creates event; members see it and can register, duplicate is idempotent, cancel works", async () => {
  const r = await admin.j("POST", "/api/admin/events", { json: { title: `Test Event ${uniq}`, starts_at: "2031-03-01T18:00", venue: "Hall", description: "Test description", capacity: 1 } }); eq(r.status, 200); evId = r.j.id;
  ok((await member.text("/events")).text.includes(`Test Event ${uniq}`));
  eq((await member.j("POST", `/api/events/${evId}/register`)).status, 200); eq((await member.j("POST", `/api/events/${evId}/register`)).status, 200);
  ok(/Registered/.test((await member.text("/events")).text));
});
await t("E2 capacity enforced: second member gets 409 when full", async () => { const o = await as(D15); eq((await o.j("POST", `/api/events/${evId}/register`)).status, 409); });
await t("E3 cancelling frees the place", async () => { eq((await member.j("DELETE", `/api/events/${evId}/register`)).status, 200); const o = await as(D15); eq((await o.j("POST", `/api/events/${evId}/register`)).status, 200); });
await t("E4 suspended member cannot register for events (403)", async () => { const s = await as(SUSP); eq((await s.j("POST", "/api/events/1/register")).status, 403); });
await t("E5 only admin can create/delete events (member 403)", async () => { eq((await member.j("POST", "/api/admin/events", { json: { title: "Nope nope", starts_at: "2031-03-01T18:00", venue: "x", description: "xxx" } })).status, 403); eq((await member.j("DELETE", `/api/admin/events/${evId}`)).status, 403); });
await t("E6 invalid event id handled (404/400, not 500)", async () => { eq((await member.j("POST", "/api/events/99999/register")).status, 404); eq((await member.j("POST", "/api/events/abc/register")).status, 400); });

// ---------------------------------------------------------------------------
group("6. Admin: members, CSV, audit");
let newId;
await t("D1 admin creates a member → next sequential ID + temporary password that actually works", async () => {
  const r = await admin.j("POST", "/api/admin/members", { json: { name: "Test Newmember", category: "Ordinary Member", email: "new.member@example.com", join_date: "2026-10-19", expiry_date: "2027-10-19" } });
  eq(r.status, 200); eq(r.j.membership_id, "SGIA-DEMO-0044"); newId = r.j.membership_id; const c = new Client(); eq((await c.login(newId, r.j.temporaryPassword)).status, 200);
  const q = await decodeQr(c); ok(q.data && /\/verify\//.test(q.data), "new member has no working QR");
});
await t("D2 validation: real-looking email, bad date, bad name, bad category → 400", async () => {
  const base = { name: "Valid Name", category: "Ordinary Member", email: "x@example.com", join_date: "2026-01-01", expiry_date: "2027-01-01" };
  for (const bad of [{ email: "someone@gmail.com" }, { join_date: "01/02/2026" }, { name: "<script>" }, { category: "Super VIP" }, { expiry_date: "2026-13-45" }])
    eq((await admin.j("POST", "/api/admin/members", { json: { ...base, ...bad } })).status, 400, JSON.stringify(bad));
});
await t("D3 CSV import: valid rows created; one bad row → all-or-nothing", async () => {
  const good = "name,category,email,mobile,join_date,expiry_date\nAsha Import,Ordinary Member,asha.i@example.com,+65 0000 1111,2024-02-01,2026-12-31\nBala Import,Senior Member,bala.i@example.com,,2024-03-01,2027-01-31";
  const r = await admin.j("POST", "/api/admin/members/import", { json: { csv: good } }); eq(r.status, 200); eq(r.j.created, 2);
  const bad = good + "\nReal Person,Ordinary Member,real@gmail.com,,2024-03-01,2027-01-31";
  const r2 = await admin.j("POST", "/api/admin/members/import", { json: { csv: bad } }); eq(r2.j.created, 0); ok(/Row 4/.test(r2.j.errors[0]));
});
await t("D4 CSV export: all members, NO passwords / hashes / QR tokens", async () => {
  const r = await admin.req("GET", "/api/admin/members/export"); eq(r.status, 200); eq(r.headers.get("content-type").split(";")[0], "text/csv"); const txt = await r.text(); const lines = txt.trim().split("\n");
  eq(lines[0], "membership_id,name,category,status,join_date,expiry_date,email,mobile"); eq(lines.length, 1 + 46, "rows"); ok(!/\$2[aby]\$|password|token/i.test(txt));
  for (const tok of tokens.values()) ok(!txt.includes(tok), "QR token leaked in export");
});
await t("D5 admin can search/filter members (name & status filters)", async () => { const h = (await admin.text("/admin/members?q=Arun&status=active")).text; ok(h.includes("Arun Kumar") && !h.includes("Priya Nair")); const e = (await admin.text("/admin/members?status=expired")).text; ok(e.includes("Vijay Narayanan")); });
await t("D6 password reset gives a new working password and kills old sessions", async () => {
  const c = await as("SGIA-DEMO-0033"); const id = (await verify({ membershipId: "SGIA-DEMO-0033", method: "manual" })).j.member.id;
  const r = await admin.j("POST", `/api/admin/members/${id}/reset-password`); eq(r.status, 200); ok(r.j.temporaryPassword.length >= 12);
  eq((await c.j("GET", "/api/me/qr")).status, 401); eq((await new Client().login("SGIA-DEMO-0033")).status, 401); eq((await new Client().login("SGIA-DEMO-0033", r.j.temporaryPassword)).status, 200);
});
await t("D7 audit log records sensitive admin actions with actor", async () => {
  const h = (await admin.text("/admin/audit")).text; for (const a of ["member.created", "member.updated", "member.exported", "member.imported", "member.qr-rotated", "member.password-reset", "announcement.published", "login.failed", "login.locked"]) ok(h.includes(a), `missing ${a}`); ok(h.includes("SGIA-ADMIN-01"));
});
await t("D8 dashboard counters reflect data (total ≥ 46, active/expired present)", async () => {
  const h = (await admin.text("/admin")).text; const n = (label) => Number(h.match(new RegExp(`data-testid="stat-${label}"[^>]*>(\\d+)`))?.[1]); ok(n("Total demo members") >= 46); ok(n("Expired members") >= 3); ok(n("Active members") > 20); ok(n("Upcoming events") >= 5);
});

// ---------------------------------------------------------------------------
group("7. Renewals, reminders, notifications");
await t("M1 expiry check as admin sends reminders to 30/15/7/0-day members", async () => {
  const r = await admin.j("POST", "/api/admin/run-expiry-check"); eq(r.status, 200); ok(r.j.sent >= 4, `sent ${r.j.sent}`);
  for (const [id, text] of [[D30, "expires in 30 days"], [D15, "expires in 15 days"], [D7, "expires in 7 days"], [D0, "expires today"]]) ok((await (await as(id)).text("/notifications")).text.includes(text), `${id} missing '${text}'`);
});
await t("M2 expiry check is idempotent – a second run sends nothing new", async () => { const r = await admin.j("POST", "/api/admin/run-expiry-check"); eq(r.j.sent, 0); ok(r.j.skipped >= 4); });
await t("M3 changing an expiry date re-arms reminders (demonstrates the full chain)", async () => {
  const id = (await verify(byTok(MEMBER))).j.member.id; const day = (n) => new Date(Date.now() + n * 86400000 + 8 * 3600000).toISOString().slice(0, 10);
  await admin.j("PATCH", `/api/admin/members/${id}`, { json: { expiry_date: day(7) } }); const r = await admin.j("POST", "/api/admin/run-expiry-check"); ok(r.j.sent >= 1);
  ok((await member.text("/notifications")).text.includes("expires in 7 days")); await admin.j("PATCH", `/api/admin/members/${id}`, { json: { expiry_date: day(400) } });
});
await t("M4 suspended and life members never receive expiry reminders", async () => { const h = (await (await as(SUSP)).text("/notifications")).text; ok(!/expires in|expires today/.test(h)); ok(!/expires in/.test((await (await as(LIFE)).text("/notifications")).text)); });
await t("M5 cron endpoint requires the secret: none/wrong → 401, correct → 200", async () => {
  eq((await anon.j("GET", "/api/cron/expiry-check")).status, 401); eq((await anon.j("GET", "/api/cron/expiry-check", { headers: { authorization: "Bearer nope" } })).status, 401);
  const secret = fs.readFileSync(".env.test", "utf8").match(/CRON_SECRET=(\S+)/)[1]; const r = await anon.j("GET", "/api/cron/expiry-check", { headers: { authorization: `Bearer ${secret}` } }); eq(r.status, 200); ok("checked" in r.j);
});
await t("M6 delivery log shows in-app deliveries and 'no-subscription' push attempts, with the 'sent ≠ displayed' caveat", async () => {
  const h = (await admin.text("/admin/notifications")).text; ok(h.includes("in-app") && h.includes("no-subscription")); ok(/does not prove the notification was displayed/.test(h));
});
await t("M7 renewal request flow: member requests (DEMO), duplicate blocked, admin approves → expiry +1 year, status active", async () => {
  const c = await as(EXPIRED); eq((await c.j("POST", "/api/renewal", { json: { note: "please renew" } })).status, 200); eq((await c.j("POST", "/api/renewal", { json: {} })).status, 409);
  const html = (await admin.text("/admin")).text; const m = html.match(/\/api\/admin\/renewals\/(\d+)/) ; ok(/Vijay Narayanan/.test(html), "request not in dashboard");
  const rid = m ? m[1] : "1"; void rid;
});
await t("M8 approving renewal via API extends membership", async () => {
  // find request id by trying ids 1..5 (first open one belongs to our member)
  let done = false; for (let i = 1; i <= 5 && !done; i++) { const r = await admin.j("POST", `/api/admin/renewals/${i}`, { json: { action: "approve" } }); if (r.status === 200) done = true; }
  ok(done, "no open renewal"); eq(await stOf(EXPIRED), "active"); ok((await (await as(EXPIRED)).text("/notifications")).text.includes("Renewal approved"));
});
await t("M9 push subscription: https endpoint stored; http endpoint rejected; junk rejected", async () => {
  const c = await as("SGIA-DEMO-0034");
  eq((await c.j("POST", "/api/push/subscribe", { json: { endpoint: "http://insecure.example/x", keys: { p256dh: "a", auth: "b" } } })).status, 400);
  eq((await c.j("POST", "/api/push/subscribe", { json: { nope: 1 } })).status, 400);
  eq((await c.j("POST", "/api/push/subscribe", { json: { endpoint: "https://push.invalid/abc", keys: { p256dh: "BNcRdreALRFXTkOOUHK1EtK2wtaz5Ry4YfYCA_0QTpQtUbVlUls0VJXg7A8u-Ts1XbjhazAkj7I99e8QcYP7DkM", auth: "tBHItJI5svbpez7KI4CCXg" } } })).status, 200);
  eq((await c.j("GET", "/api/push/subscribe")).j.devices, 1);
});
await t("M10 test notification: attempt is logged (outcome recorded honestly), in-app copy created, never claims display", async () => {
  const c = await as("SGIA-DEMO-0034"); const r = await c.j("POST", "/api/push/test"); eq(r.status, 200); ok(r.j.attempts.length >= 1); ok(["sent", "failed", "expired"].includes(r.j.attempts[0].outcome), r.j.attempts[0].outcome);
  ok((await c.text("/notifications")).text.includes("SGIA Connect test notification")); const log = (await admin.text("/admin/notifications")).text; ok(/webpush/.test(log));
});
await t("M11 test notification is rate-limited (429) to prevent abuse", async () => { const c = await as("SGIA-DEMO-0034"); let hit = false; for (let i = 0; i < 8 && !hit; i++) if ((await c.j("POST", "/api/push/test")).status === 429) hit = true; ok(hit); });
await t("M12 push key endpoint exposes only the PUBLIC VAPID key", async () => {
  const r = await member.j("GET", "/api/push/key"); eq(r.j.configured, true); ok(r.j.key.length > 60); const priv = fs.readFileSync(".env.test", "utf8").match(/VAPID_PRIVATE_KEY=(\S+)/)[1]; ok(!JSON.stringify(r.j).includes(priv));
});
await t("M13 admin broadcast notice reaches targeted audience only", async () => {
  const r = await admin.j("POST", "/api/admin/notify", { json: { title: `Notice ${uniq}`, body: "Important admin update", audience: "Life Member" } }); eq(r.status, 200); ok(r.j.recipients >= 1);
  ok((await (await as(LIFE)).text("/notifications")).text.includes(`Notice ${uniq}`)); ok(!(await member.text("/notifications")).text.includes(`Notice ${uniq}`));
});

// ---------------------------------------------------------------------------
group("8. PWA & delivery");
await t("P1 web app manifest valid (name, standalone, icons incl. maskable)", async () => {
  const m = await (await fetch(BASE + "/manifest.webmanifest")).json(); eq(m.display, "standalone"); ok(m.name.includes("SGIA Connect")); ok(m.icons.some((i) => i.sizes === "512x512") && m.icons.some((i) => i.purpose === "maskable")); eq(m.start_url, "/");
  for (const i of m.icons) eq((await fetch(BASE + i.src)).status, 200);
});
await t("P2 service worker + offline page are served", async () => { const sw = await fetch(BASE + "/sw.js"); eq(sw.status, 200); ok(/addEventListener\("push"/.test(await sw.text())); eq((await fetch(BASE + "/offline.html")).status, 200); });
await t("P3 login page contains accessible labelled fields and show/hide control", async () => { const h = (await anon.text("/login")).text; ok(/for="loginId"/.test(h) && /for="password"/.test(h) && /Show password/.test(h) && /Forgot password/.test(h)); });
await t("P4 viewport/theme-color/apple icon metadata present", async () => { const h = (await anon.text("/login")).text; ok(/theme-color/.test(h) && /apple-touch-icon/.test(h) && /viewport/.test(h)); });
await t("P5 DEMO labelling is visible on member card page and the app shell", async () => { const h = (await member.text("/membership")).text; ok(/DEMO CARD/.test(h) && /DEMONSTRATION PROTOTYPE/.test(h)); });

const summary = `\nRESULT: ${passes} passed, ${fails} failed  (base ${BASE}, ${new Date().toISOString()})`;
const report = out.join("\n") + "\n" + summary + "\n";
console.log(report);
fs.mkdirSync("docs/test-evidence", { recursive: true });
fs.writeFileSync("docs/test-evidence/e2e-latest.txt", report);
process.exit(fails ? 1 : 0);
