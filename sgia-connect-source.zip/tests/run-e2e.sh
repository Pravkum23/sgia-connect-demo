#!/usr/bin/env bash
# Resets a throwaway database, starts the production server on :3100 against it, runs the E2E suite, stops the server.
set -uo pipefail
cd "$(dirname "$0")/.."
export PGLITE_DIR="$PWD/data/pglite-test"
export CREDENTIALS_FILE="$PWD/.secrets/test-credentials.md"
grep -v '^APP_URL' .env.local > .env.test; echo "APP_URL=http://localhost:3100" >> .env.test
fuser -k 3100/tcp >/dev/null 2>&1; sleep 1   # free the port if a previous run left a server behind
rm -rf "$PGLITE_DIR"
npm run db:reset --silent || exit 2
set -a; . ./.env.test; set +a
npx next start -p 3100 > "${TMPDIR:-/tmp}/sgia-test-server.log" 2>&1 &
trap 'fuser -k 3100/tcp >/dev/null 2>&1' EXIT
for i in $(seq 1 40); do curl -s -o /dev/null localhost:3100/login && break; sleep 0.5; done
BASE=http://localhost:3100 node tests/e2e.mjs
