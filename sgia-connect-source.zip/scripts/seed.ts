/* Seeds SYNTHETIC demo data only. Usage: npm run db:seed [-- --reset]
   Credentials are generated randomly and written to .secrets/demo-credentials.md (git-ignored). */
import fs from "node:fs";
import path from "node:path";
import { q, one, resetDb, dbKind } from "../src/lib/db";
import { hashPassword } from "../src/lib/auth";
import { newToken, newPassword } from "../src/lib/tokens";
import { addDays, sgToday } from "../src/lib/status";

const reset = process.argv.includes("--reset");
const today = sgToday();

const FIRST = ["Arun","Priya","Karthik","Meena","Suresh","Lakshmi","Vijay","Anita","Ramesh","Deepa","Sanjay","Kavitha","Mohan","Divya","Prakash","Revathi","Naveen","Shalini","Gopal","Uma","Hari","Sandhya","Dinesh","Padma","Rajan","Geetha","Balaji","Nisha","Venkat","Anjali","Manoj","Radha","Ashok","Swathi","Kumar","Indira","Siva","Malathi","Bala","Janani"];
const LAST = ["Kumar","Nair","Menon","Pillai","Rajan","Subramaniam","Iyer","Narayanan","Krishnan","Balakrishnan","Chandran","Varma","Ramasamy","Govindan","Sharma","Naidu","Reddy","Das","Mohan","Raman"];

type M = { name: string; category: string; status?: "active" | "suspended"; join: string; expiryOffset?: number; expiry?: string; head?: number };
const showcase: M[] = [
  { name: "Arun Kumar", category: "Ordinary Member", join: "2022-01-15", expiry: "2026-12-31" },
  { name: "Priya Nair", category: "Life Member", join: "2009-03-02", expiry: "2099-12-31" },
  { name: "Karthik Menon", category: "Ordinary Member", join: "2021-06-10", expiryOffset: 30 },
  { name: "Meena Pillai", category: "Senior Member", join: "2015-08-21", expiryOffset: 15 },
  { name: "Suresh Rajan", category: "Ordinary Member", join: "2019-02-11", expiryOffset: 7 },
  { name: "Lakshmi Iyer", category: "Ordinary Member", join: "2020-10-05", expiryOffset: 0 },
  { name: "Vijay Narayanan", category: "Ordinary Member", join: "2018-04-18", expiryOffset: -12 },
  { name: "Anita Krishnan", category: "Family Member", join: "2017-07-07", expiryOffset: -190 },
  { name: "Ramesh Chandran", category: "Ordinary Member", join: "2016-11-30", status: "suspended", expiryOffset: 200 },
  { name: "Deepa Varma", category: "Family Member", join: "2023-01-20", expiryOffset: 240 }, // family head
  { name: "Sanjay Varma", category: "Family Member", join: "2023-01-20", expiryOffset: 240, head: 10 },
  { name: "Aarav Varma", category: "Family Member", join: "2023-01-20", expiryOffset: 240, head: 10 },
  { name: "Mohan Ramasamy", category: "Senior Member", join: "2005-05-14", expiryOffset: 320 },
];

function buildMembers(): M[] {
  const out = [...showcase];
  const used = new Set(out.map((m) => m.name));
  const cats = ["Ordinary Member", "Ordinary Member", "Ordinary Member", "Life Member", "Family Member", "Senior Member"];
  let i = 0;
  while (out.length < 40) {
    const name = `${FIRST[(i * 7 + 3) % FIRST.length]} ${LAST[(i * 5 + 1) % LAST.length]}`;
    i++;
    if (used.has(name)) continue;
    used.add(name);
    const cat = cats[out.length % cats.length];
    const k = out.length;
    out.push({
      name,
      category: cat,
      join: `${2008 + (k % 16)}-${String(1 + (k % 12)).padStart(2, "0")}-${String(1 + ((k * 3) % 27)).padStart(2, "0")}`,
      expiryOffset: cat === "Life Member" ? undefined : k % 9 === 0 ? -(20 + k) : 45 + ((k * 37) % 320),
      expiry: cat === "Life Member" ? "2099-12-31" : undefined,
      status: k === 25 ? "suspended" : "active",
    });
  }
  return out;
}

async function main() {
  if (reset) await resetDb();
  const seeded = await one(`SELECT value FROM meta WHERE key='seeded'`);
  if (seeded) {
    console.log("Database already seeded. Use --reset to wipe and reseed.");
    process.exit(0);
  }
  console.log(`Seeding (${await dbKind()}) ...`);
  const creds: { id: string; pw: string; role: string; name: string }[] = [];
  const members = buildMembers();

  // Committee tester members (so committee accounts can try member-facing features)
  const committee: M[] = ["Rohit Balakrishnan", "Sunita Govindan", "Murali Naidu"].map((name, i): M => ({
    name, category: "Ordinary Member", join: "2020-01-0" + (i + 1), expiryOffset: 200 + i * 30, status: "active" as const,
  }));
  const all: M[] = [...members, ...committee];

  const ids: number[] = [];
  for (let i = 0; i < all.length; i++) {
    const m = all[i];
    const mid = `SGIA-DEMO-${String(i + 1).padStart(4, "0")}`;
    const first = m.name.split(" ")[0].toLowerCase();
    const last = m.name.split(" ").slice(-1)[0].toLowerCase();
    const expiry = m.expiry ?? addDays(today, m.expiryOffset ?? 365);
    const row = await one<{ id: number }>(
      `INSERT INTO members(membership_id,name,category,status,join_date,expiry_date,email,mobile,qr_token,avatar_hue,family_head_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
      [mid, m.name, m.category, m.status ?? "active", m.join, expiry, `${first}.${last}${i + 1}@example.com`, `+65 0000 ${String(1000 + i).slice(-4)} (fictional)`,
       newToken(), (i * 47) % 360, m.head ? ids[m.head - 1] : null],
    );
    ids.push(row!.id);
    const pw = newPassword();
    await q(`INSERT INTO accounts(login_id,password_hash,role,member_id,display_name) VALUES ($1,$2,'member',$3,$4)`, [mid, await hashPassword(pw), row!.id, m.name]);
    creds.push({ id: mid, pw, role: "member", name: m.name });
  }

  // Staff / admin / committee accounts
  const staff: [string, string, string, number | null][] = [
    ["SGIA-STAFF-01", "staff", "Gate Staff One", null],
    ["SGIA-STAFF-02", "staff", "Gate Staff Two", null],
    ["SGIA-ADMIN-01", "admin", "SGIA Administrator", null],
    ["SGIA-COMM-01", "committee", committee[0].name, ids[40]],
    ["SGIA-COMM-02", "committee", committee[1].name, ids[41]],
    ["SGIA-COMM-03", "committee", committee[2].name, ids[42]],
  ];
  for (const [login, role, name, mid] of staff) {
    const pw = newPassword(14);
    await q(`INSERT INTO accounts(login_id,password_hash,role,member_id,display_name) VALUES ($1,$2,$3,$4,$5)`, [login, await hashPassword(pw), role, mid, name]);
    creds.push({ id: login, pw, role, name });
  }

  // Announcements
  const ann: [string, string, string, string, string?][] = [
    ["Annual General Meeting 2026", "The SGIA AGM will be held on 29 November 2026 at the clubhouse. Members are invited to submit agenda items by 15 November. (DEMO content)", "Notices", "published"],
    ["Deepavali Celebration – Registration Open", "Join us for an evening of lights, music, dance and food. Family and friends are welcome. Register under Events. (DEMO content)", "Events", "published"],
    ["Cricket Championship Fixtures Released", "Fixtures for the inter-club cricket championship are now available. Captains, please confirm your squads by Friday. (DEMO content)", "Events", "published"],
    ["Facility Maintenance Notice", "Selected sports facilities will be temporarily closed for maintenance. Outdoor nets remain open. (DEMO content)", "Notices", "published"],
    ["Membership Renewal Reminder", "Members whose membership expires within 30 days will receive reminders in the app. Renewal in this prototype is a demonstration only. (DEMO content)", "Notices", "published"],
    ["Community Volunteers Needed", "We are looking for volunteers for upcoming community events. Sign up at the front desk. (DEMO content)", "Community", "published"],
    ["Draft: New Year Dinner", "Details to be confirmed. (DEMO draft)", "Events", "draft"],
    ["Scheduled: Youth Wing Orientation", "Orientation for new Youth Wing members. (DEMO scheduled)", "Community", "scheduled"],
    ["Archived: Last Year's Sports Day Results", "Results from the previous Family Sports Day. (DEMO archived)", "Events", "archived"],
  ];
  for (let i = 0; i < ann.length; i++) {
    const [title, body, category, state] = ann[i];
    await q(
      `INSERT INTO announcements(title,body,category,state,publish_at,published_at,author,created_at)
       VALUES ($1,$2,$3,$4,$5,$6,'SGIA Administrator', now() - make_interval(days => $7))`,
      [title, body, category, state, state === "scheduled" ? new Date(Date.now() + 86400000) : null, state === "published" || state === "archived" ? new Date(Date.now() - (i + 1) * 86400000 * 2) : null, i * 2 + 1],
    );
  }

  // Events (SGT)
  const ev: [string, string, string, string, string, number, number][] = [
    ["Members Networking Evening", addDays(today, 11), "18:30", "Clubhouse Function Room", "Meet fellow members over light refreshments. Ideal for new members to get acquainted with the SGIA community. (DEMO event)", 30, 120],
    ["SGIA Deepavali Celebration", "2026-11-08", "17:00", "Main Hall", "A celebration of lights with cultural performances, music and a community dinner. (DEMO event)", 25, 250],
    ["Cricket Championship", "2026-11-21", "08:00", "SGIA Cricket Ground", "Two days of inter-club T25 cricket. Spectators welcome; refreshments available at the F&B area. (DEMO event)", 140, 400],
    ["Annual General Meeting", "2026-11-29", "10:00", "Main Hall", "Annual General Meeting for all voting members. Agenda circulated two weeks prior. (DEMO event)", 215, 200],
    ["Family Sports Day", "2026-12-12", "09:00", "Sports Field & Courts", "A day of friendly family games, relay races and fun for all ages. (DEMO event)", 100, 300],
  ];
  const evIds: number[] = [];
  for (const [title, d, t, venue, desc, hue, cap] of ev) {
    const r = await one<{ id: number }>(
      `INSERT INTO events(title,starts_at,venue,description,hue,capacity) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [title, `${d}T${t}:00+08:00`, venue, desc, hue, cap],
    );
    evIds.push(r!.id);
  }
  for (const mi of [0, 1, 2, 3, 9, 40]) await q(`INSERT INTO event_registrations(event_id,member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [evIds[1], ids[mi]]);
  for (const mi of [0, 4, 5]) await q(`INSERT INTO event_registrations(event_id,member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [evIds[2], ids[mi]]);

  // Facilities (placeholders until SGIA supplies approved content)
  const fac: [string, string, string, string, string][] = [
    ["Cricket Ground", "Cricket ground", "Turf ground with practice nets. PLACEHOLDER description pending approved SGIA content.", "Daily 7:00 am – 7:00 pm (placeholder)", "admin@sgia.sg"],
    ["Sports Courts & Facilities", "Sports facilities", "Multi-purpose sports facilities. PLACEHOLDER description pending approved SGIA content.", "Daily 7:00 am – 10:00 pm (placeholder)", "admin@sgia.sg"],
    ["Function Hall & Event Spaces", "Function & event spaces", "Spaces for celebrations, meetings and community gatherings. PLACEHOLDER description pending approved SGIA content.", "By arrangement (placeholder)", "admin@sgia.sg"],
    ["Food & Beverage Area", "Food & beverage", "Clubhouse dining and refreshments. PLACEHOLDER description pending approved SGIA content.", "Daily 11:00 am – 10:00 pm (placeholder)", "admin@sgia.sg"],
  ];
  for (const f of fac) await q(`INSERT INTO facilities(name,kind,description,hours,contact) VALUES ($1,$2,$3,$4,$5)`, f);

  // Starter in-app notifications
  for (const mi of [0, 2, 3, 4, 5]) {
    await q(`INSERT INTO notifications(member_id,kind,title,body,url) VALUES ($1,'announcement','Welcome to SGIA Connect (DEMO)','This is a demonstration notification.', '/notifications')`, [ids[mi]]);
  }

  await q(`INSERT INTO meta(key,value) VALUES ('seeded', $1)`, [new Date().toISOString()]);

  const credFile = process.env.CREDENTIALS_FILE || path.join(process.cwd(), ".secrets", "demo-credentials.md");
  fs.mkdirSync(path.dirname(credFile), { recursive: true });
  const lines = ["# SGIA Connect demo credentials (DO NOT COMMIT, DO NOT EMAIL IN PLAIN TEXT)", `Generated ${new Date().toISOString()}`, "", "| Login ID | Password | Role | Name |", "|---|---|---|---|"];
  for (const c of creds) lines.push(`| ${c.id} | ${c.pw} | ${c.role} | ${c.name} |`);
  fs.writeFileSync(credFile, lines.join("\n") + "\n", { mode: 0o600 });
  console.log(`Seeded ${all.length} members, ${staff.length} staff/admin/committee accounts. Credentials: ${credFile}`);
  process.exit(0);
}
main().catch((e) => { console.error(e); process.exit(1); });
