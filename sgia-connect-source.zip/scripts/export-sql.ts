/* Exports schema + current seeded data as plain SQL (hashes only, never plaintext passwords).
   Usage: PGLITE_DIR=<seeded dir> tsx scripts/export-sql.ts <out.sql> */
import fs from "node:fs";
import { q } from "../src/lib/db";
import { SCHEMA_SQL } from "../src/lib/schema";

const lit = (v: unknown): string => {
  if (v === null || v === undefined) return "NULL";
  if (v instanceof Date) return `'${v.toISOString()}'`;
  if (typeof v === "number") return String(v);
  if (typeof v === "boolean") return v ? "true" : "false";
  return `'${String(v).replace(/'/g, "''")}'`;
};
const TABLES = ["members", "accounts", "announcements", "events", "event_registrations", "facilities", "notifications", "meta"];
const SERIAL = ["members", "accounts", "announcements", "events", "facilities", "notifications"];

async function main() {
  const out: string[] = ["-- SGIA Connect demo setup (synthetic data only)", SCHEMA_SQL.trim(), ""];
  for (const t of TABLES) {
    const rows = await q<Record<string, unknown>>(`SELECT * FROM ${t} ORDER BY 1`);
    if (!rows.length) continue;
    const cols = Object.keys(rows[0]);
    out.push(`INSERT INTO ${t} (${cols.join(",")}) VALUES`);
    out.push(rows.map((r) => `(${cols.map((c) => lit(r[c])).join(",")})`).join(",\n") + ";");
  }
  for (const t of SERIAL) out.push(`SELECT setval(pg_get_serial_sequence('${t}','id'), (SELECT COALESCE(max(id),1) FROM ${t}));`);
  out.push("ALTER TABLE members ENABLE ROW LEVEL SECURITY;");
  for (const t of ["accounts","sessions","rate_limits","audit_log","verifications","announcements","attachments","announcement_reads","events","event_registrations","facilities","notifications","push_subscriptions","delivery_log","reminder_log","renewal_requests","feedback","meta"]) out.push(`ALTER TABLE ${t} ENABLE ROW LEVEL SECURITY;`);
  fs.writeFileSync(process.argv[2], out.join("\n") + "\n", { mode: 0o600 });
  console.log("written", process.argv[2], fs.statSync(process.argv[2]).size, "bytes");
  process.exit(0);
}
main();
