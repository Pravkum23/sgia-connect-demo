import { Logo } from "./Logo";
import { Avatar } from "./Status";
import { StatusBadge } from "./Status";
import { fmtDate, type MemberStatus } from "@/lib/status";

export function MemberCard({ m, qrSvg, status }: {
  m: { name: string; membership_id: string; category: string; expiry_date: string; join_date: string; avatar_hue: number; lifetime: boolean };
  qrSvg: string; status: MemberStatus;
}) {
  return (
    <div className="relative overflow-hidden rounded-3xl text-white p-5 sm:p-6 shadow-[0_12px_40px_rgba(0,31,61,.35)] bg-[linear-gradient(135deg,#001f3d_0%,#0d3156_55%,#17446f_100%)]">
      <div aria-hidden className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-cyan/20 blur-2xl" />
      <div aria-hidden className="absolute inset-0 grid place-items-center pointer-events-none select-none">
        <span className="text-[6rem] sm:text-[8rem] font-black tracking-widest text-white/[0.06] -rotate-12">DEMO</span>
      </div>
      <div className="relative flex items-start justify-between gap-3">
        <div className="bg-white rounded-lg px-2.5 py-1.5"><Logo height={34} /></div>
        <span className="text-[11px] font-bold tracking-widest bg-cyan text-navy rounded px-2 py-1">DEMO CARD</span>
      </div>
      <div className="relative mt-5 flex gap-4 items-center">
        <Avatar name={m.name} hue={m.avatar_hue} size={64} />
        <div className="min-w-0">
          <p className="text-xs uppercase tracking-widest text-white/70">Member</p>
          <p className="text-2xl font-bold leading-tight">{m.name}</p>
          <p className="text-cyan font-medium">{m.category}</p>
        </div>
      </div>
      <div className="relative mt-5 grid grid-cols-[1fr_auto] gap-4 items-end">
        <dl className="space-y-2 text-sm">
          <div><dt className="text-white/70 text-xs uppercase tracking-wider">Membership ID</dt><dd className="font-mono text-lg font-bold tracking-wide">{m.membership_id}</dd></div>
          <div><dt className="text-white/70 text-xs uppercase tracking-wider">Valid</dt><dd className="font-medium">{fmtDate(m.join_date)} – {m.lifetime ? "Lifetime" : fmtDate(m.expiry_date)}</dd></div>
          <div><StatusBadge status={status} /></div>
        </dl>
        <div className="bg-white rounded-xl p-2 w-32 h-32 sm:w-36 sm:h-36 [&>svg]:w-full [&>svg]:h-full" role="img" aria-label="Your personal membership QR code" dangerouslySetInnerHTML={{ __html: qrSvg }} />
      </div>
      <p className="relative mt-4 text-[11px] text-white/60">Demonstration credential for SGIA Management Committee testing. Not valid for entry or benefits.</p>
    </div>
  );
}
