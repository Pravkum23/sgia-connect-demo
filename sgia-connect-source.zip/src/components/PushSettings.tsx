"use client";
import { useCallback, useEffect, useState } from "react";
import { Icon } from "./Icon";

type Attempt = { outcome: string; status?: number; detail?: string };

function b64ToU8(b64: string) {
  const pad = "=".repeat((4 - (b64.length % 4)) % 4);
  const raw = atob((b64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

export function PushSettings({ showTest = false }: { showTest?: boolean }) {
  const [supported, setSupported] = useState(true);
  const [perm, setPerm] = useState<NotificationPermission | "unsupported">("default");
  const [subscribed, setSubscribed] = useState(false);
  const [ios, setIos] = useState(false);
  const [standalone, setStandalone] = useState(false);
  const [serverOk, setServerOk] = useState(true);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [attempts, setAttempts] = useState<Attempt[] | null>(null);

  const refresh = useCallback(async () => {
    const hasSw = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;
    setSupported(hasSw);
    const ua = navigator.userAgent;
    setIos(/iPad|iPhone|iPod/.test(ua) || (ua.includes("Mac") && navigator.maxTouchPoints > 1));
    setStandalone(window.matchMedia("(display-mode: standalone)").matches || (navigator as unknown as { standalone?: boolean }).standalone === true);
    if (!hasSw) { setPerm("unsupported"); return; }
    setPerm(Notification.permission);
    try {
      const reg = await navigator.serviceWorker.ready;
      setSubscribed(!!(await reg.pushManager.getSubscription()));
    } catch { /* ignore */ }
    const k = await fetch("/api/push/key").then((r) => r.json()).catch(() => ({ configured: false }));
    setServerOk(!!k.configured);
  }, []);
  useEffect(() => { const t = setTimeout(refresh, 0); return () => clearTimeout(t); }, [refresh]);

  async function enable() {
    setBusy(true); setMsg("");
    try {
      const p = await Notification.requestPermission();
      setPerm(p);
      if (p !== "granted") { setMsg("Permission was not granted. You can change this in your browser or phone settings."); return; }
      const { key } = await fetch("/api/push/key").then((r) => r.json());
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(key) });
      const r = await fetch("/api/push/subscribe", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(sub.toJSON()) });
      if (!r.ok) throw new Error((await r.json()).error || "Subscription failed");
      setSubscribed(true); setMsg("Notifications are on for this device.");
    } catch (e) {
      setMsg("Could not turn on notifications: " + (e instanceof Error ? e.message : "unknown error"));
    } finally { setBusy(false); }
  }
  async function disable() {
    setBusy(true);
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        await fetch("/api/push/subscribe", { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ endpoint: sub.endpoint }) });
        await sub.unsubscribe();
      }
      setSubscribed(false); setMsg("Notifications are off for this device.");
    } finally { setBusy(false); }
  }
  async function test() {
    setBusy(true); setAttempts(null); setMsg("");
    const r = await fetch("/api/push/test", { method: "POST" });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) { setMsg(j.error || "Test failed."); return; }
    setAttempts(j.attempts);
  }

  const needsInstall = ios && !standalone;
  return (
    <section className="card p-5 space-y-4" aria-labelledby="push-h">
      <div className="flex items-center gap-3"><Icon name="bell" className="text-navy-600" /><h2 id="push-h" className="h2">Push notifications</h2></div>
      {!supported && <p className="rounded-xl bg-warn-bg text-warn p-3 text-sm">This browser does not support web push. You will still see all alerts inside the app&apos;s notification centre.</p>}
      {needsInstall && (
        <div className="rounded-xl bg-pale p-3 text-sm text-navy-700 space-y-1">
          <p className="font-bold">iPhone / iPad: install the app first</p>
          <p>Apple only allows web push for apps added to the Home Screen. In Safari tap <strong>Share</strong> → <strong>Add to Home Screen</strong>, open SGIA Connect from your Home Screen, then return here to turn on notifications (iOS 16.4 or later).</p>
        </div>
      )}
      {!serverOk && <p className="rounded-xl bg-warn-bg text-warn p-3 text-sm">Push is not configured on the server yet.</p>}
      <p className="text-sm text-slate">Status: <strong className="text-navy">{perm === "unsupported" ? "Not supported" : perm === "granted" ? (subscribed ? "On for this device" : "Allowed, not subscribed") : perm === "denied" ? "Blocked in device settings" : "Not asked yet"}</strong></p>
      <div className="flex gap-3 flex-wrap">
        {!subscribed ? (
          <button className="btn-primary" onClick={enable} disabled={busy || !supported || needsInstall || !serverOk || perm === "denied"}>Turn on notifications</button>
        ) : (
          <button className="btn-ghost" onClick={disable} disabled={busy}>Turn off on this device</button>
        )}
        {(showTest || subscribed) && <button className="btn-cyan" onClick={test} disabled={busy}>Send me a test notification</button>}
      </div>
      {perm === "denied" && <p className="text-sm text-bad">Notifications are blocked. Open your browser/phone settings for this site and allow notifications, then reload.</p>}
      {msg && <p role="status" className="text-sm font-medium text-navy">{msg}</p>}
      {attempts && (
        <div className="rounded-xl border border-line p-3 text-sm space-y-2" role="status">
          <p className="font-bold text-navy">Delivery attempt result</p>
          <ul className="space-y-1">{attempts.map((a, i) => (<li key={i}><span className={a.outcome === "sent" ? "badge-green" : "badge-amber"}>{a.outcome}</span> <span className="text-slate">{a.status ? `HTTP ${a.status} · ` : ""}{a.detail}</span></li>))}</ul>
          <p className="text-slate">&ldquo;Sent&rdquo; means the push service accepted the message. It does not guarantee the notification was displayed or read.</p>
        </div>
      )}
      <p className="text-xs text-slate">Notifications cannot override your device&apos;s Silent Mode, Focus/Do Not Disturb, or notification settings. Important notices also appear in the in-app notification centre.</p>
    </section>
  );
}
