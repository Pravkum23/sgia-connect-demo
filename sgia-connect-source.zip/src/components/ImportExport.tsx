"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function ImportExport() {
  const r = useRouter(); const [csv, setCsv] = useState(""); const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null); const [busy, setBusy] = useState(false);
  async function imp() {
    setBusy(true); setMsg(null);
    const res = await fetch("/api/admin/members/import", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ csv }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) setMsg({ ok: false, t: j.error || "Failed." });
    else if (!j.ok) setMsg({ ok: false, t: "Nothing imported. " + j.errors.join(" ") });
    else { setMsg({ ok: true, t: `Imported ${j.created} synthetic members. Use "Reset password" on a member to issue login credentials.` }); setCsv(""); r.refresh(); }
  }
  return (
    <div className="card p-5 space-y-3">
      <div className="flex items-center justify-between gap-3 flex-wrap"><h2 className="h2">CSV import / export</h2><a className="btn-ghost btn-sm" href="/api/admin/members/export" download>Export members CSV</a></div>
      <p className="muted">Export contains no passwords or QR tokens. Import accepts synthetic records only (emails must end in @example.com). Columns: <code>name,category,email,mobile,join_date,expiry_date</code>.</p>
      <label className="label" htmlFor="csv">Paste CSV</label>
      <textarea id="csv" className="input py-3 min-h-28 font-mono text-sm" value={csv} onChange={(e) => setCsv(e.target.value)} placeholder={"name,category,email,mobile,join_date,expiry_date\nAsha Menon,Ordinary Member,asha@example.com,+65 0000 1111,2024-02-01,2026-12-31"} />
      <button className="btn-primary" onClick={imp} disabled={busy || !csv.trim()}>{busy ? "Importing…" : "Import CSV"}</button>
      {msg && <p role="status" className={`text-sm font-medium ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</p>}
    </div>
  );
}
