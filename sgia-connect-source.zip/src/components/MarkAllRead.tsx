"use client";
import { useRouter } from "next/navigation";
export function MarkAllRead() {
  const r = useRouter();
  return <button className="btn-ghost btn-sm" onClick={async () => { await fetch("/api/notifications", { method: "POST" }); r.refresh(); }}>Mark all as read</button>;
}
