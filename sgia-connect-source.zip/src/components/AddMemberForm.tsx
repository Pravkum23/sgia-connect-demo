"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/members-constants";

export function AddMemberForm({ today, nextYear }: { today: string; nextYear: string }) {
  const r = useRouter();
  const [f, setF] = useState({ name: "", category: CATEGORIES[0], email: "", mobile: "", join_date: today, expiry_date: nextYear });
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null); const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  async function go(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMsg(null);
    const res = await fetch("/api/admin/members", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...f, mobile: f.mobile || undefined }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) { setMsg({ ok: true, t: `Created ${j.membership_id}. Temporary password (shown once): ${j.temporaryPassword}` }); setF({ ...f, name: "", email: "" }); r.refresh(); } else setMsg({ ok: false, t: j.error || "Failed." });
  }
  return (
    <form onSubmit={go} className="card p-5 grid gap-4 sm:grid-cols-2">
      <div><label className="label" htmlFor="am-name">Full name (fictional)</label><input id="am-name" className="input" value={f.name} onChange={set("name")} required /></div>
      <div><label className="label" htmlFor="am-cat">Category</label><select id="am-cat" className="input" value={f.category} onChange={set("category")}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
      <div><label className="label" htmlFor="am-email">Email (@example.com only)</label><input id="am-email" type="email" className="input" value={f.email} onChange={set("email")} placeholder="name@example.com" required /></div>
      <div><label className="label" htmlFor="am-mobile">Phone placeholder (optional)</label><input id="am-mobile" className="input" value={f.mobile} onChange={set("mobile")} placeholder="+65 0000 0000" /></div>
      <div><label className="label" htmlFor="am-join">Joining date</label><input id="am-join" type="date" className="input" value={f.join_date} onChange={set("join_date")} required /></div>
      <div><label className="label" htmlFor="am-exp">Expiry date</label><input id="am-exp" type="date" className="input" value={f.expiry_date} onChange={set("expiry_date")} required /></div>
      <div className="sm:col-span-2 space-y-3">
        <button className="btn-primary" disabled={busy}>{busy ? "Creating…" : "Create demo member"}</button>
        {msg && <p role="status" className={`text-sm font-medium break-all ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</p>}
      </div>
    </form>
  );
}
