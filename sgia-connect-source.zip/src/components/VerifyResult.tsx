"use client";
import { useState } from "react";
import { Avatar } from "./Status";
import { Icon } from "./Icon";
import { fmtDate, fmtDateTime, STATUS_LABEL, STATUS_TONE, type MemberStatus } from "@/lib/status";
import type { VerifyData } from "@/lib/verify";

const TONE = {
  green: { box: "bg-ok-bg border-[#9ad6b0] text-ok", big: "bg-ok text-white" },
  amber: { box: "bg-warn-bg border-[#f1d49a] text-warn", big: "bg-[#c77700] text-white" },
  red: { box: "bg-bad-bg border-[#f3c3be] text-bad", big: "bg-bad text-white" },
};

export function VerifyResult({ data, onDone }: { data: VerifyData; onDone?: () => void }) {
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [checked, setChecked] = useState<string | null>(null);

  if (!data.found || !data.member) {
    return (
      <div role="alert" className="rounded-2xl border bg-bad-bg border-[#f3c3be] p-6 text-bad text-center space-y-2">
        <div className="mx-auto h-16 w-16 rounded-full bg-bad text-white grid place-items-center"><Icon name="x" size={34} stroke={2.6} /></div>
        <p className="text-xl font-bold">Not recognised</p>
        <p className="text-sm">This code or ID does not match any SGIA Connect demo member.</p>
        {onDone && <button className="btn-primary mt-2" onClick={onDone}>Scan another</button>}
      </div>
    );
  }
  const m = data.member;
  const st = m.status as MemberStatus;
  const tone = TONE[STATUS_TONE[st]];
  const canCheckIn = STATUS_TONE[st] !== "red";

  async function checkIn() {
    setBusy(true); setMsg(null);
    const r = await fetch("/api/staff/checkin", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ memberId: m.id }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setChecked(j.at); setMsg({ ok: true, t: "Check-in recorded." }); } else setMsg({ ok: false, t: j.error || "Could not record check-in." });
  }

  return (
    <div className={`rounded-2xl border-2 overflow-hidden ${tone.box}`} data-testid="verify-result" data-status={st}>
      <div className={`${tone.big} px-5 py-4 flex items-center gap-3`}>
        <Icon name={STATUS_TONE[st] === "red" ? "x" : "check"} size={34} stroke={2.8} />
        <div><p className="text-2xl font-black leading-none">{STATUS_LABEL[st].toUpperCase()}</p>
          <p className="text-sm opacity-90">{st === "expiring" ? (m.days === 0 ? "Expires today" : `${m.days} day${m.days === 1 ? "" : "s"} remaining`) : st === "active" ? "Membership valid" : "Do not admit as a valid member"}</p></div>
      </div>
      <div className="bg-white text-navy p-5 space-y-4">
        <div className="flex gap-4 items-center"><Avatar name={m.name} hue={m.avatar_hue} size={72} />
          <div className="min-w-0"><p className="text-2xl font-bold leading-tight">{m.name}</p><p className="font-mono font-bold tracking-wide">{m.membership_id}</p><p className="text-slate">{m.category}</p></div></div>
        <dl className="grid grid-cols-2 gap-3 text-sm">
          <div><dt className="text-slate">Member since</dt><dd className="font-medium">{fmtDate(m.join_date)}</dd></div>
          <div><dt className="text-slate">Valid until</dt><dd className="font-medium">{m.lifetime ? "Lifetime" : fmtDate(m.expiry_date)}</dd></div>
          <div><dt className="text-slate">Last check-in</dt><dd className="font-medium">{checked ? fmtDateTime(checked) : data.lastCheckin ? fmtDateTime(data.lastCheckin) : "Never"}</dd></div>
          <div><dt className="text-slate">Last verified</dt><dd className="font-medium">{data.lastVerified ? fmtDateTime(data.lastVerified) : "First time"}</dd></div>
        </dl>
        <p className="text-xs text-slate">Status is read live from the SGIA Connect backend at the moment of scanning. DEMO data.</p>
        {msg && <p role="status" className={`rounded-xl px-4 py-3 text-sm font-medium ${msg.ok ? "bg-ok-bg text-ok" : "bg-bad-bg text-bad"}`}>{msg.t}</p>}
        <div className="flex gap-3 flex-wrap">
          <button className="btn-primary flex-1 min-w-40" onClick={checkIn} disabled={busy || !canCheckIn || !!checked}>{checked ? "Checked in" : canCheckIn ? "Record check-in" : "Check-in not allowed"}</button>
          {onDone && <button className="btn-ghost flex-1 min-w-40" onClick={onDone}>Scan another</button>}
        </div>
      </div>
    </div>
  );
}
