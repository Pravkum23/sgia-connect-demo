"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function EventRegister({ id, registered, full }: { id: number; registered: boolean; full: boolean }) {
  const router = useRouter(); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  async function go() {
    setBusy(true); setErr("");
    const r = await fetch(`/api/events/${id}/register`, { method: registered ? "DELETE" : "POST" });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) { setErr(j.error || "Something went wrong."); return; }
    router.refresh();
  }
  return (
    <div>
      <button onClick={go} disabled={busy || (full && !registered)} className={registered ? "btn-ghost" : "btn-primary"}>
        {busy ? "Please wait…" : registered ? "Cancel registration" : full ? "Event full" : "Register (DEMO)"}
      </button>
      {err && <p role="alert" className="text-bad text-sm mt-2">{err}</p>}
    </div>
  );
}
