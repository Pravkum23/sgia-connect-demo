"use client";
import { useState } from "react";

export function PasswordForm() {
  const [cur, setCur] = useState(""); const [next, setNext] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMsg(null);
    const r = await fetch("/api/auth/password", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ current: cur, next }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setMsg({ ok: true, text: "Password changed. Other devices have been signed out." }); setCur(""); setNext(""); }
    else setMsg({ ok: false, text: j.error || "Could not change password." });
  }
  return (
    <form onSubmit={submit} className="space-y-4">
      <div><label className="label" htmlFor="cur">Current password</label><input id="cur" type="password" className="input" autoComplete="current-password" value={cur} onChange={(e) => setCur(e.target.value)} required /></div>
      <div><label className="label" htmlFor="new">New password</label><input id="new" type="password" className="input" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} required minLength={10} /><p className="muted mt-1">At least 10 characters, with letters and numbers.</p></div>
      <div role="status" aria-live="polite" className={msg ? `rounded-xl px-4 py-3 text-sm font-medium ${msg.ok ? "bg-ok-bg text-ok" : "bg-bad-bg text-bad"}` : "sr-only"}>{msg?.text}</div>
      <button className="btn-primary" disabled={busy || !cur || !next}>{busy ? "Saving…" : "Change password"}</button>
    </form>
  );
}
