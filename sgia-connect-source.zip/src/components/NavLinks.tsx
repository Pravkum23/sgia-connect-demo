"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon } from "./Icon";
import type { NavItem } from "@/lib/nav";

function active(path: string, href: string) {
  return href === "/" ? path === "/" : path === href || path.startsWith(href + "/");
}

export function BottomNav({ items, unread }: { items: NavItem[]; unread: number }) {
  const path = usePathname();
  return (
    <nav aria-label="Main" className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-line pb-[env(safe-area-inset-bottom)]">
      <ul className="grid" style={{ gridTemplateColumns: `repeat(${items.length}, minmax(0,1fr))` }}>
        {items.map((it) => {
          const on = active(path, it.href);
          return (
            <li key={it.href}>
              <Link href={it.href} aria-current={on ? "page" : undefined} className={`relative flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium min-h-16 ${on ? "text-navy" : "text-slate"}`}>
                <span className={`relative grid place-items-center h-8 w-14 rounded-full ${on ? "bg-pale" : ""}`}>
                  <Icon name={it.icon} size={22} stroke={on ? 2.2 : 1.8} />
                  {it.icon === "bell" && unread > 0 && <span className="absolute top-0.5 right-2.5 min-w-4 h-4 px-1 rounded-full bg-bad text-white text-[10px] font-bold grid place-items-center">{unread > 9 ? "9+" : unread}</span>}
                </span>
                {it.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function SideNav({ items, extra, unread }: { items: NavItem[]; extra: NavItem[]; unread: number }) {
  const path = usePathname();
  const row = (it: NavItem) => {
    const on = active(path, it.href);
    return (
      <li key={it.href}>
        <Link href={it.href} aria-current={on ? "page" : undefined} className={`flex items-center gap-3 rounded-xl px-4 min-h-12 font-medium ${on ? "bg-navy text-white" : "text-navy-700 hover:bg-pale"}`}>
          <Icon name={it.icon} size={20} />
          <span className="flex-1">{it.label}</span>
          {it.icon === "bell" && unread > 0 && <span className="rounded-full bg-bad text-white text-xs font-bold px-2 py-0.5">{unread}</span>}
        </Link>
      </li>
    );
  };
  return (
    <nav aria-label="Main" className="hidden md:block w-64 shrink-0">
      <ul className="space-y-1 sticky top-24">{items.map(row)}</ul>
      {extra.length > 0 && <ul className="space-y-1 mt-6 pt-6 border-t border-line sticky top-[27rem]">{extra.map(row)}</ul>}
    </nav>
  );
}
