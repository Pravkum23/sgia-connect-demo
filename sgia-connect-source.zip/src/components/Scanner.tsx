"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { VerifyResult } from "./VerifyResult";
import { Icon } from "./Icon";
import type { VerifyData } from "@/lib/verify";

/** Accepts either a /verify/<token> URL (what our QR carries) or a bare token. */
export function extractToken(text: string): string {
  const t = text.trim();
  const m = t.match(/\/verify\/([A-Za-z0-9_-]{20,64})(?:[/?#]|$)/);
  return m ? m[1] : t;
}

export function Scanner() {
  const [phase, setPhase] = useState<"idle" | "starting" | "scanning" | "result">("idle");
  const [error, setError] = useState("");
  const [data, setData] = useState<VerifyData | null>(null);
  const [manual, setManual] = useState("");
  const [busy, setBusy] = useState(false);
  const scannerRef = useRef<import("html5-qrcode").Html5Qrcode | null>(null);
  const handled = useRef(false);

  const stop = useCallback(async () => {
    const s = scannerRef.current;
    scannerRef.current = null;
    if (s) { try { if (s.isScanning) await s.stop(); s.clear(); } catch { /* ignore */ } }
  }, []);
  useEffect(() => () => { stop(); }, [stop]);

  async function lookup(payload: Record<string, string>) {
    setBusy(true); setError("");
    try {
      const r = await fetch("/api/staff/verify", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
      const j = await r.json();
      if (!r.ok) { setError(j.error || "Lookup failed."); setPhase("idle"); return; }
      setData(j); setPhase("result");
    } catch { setError("Could not reach the server."); setPhase("idle"); }
    finally { setBusy(false); }
  }

  async function start() {
    setError(""); setData(null); handled.current = false; setPhase("starting");
    try {
      if (!navigator.mediaDevices?.getUserMedia) throw new Error("unsupported");
      const { Html5Qrcode } = await import("html5-qrcode");
      const sc = new Html5Qrcode("qr-reader", { verbose: false });
      scannerRef.current = sc;
      await sc.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: (w, h) => { const s = Math.floor(Math.min(w, h) * 0.75); return { width: s, height: s }; } },
        async (text) => {
          if (handled.current) return;
          handled.current = true;
          await stop();
          await lookup({ token: extractToken(text), method: "qr" });
        },
        () => {},
      );
      setPhase("scanning");
    } catch (e) {
      await stop();
      setPhase("idle");
      const name = e instanceof Error ? e.name + " " + e.message : "";
      setError(/NotAllowed|Permission/i.test(name) ? "Camera permission was denied. Allow camera access in your browser settings, or use manual lookup below." : /NotFound|unsupported|Devices/i.test(name) ? "No usable camera was found. Use manual lookup below." : "The camera could not be started. Use manual lookup below.");
    }
  }

  function reset() { stop(); setData(null); setPhase("idle"); setError(""); setManual(""); }

  return (
    <div className="space-y-6 max-w-xl">
      {phase !== "result" && (
        <section className="card p-5 space-y-4">
          <div id="qr-reader" className={phase === "scanning" || phase === "starting" ? "rounded-xl overflow-hidden bg-black min-h-64" : "hidden"} />
          {phase === "idle" && <div className="rounded-xl bg-pale grid place-items-center py-10 text-navy-600"><Icon name="scan" size={56} stroke={1.4} /><p className="mt-2 font-medium">Point the camera at a member&apos;s QR code</p></div>}
          {phase === "scanning" ? <button className="btn-ghost w-full" onClick={reset}>Stop camera</button> : <button className="btn-primary w-full text-lg min-h-14" onClick={start} disabled={phase === "starting" || busy}>{phase === "starting" ? "Starting camera…" : "Start camera scan"}</button>}
        </section>
      )}
      {error && <p role="alert" className="rounded-xl bg-bad-bg text-bad px-4 py-3 text-sm font-medium">{error}</p>}
      {phase !== "result" && (
        <form className="card p-5 space-y-3" onSubmit={(e) => { e.preventDefault(); if (manual.trim()) lookup({ membershipId: manual.trim(), method: "manual" }); }}>
          <h2 className="h2">Manual lookup</h2>
          <p className="muted">Use if the camera is unavailable or the QR code cannot be read.</p>
          <label className="label" htmlFor="mid">Membership ID</label>
          <input id="mid" className="input uppercase placeholder:normal-case" placeholder="SGIA-DEMO-0001" value={manual} onChange={(e) => setManual(e.target.value)} autoCapitalize="characters" autoCorrect="off" spellCheck={false} />
          <button className="btn-cyan w-full" disabled={busy || !manual.trim()}>{busy ? "Checking…" : "Look up member"}</button>
        </form>
      )}
      {phase === "result" && data && <VerifyResult data={data} onDone={reset} />}
    </div>
  );
}
