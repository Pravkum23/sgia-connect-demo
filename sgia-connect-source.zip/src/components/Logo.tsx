import fs from "node:fs";
import path from "node:path";

const CANDIDATES = ["sgia-logo.svg", "sgia-logo.png", "sgia-logo.webp", "sgia-logo.jpg"];
function findLogo(): string | null {
  for (const f of CANDIDATES) if (fs.existsSync(path.join(process.cwd(), "public", "brand", f))) return `/brand/${f}`;
  return null;
}

/**
 * Official SGIA logo (supplied by SGIA) at public/brand/sgia-logo.png – used unmodified, only margins trimmed.
 * Falls back to a plain typographic placeholder if the file is ever missing.
 */
export function Logo({ height = 44, onDark = false }: { height?: number; onDark?: boolean }) {
  const src = findLogo();
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={src} alt="Singapore Indian Association" style={{ height, width: "auto" }} />;
  }
  return (
    <div className={`flex items-center gap-2 ${onDark ? "text-white" : "text-navy"}`} style={{ height }} role="img" aria-label="Singapore Indian Association (logo placeholder)">
      <span className="font-black tracking-tight leading-none" style={{ fontSize: height * 0.7 }}>SGIA</span>
      <span className="text-[10px] leading-tight uppercase tracking-wider opacity-80 border-l border-current pl-2">Singapore Indian<br />Association</span>
    </div>
  );
}
