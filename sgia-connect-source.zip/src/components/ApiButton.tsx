"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function ApiButton({ url, method = "POST", payload, label, busyLabel, confirmText, className = "btn-ghost btn-sm", doneText }: {
  url: string; method?: string; payload?: unknown; label: string; busyLabel?: string; confirmText?: string; className?: string; doneText?: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  async function go() {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusy(true); setMsg(null);
    try {
      const r = await fetch(url, { method, headers: { "content-type": "application/json" }, body: payload === undefined ? undefined : JSON.stringify(payload) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ ok: false, t: j.error || "Failed." });
      else {
        const extra = j.temporaryPassword ? ` Temporary password (shown once): ${j.temporaryPassword}` : j.sent !== undefined ? ` Checked ${j.checked}, reminders sent ${j.sent}, already sent ${j.skipped}.` : "";
        setMsg({ ok: true, t: (doneText ?? "Done.") + extra });
        router.refresh();
      }
    } finally { setBusy(false); }
  }
  return (
    <span className="inline-flex flex-col gap-1">
      <button type="button" onClick={go} disabled={busy} className={className}>{busy ? busyLabel ?? "Working…" : label}</button>
      {msg && <span role="status" className={`text-xs font-medium break-all ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</span>}
    </span>
  );
}
