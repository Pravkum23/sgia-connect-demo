"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Icon } from "./Icon";

export function LoginForm() {
  const router = useRouter();
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [help, setHelp] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ loginId, password }) });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(j.error || "Sign-in failed. Please try again.");
        setBusy(false);
        return;
      }
      router.replace(j.next || "/");
      router.refresh();
    } catch {
      setError("Could not reach the server. Check your internet connection and try again.");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      <div>
        <label htmlFor="loginId" className="label">Membership ID</label>
        <div className="relative">
          <Icon name="user" className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-600" size={20} />
          <input id="loginId" name="username" className="input pl-12 uppercase placeholder:normal-case" placeholder="e.g. SGIA-DEMO-0001" autoComplete="username" autoCapitalize="characters" autoCorrect="off" spellCheck={false} required value={loginId} onChange={(e) => setLoginId(e.target.value)} aria-describedby={error ? "login-error" : undefined} aria-invalid={!!error} />
        </div>
      </div>
      <div>
        <label htmlFor="password" className="label">Password</label>
        <div className="relative">
          <Icon name="lock" className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-600" size={20} />
          <input id="password" name="password" type={show ? "text" : "password"} className="input pl-12 pr-14" placeholder="Password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} aria-describedby={error ? "login-error" : undefined} aria-invalid={!!error} />
          <button type="button" onClick={() => setShow((v) => !v)} className="absolute right-1.5 top-1/2 -translate-y-1/2 h-11 w-11 grid place-items-center rounded-lg text-navy-600 hover:bg-pale" aria-label={show ? "Hide password" : "Show password"} aria-pressed={show}>
            <Icon name={show ? "eyeoff" : "eye"} size={22} />
          </button>
        </div>
      </div>
      <div id="login-error" role="alert" aria-live="assertive" className={error ? "rounded-xl bg-bad-bg text-bad px-4 py-3 text-sm font-medium" : "sr-only"}>{error}</div>
      <button type="submit" className="btn-primary w-full text-lg min-h-14" disabled={busy || !loginId || !password}>{busy ? "Signing in…" : "Login"}</button>
      <div className="text-center">
        <button type="button" onClick={() => setHelp((v) => !v)} className="text-navy-600 underline underline-offset-4 font-medium min-h-11 px-3" aria-expanded={help}>Forgot password?</button>
      </div>
      {help && (
        <div className="card-pale p-4 text-sm text-navy-700 space-y-2">
          <p><strong>Demo environment:</strong> passwords cannot be reset by email in this prototype. Please ask the SGIA Administrator to issue you a new temporary password.</p>
          <p>In the production app, members would reset their password through a secure link sent to their registered email address.</p>
        </div>
      )}
    </form>
  );
}
