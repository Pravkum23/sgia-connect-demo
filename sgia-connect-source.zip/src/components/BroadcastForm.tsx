"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/members-constants";

export function BroadcastForm() {
  const r = useRouter(); const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null); const [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    if (!window.confirm("Send this notice to the selected members?")) return;
    setBusy(true); setMsg(null);
    const res = await fetch("/api/admin/notify", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ title: fd.get("title"), body: fd.get("body"), audience: fd.get("audience") }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) { setMsg({ ok: true, t: `Sent: ${j.recipients} in-app notices created; web push accepted for ${j.pushSent}. (Accepted ≠ displayed.)` }); (e.target as HTMLFormElement).reset(); r.refresh(); } else setMsg({ ok: false, t: j.error || "Failed." });
  }
  return (
    <form onSubmit={go} className="card p-5 grid gap-4 sm:grid-cols-2">
      <div><label className="label" htmlFor="b-title">Title</label><input id="b-title" name="title" className="input" required minLength={3} maxLength={80} /></div>
      <div><label className="label" htmlFor="b-aud">Audience</label><select id="b-aud" name="audience" className="input"><option value="all">All members</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="b-body">Message</label><textarea id="b-body" name="body" className="input py-3" required minLength={3} maxLength={240} /></div>
      <div className="sm:col-span-2 space-y-3"><button className="btn-primary" disabled={busy}>{busy ? "Sending…" : "Send administrative notice"}</button>{msg && <p role="status" className={`text-sm font-medium ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</p>}</div>
    </form>
  );
}
