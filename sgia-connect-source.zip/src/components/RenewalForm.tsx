"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export function RenewalForm({ disabled }: { disabled: boolean }) {
  const r = useRouter(); const [note, setNote] = useState(""); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState("");
  async function go(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMsg("");
    const res = await fetch("/api/renewal", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ note }) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) { setMsg("Demo renewal request sent. An administrator can approve it to demonstrate the status change."); setNote(""); r.refresh(); } else setMsg(j.error || "Could not send request.");
  }
  return (
    <form onSubmit={go} className="card p-5 space-y-4">
      <div><label className="label" htmlFor="note">Note to SGIA office (optional)</label><textarea id="note" className="input py-3 min-h-24" maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} /></div>
      <button className="btn-primary w-full" disabled={busy || disabled}>{busy ? "Sending…" : "Request renewal (DEMO)"}</button>
      {msg && <p role="status" className="text-sm font-medium text-navy">{msg}</p>}
    </form>
  );
}
