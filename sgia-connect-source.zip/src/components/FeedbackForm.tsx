"use client";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

const KINDS = ["Bug", "Design suggestion", "Missing feature", "Accessibility problem", "Notification issue"];

export function FeedbackForm() {
  const path = usePathname();
  const [kind, setKind] = useState(KINDS[0]);
  const [page, setPage] = useState("");
  const [message, setMessage] = useState("");
  const [attach, setAttach] = useState(true);
  const [device, setDevice] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  useEffect(() => {
    const t = setTimeout(() => {
    setDevice(`${navigator.userAgent} | viewport ${window.innerWidth}x${window.innerHeight} | ${window.matchMedia("(display-mode: standalone)").matches ? "installed PWA" : "browser tab"}`);
    const ref = document.referrer ? new URL(document.referrer).pathname : "";
    setPage(ref && ref !== path ? ref : "");
    }, 0);
    return () => clearTimeout(t);
  }, [path]);
  async function go(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setMsg(null);
    const r = await fetch("/api/feedback", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kind, page, message, device: attach ? device : "" }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setMsg({ ok: true, t: "Thank you – your feedback was submitted." }); setMessage(""); } else setMsg({ ok: false, t: j.error || "Could not submit." });
  }
  return (
    <form onSubmit={go} className="card p-5 space-y-4">
      <div><label className="label" htmlFor="kind">Type of feedback</label><select id="kind" className="input" value={kind} onChange={(e) => setKind(e.target.value)}>{KINDS.map((k) => <option key={k}>{k}</option>)}</select></div>
      <div><label className="label" htmlFor="page">Page or screen (optional)</label><input id="page" className="input" value={page} onChange={(e) => setPage(e.target.value)} placeholder="e.g. /membership" maxLength={120} /></div>
      <div><label className="label" htmlFor="message">Description</label><textarea id="message" className="input py-3 min-h-36" required minLength={5} maxLength={2000} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="What happened, or what would you like to see?" /></div>
      <label className="flex items-start gap-3 text-sm text-slate"><input type="checkbox" className="mt-1 h-5 w-5" checked={attach} onChange={(e) => setAttach(e.target.checked)} />Include my device and browser details to help diagnose the issue.</label>
      <div role="status" aria-live="polite" className={msg ? `rounded-xl px-4 py-3 text-sm font-medium ${msg.ok ? "bg-ok-bg text-ok" : "bg-bad-bg text-bad"}` : "sr-only"}>{msg?.t}</div>
      <button className="btn-primary w-full" disabled={busy || message.trim().length < 5}>{busy ? "Submitting…" : "Submit feedback"}</button>
    </form>
  );
}
