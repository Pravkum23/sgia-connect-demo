import { STATUS_LABEL, STATUS_TONE, type MemberStatus } from "@/lib/status";
import { Icon } from "./Icon";

export function StatusBadge({ status }: { status: MemberStatus }) {
  const tone = STATUS_TONE[status];
  const cls = tone === "green" ? "badge-green" : tone === "amber" ? "badge-amber" : "badge-red";
  return (
    <span className={cls}>
      <Icon name={tone === "red" ? "x" : "check"} size={14} stroke={2.6} />
      {STATUS_LABEL[status]}
    </span>
  );
}

export function Avatar({ name, hue = 210, size = 56 }: { name: string; hue?: number; size?: number }) {
  const initials = name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  return (
    <div
      className="rounded-full grid place-items-center font-bold text-white shrink-0 select-none"
      style={{ width: size, height: size, fontSize: size * 0.38, background: `linear-gradient(135deg, hsl(${hue} 55% 38%), hsl(${(hue + 30) % 360} 60% 28%))` }}
      aria-hidden="true"
    >
      {initials}
    </div>
  );
}
