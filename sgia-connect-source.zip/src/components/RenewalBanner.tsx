import Link from "next/link";
import type { MemberStatus } from "@/lib/status";
import { fmtDate } from "@/lib/status";
import { Icon } from "./Icon";

export function RenewalBanner({ status, days, expiry }: { status: MemberStatus; days: number; expiry: string }) {
  if (status === "active") return null;
  if (status === "suspended" || status === "inactive")
    return (
      <div role="alert" className="rounded-2xl bg-bad-bg border border-[#f3c3be] p-4 flex gap-3 text-bad">
        <Icon name="x" className="mt-0.5 shrink-0" />
        <div><p className="font-bold">Your membership is {status === "suspended" ? "suspended" : "deactivated"}</p><p className="text-sm">Please contact the SGIA office. Your digital card will show this status when scanned.</p></div>
      </div>
    );
  const expired = status === "expired";
  const msg = expired ? `Your membership expired on ${fmtDate(expiry)}.` : days === 0 ? "Your membership expires today." : `Your membership expires in ${days} day${days === 1 ? "" : "s"} (${fmtDate(expiry)}).`;
  return (
    <div role="alert" className={`rounded-2xl p-4 flex gap-3 items-center flex-wrap border ${expired ? "bg-bad-bg border-[#f3c3be] text-bad" : "bg-warn-bg border-[#f1d49a] text-warn"}`}>
      <Icon name="bell" className="shrink-0" />
      <div className="flex-1 min-w-48"><p className="font-bold">{expired ? "Membership expired" : "Renewal due soon"}</p><p className="text-sm">{msg}</p></div>
      <Link href="/renewal" className="btn-primary btn-sm">Renew (DEMO)</Link>
    </div>
  );
}
