"use client";
import { useRouter } from "next/navigation";
import { Icon } from "./Icon";
export function LogoutButton() {
  const router = useRouter();
  return (
    <button className="btn-ghost w-full sm:w-auto" onClick={async () => { await fetch("/api/auth/logout", { method: "POST" }); router.replace("/login"); router.refresh(); }}>
      <Icon name="logout" size={20} />Log out
    </button>
  );
}
