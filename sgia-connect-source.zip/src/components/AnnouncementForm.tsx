"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/members-constants";

export function AnnouncementForm() {
  const r = useRouter();
  const [action, setAction] = useState("draft");
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null); const [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg(null);
    const fd = new FormData(e.currentTarget); fd.set("action", action);
    const res = await fetch("/api/admin/announcements", { method: "POST", body: fd });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) { setMsg({ ok: true, t: j.delivery ? `Published. In-app notices created for ${j.delivery.recipients} members; push accepted for ${j.delivery.pushSent}.` : "Saved." }); (e.target as HTMLFormElement).reset(); setAction("draft"); r.refresh(); }
    else setMsg({ ok: false, t: j.error || "Failed." });
  }
  return (
    <form onSubmit={go} className="card p-5 grid gap-4 sm:grid-cols-2">
      <div className="sm:col-span-2"><label className="label" htmlFor="a-title">Title</label><input id="a-title" name="title" className="input" required minLength={3} maxLength={120} /></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="a-body">Description</label><textarea id="a-body" name="body" className="input py-3 min-h-32" required minLength={3} maxLength={5000} /></div>
      <div><label className="label" htmlFor="a-cat">Category</label><select id="a-cat" name="category" className="input"><option>Notices</option><option>Events</option><option>Community</option></select></div>
      <div><label className="label" htmlFor="a-aud">Audience</label><select id="a-aud" name="audience" className="input"><option value="all">All members</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="a-files">Attachments (images or PDF, max 2 MB each, up to 4)</label><input id="a-files" name="files" type="file" multiple accept="image/png,image/jpeg,image/gif,image/webp,application/pdf" className="input py-2.5" /></div>
      <div><label className="label" htmlFor="a-act">Publication</label><select id="a-act" className="input" value={action} onChange={(e) => setAction(e.target.value)}><option value="draft">Save as draft</option><option value="publish">Publish now</option><option value="schedule">Schedule…</option></select></div>
      {action === "schedule" && <div><label className="label" htmlFor="a-at">Publish at (Singapore time)</label><input id="a-at" name="publish_at" type="datetime-local" className="input" required /></div>}
      <div className="sm:col-span-2 space-y-3"><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : action === "publish" ? "Publish announcement" : action === "schedule" ? "Schedule announcement" : "Save draft"}</button>
        {msg && <p role="status" className={`text-sm font-medium ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</p>}</div>
    </form>
  );
}
