"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function EventForm() {
  const r = useRouter(); const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null); const [busy, setBusy] = useState(false);
  async function go(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg(null);
    const fd = new FormData(e.currentTarget);
    const cap = String(fd.get("capacity") || "");
    const body = { title: fd.get("title"), starts_at: fd.get("starts_at"), venue: fd.get("venue"), description: fd.get("description"), capacity: cap ? Number(cap) : null };
    const res = await fetch("/api/admin/events", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) { setMsg({ ok: true, t: "Event created." }); (e.target as HTMLFormElement).reset(); r.refresh(); } else setMsg({ ok: false, t: j.error || "Failed." });
  }
  return (
    <form onSubmit={go} className="card p-5 grid gap-4 sm:grid-cols-2">
      <div className="sm:col-span-2"><label className="label" htmlFor="ev-title">Title</label><input id="ev-title" name="title" className="input" required minLength={3} /></div>
      <div><label className="label" htmlFor="ev-start">Starts (Singapore time)</label><input id="ev-start" name="starts_at" type="datetime-local" className="input" required /></div>
      <div><label className="label" htmlFor="ev-venue">Venue</label><input id="ev-venue" name="venue" className="input" required /></div>
      <div className="sm:col-span-2"><label className="label" htmlFor="ev-desc">Description</label><textarea id="ev-desc" name="description" className="input py-3 min-h-24" required minLength={3} /></div>
      <div><label className="label" htmlFor="ev-cap">Capacity (optional)</label><input id="ev-cap" name="capacity" type="number" min={1} className="input" /></div>
      <div className="sm:col-span-2 space-y-3"><button className="btn-primary" disabled={busy}>{busy ? "Creating…" : "Create event"}</button>{msg && <p role="status" className={`text-sm font-medium ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</p>}</div>
    </form>
  );
}
