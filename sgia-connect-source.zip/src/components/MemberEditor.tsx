"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/members-constants";
import { ApiButton } from "./ApiButton";

function dateOffset(days: number) { return new Date(Date.now() + days * 86400000 + 8 * 3600000).toISOString().slice(0, 10); }

export function MemberEditor({ m }: { m: { id: number; name: string; category: string; email: string; expiry_date: string; status: string; deactivated: boolean } }) {
  const r = useRouter();
  const [f, setF] = useState({ name: m.name, category: m.category, email: m.email, expiry_date: m.expiry_date });
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null); const [busy, setBusy] = useState(false);
  async function patch(data: Record<string, unknown>, done: string) {
    setBusy(true); setMsg(null);
    const res = await fetch(`/api/admin/members/${m.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(data) });
    const j = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok) { setMsg({ ok: true, t: done }); r.refresh(); } else setMsg({ ok: false, t: j.error || "Failed." });
  }
  const quick = (days: number) => setF({ ...f, expiry_date: dateOffset(days) });
  return (
    <div className="space-y-6">
      <form className="card p-5 grid gap-4 sm:grid-cols-2" onSubmit={(e) => { e.preventDefault(); patch(f, "Saved."); }}>
        <div><label className="label" htmlFor="e-name">Full name</label><input id="e-name" className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><label className="label" htmlFor="e-cat">Category</label><select id="e-cat" className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label className="label" htmlFor="e-email">Email (@example.com)</label><input id="e-email" className="input" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="label" htmlFor="e-exp">Expiry date</label><input id="e-exp" type="date" className="input" value={f.expiry_date} onChange={(e) => setF({ ...f, expiry_date: e.target.value })} />
          <div className="flex gap-2 flex-wrap mt-2">{[["+30 days", 30], ["+15 days", 15], ["+7 days", 7], ["Today", 0], ["Yesterday", -1]].map(([l, d]) => <button type="button" key={String(l)} className="btn-ghost btn-sm" onClick={() => quick(d as number)}>{l}</button>)}</div></div>
        <div className="sm:col-span-2"><button className="btn-primary" disabled={busy}>{busy ? "Saving…" : "Save changes"}</button></div>
      </form>
      {msg && <p role="status" className={`text-sm font-medium ${msg.ok ? "text-ok" : "text-bad"}`}>{msg.t}</p>}
      <div className="card p-5 space-y-4">
        <h2 className="h2">Status &amp; access</h2>
        <div className="flex gap-3 flex-wrap items-start">
          {m.status === "active" ? <button className="btn-danger btn-sm" onClick={() => patch({ status: "suspended" }, "Member suspended. Their QR now shows RED.")}>Suspend membership</button> : <button className="btn-primary btn-sm" onClick={() => patch({ status: "active" }, "Membership reinstated.")}>Reinstate membership</button>}
          <button className="btn-ghost btn-sm" onClick={() => patch({ deactivated: !m.deactivated }, m.deactivated ? "Member reactivated." : "Member deactivated and signed out.")}>{m.deactivated ? "Reactivate member" : "Deactivate member"}</button>
          <ApiButton url={`/api/admin/members/${m.id}/reset-password`} label="Reset password" confirmText="Issue a new temporary password for this member? Their current sessions will be signed out." />
          <ApiButton url={`/api/admin/members/${m.id}/rotate-qr`} label="Regenerate QR code" confirmText="Replace this member's QR code? The old QR will stop working immediately." doneText="New QR token issued." />
        </div>
      </div>
    </div>
  );
}
