import { redirect } from "next/navigation";
import { currentSession } from "@/lib/auth";
import { Logo } from "@/components/Logo";
import { LoginForm } from "@/components/LoginForm";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sign in" };

export default async function LoginPage() {
  const s = await currentSession();
  if (s) redirect(s.role === "staff" ? "/staff/scan" : s.role === "admin" ? "/admin" : "/");
  return (
    <div className="min-h-dvh bg-[radial-gradient(1200px_500px_at_50%_-10%,#d8effa,transparent),linear-gradient(#fff,#eef6fb)] flex flex-col">
      <div className="bg-cyan text-navy text-center text-xs font-bold tracking-wide py-1 px-3">DEMONSTRATION PROTOTYPE · SYNTHETIC DATA ONLY</div>
      <main className="flex-1 grid place-items-center px-4 py-8">
        <div className="w-full max-w-md">
          <div className="flex justify-center mb-6"><Logo height={72} /></div>
          <div className="card p-6 sm:p-8">
            <h1 className="text-2xl font-bold text-navy text-center">Welcome to SGIA Connect</h1>
            <p className="text-center text-slate mt-1 mb-6">Pioneering Since 1923</p>
            <LoginForm />
          </div>
          <p className="text-center text-xs text-slate mt-6 px-4">Prototype for the SGIA Management Committee. All members and records are fictional. Do not enter real personal data.</p>
        </div>
      </main>
    </div>
  );
}
