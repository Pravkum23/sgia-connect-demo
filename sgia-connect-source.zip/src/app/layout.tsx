import type { Metadata, Viewport } from "next";
import "@fontsource/roboto/400.css";
import "@fontsource/roboto/500.css";
import "@fontsource/roboto/700.css";
import "./globals.css";
import { PwaRegister } from "@/components/PwaRegister";

export const metadata: Metadata = {
  title: { default: "SGIA Connect (DEMO)", template: "%s · SGIA Connect" },
  description: "SGIA Connect – prototype membership app for the Singapore Indian Association. Demonstration only, synthetic data.",
  applicationName: "SGIA Connect",
  appleWebApp: { capable: true, title: "SGIA Connect", statusBarStyle: "black-translucent" },
  robots: { index: false, follow: false },
  icons: { icon: "/icons/icon-192.png", apple: "/icons/apple-touch-icon.png" },
};
export const viewport: Viewport = { themeColor: "#001f3d", width: "device-width", initialScale: 1, viewportFit: "cover" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh bg-mist antialiased">
        {children}
        <PwaRegister />
      </body>
    </html>
  );
}
