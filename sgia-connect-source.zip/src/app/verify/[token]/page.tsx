import Link from "next/link";
import { currentSession, STAFF_ROLES } from "@/lib/auth";
import { verifyLookup, TOKEN_RE } from "@/lib/verify";
import { VerifyResult } from "@/components/VerifyResult";
import { Logo } from "@/components/Logo";

export const dynamic = "force-dynamic";
export const metadata = { title: "Membership verification", robots: { index: false } };

export default async function VerifyPage({ params }: { params: Promise<{ token: string }> }) {
  const { token } = await params;
  const s = await currentSession();
  const authorised = !!s && STAFF_ROLES.includes(s.role);
  // Unauthenticated / unauthorised visitors learn NOTHING about the member behind this code.
  const data = authorised && TOKEN_RE.test(token) ? await verifyLookup(s!.accountId, { token }, "qr-link") : null;
  return (
    <div className="min-h-dvh bg-mist">
      <div className="bg-cyan text-navy text-center text-xs font-bold tracking-wide py-1">DEMONSTRATION PROTOTYPE · SYNTHETIC DATA ONLY</div>
      <main className="max-w-xl mx-auto px-4 py-8 space-y-5">
        <div className="flex justify-center"><Logo height={56} /></div>
        {authorised && data ? (
          <>
            <VerifyResult data={data} />
            <div className="text-center"><Link href="/staff/scan" className="btn-ghost">Back to scanner</Link></div>
          </>
        ) : (
          <div className="card p-6 text-center space-y-3">
            <h1 className="h1">SGIA Connect demo membership code</h1>
            <p className="text-slate">{s ? "Your account is not authorised to verify memberships." : "Membership details are only shown to signed-in SGIA verification staff."}</p>
            {!s && <Link href="/login" className="btn-primary">Staff sign-in</Link>}
          </div>
        )}
      </main>
    </div>
  );
}
