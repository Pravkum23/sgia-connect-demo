import Link from "next/link";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/auth";
import { navFor } from "@/lib/nav";
import { one } from "@/lib/db";
import { Logo } from "@/components/Logo";
import { Icon } from "@/components/Icon";
import { BottomNav, SideNav } from "@/components/NavLinks";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const s = await currentSession();
  if (!s) redirect("/login");
  const nav = navFor(s.role);
  let unread = 0;
  if (s.memberId) {
    const r = await one<{ n: number }>(`SELECT count(*)::int AS n FROM notifications WHERE member_id=$1 AND read=false`, [s.memberId]);
    unread = r?.n ?? 0;
  }
  const roleLabel = { member: "Member", staff: "Verification Staff", admin: "Administrator", committee: "Management Committee" }[s.role];
  return (
    <div className="min-h-dvh flex flex-col">
      <div className="bg-cyan text-navy text-center text-xs font-bold tracking-wide py-1 px-3">DEMONSTRATION PROTOTYPE · SYNTHETIC DATA ONLY · NOT AN OFFICIAL SGIA CREDENTIAL</div>
      <header className="bg-navy text-white sticky top-0 z-30">
        <div className="mx-auto max-w-6xl px-4 h-16 flex items-center gap-4">
          <Link href={nav.home} aria-label="SGIA Connect home" className="flex items-center gap-3 min-w-0">
            <div className="bg-white rounded-lg px-2 py-1"><Logo height={34} /></div>
            <span className="font-bold text-lg hidden sm:block">SGIA Connect</span>
          </Link>
          <div className="flex-1" />
          <span className="hidden sm:block text-sm text-white/80">{s.name} · {roleLabel}</span>
          {s.memberId && (
            <Link href="/notifications" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} className="relative grid place-items-center h-11 w-11 rounded-full hover:bg-white/10">
              <Icon name="bell" />
              {unread > 0 && <span className="absolute top-1 right-1 min-w-4 h-4 px-1 rounded-full bg-cyan text-navy text-[10px] font-bold grid place-items-center">{unread}</span>}
            </Link>
          )}
        </div>
      </header>
      <div className="mx-auto w-full max-w-6xl flex-1 px-4 py-5 md:py-8 flex gap-8 pb-28 md:pb-10">
        <SideNav items={nav.primary} extra={nav.extra} unread={unread} />
        <main id="main" className="flex-1 min-w-0">{children}</main>
      </div>
      <BottomNav items={nav.primary} unread={unread} />
    </div>
  );
}
