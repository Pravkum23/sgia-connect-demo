import { requirePage } from "@/lib/guard";
import { STAFF_ROLES } from "@/lib/auth";
import { Scanner } from "@/components/Scanner";
export const metadata = { title: "Scan membership" };
export default async function ScanPage() {
  await requirePage(STAFF_ROLES);
  return (<div className="space-y-5"><div><h1 className="h1">Verify membership</h1><p className="muted">Scan a member&apos;s digital card. Every lookup is logged with your name and the time.</p></div><Scanner /></div>);
}
