import { requirePage } from "@/lib/guard";
import { STAFF_ROLES } from "@/lib/auth";
import { recentVerifications } from "@/lib/verify";
import { fmtDateTime } from "@/lib/status";
export const metadata = { title: "Check-in log" };
const cls = (r: string) => (r === "active" ? "badge-green" : r === "expiring" ? "badge-amber" : "badge-red");
export default async function History() {
  await requirePage(STAFF_ROLES);
  const rows = await recentVerifications(100);
  return (
    <div className="space-y-5">
      <h1 className="h1">Verification &amp; check-in log</h1>
      <div className="table-wrap"><table className="table"><thead><tr><th>Time</th><th>Member</th><th>Result</th><th>Method</th><th>Staff</th></tr></thead>
        <tbody>{rows.map((r) => (<tr key={r.id}><td className="whitespace-nowrap">{fmtDateTime(r.at)}</td><td>{r.member ?? "—"}<div className="muted">{r.membership_id}</div></td><td><span className={cls(r.result)}>{r.result.replace("_", " ")}</span>{r.checked_in && <span className="badge-blue ml-1">checked in</span>}</td><td>{r.method}</td><td>{r.staff}</td></tr>))}
          {rows.length === 0 && <tr><td colSpan={5} className="muted">Nothing logged yet.</td></tr>}</tbody></table></div>
    </div>
  );
}
