import { requirePage } from "@/lib/guard";
import { getMember, qrSvg } from "@/lib/members";
import { MemberCard } from "@/components/MemberCard";
import { RenewalBanner } from "@/components/RenewalBanner";
import { Icon } from "@/components/Icon";
import { fmtDate, STATUS_LABEL } from "@/lib/status";
import Link from "next/link";

export const metadata = { title: "Membership" };

export default async function MembershipPage() {
  const s = await requirePage(["member", "committee"]);
  const m = (await getMember(s.memberId!))!;
  const svg = await qrSvg(m.qr_token);
  const rows: [string, string, string][] = [
    ["user", "Membership type", m.category],
    ["calendar", "Date of joining", fmtDate(m.join_date)],
    ["calendar", "Expiry date", m.lifetime ? "Lifetime" : fmtDate(m.expiry_date)],
    ["shield", "Status", STATUS_LABEL[m.computed]],
  ];
  return (
    <div className="space-y-5 max-w-xl mx-auto md:mx-0">
      <h1 className="h1">Membership</h1>
      <RenewalBanner status={m.computed} days={m.days} expiry={m.expiry_date} />
      <MemberCard m={m} qrSvg={svg} status={m.computed} />
      <div className="flex gap-3 flex-wrap">
        <a href="/api/me/qr?download=1" className="btn-cyan flex-1"><Icon name="download" size={20} />Save QR as image</a>
        <Link href="/renewal" className="btn-ghost flex-1"><Icon name="refresh" size={20} />Renewal (DEMO)</Link>
      </div>
      <p className="muted">The QR code contains only a random verification code. When staff scan it, they see your current status from the SGIA system – so it always reflects expiry or suspension.</p>
      <div className="card divide-y divide-line">
        {rows.map(([ic, k, v]) => (
          <div key={k} className="flex items-center gap-4 p-4"><Icon name={ic} className="text-navy-600" /><div><p className="muted">{k}</p><p className="font-medium text-navy">{v}</p></div></div>
        ))}
      </div>
    </div>
  );
}
