import { requirePage } from "@/lib/guard";
import { ADMIN_VIEW_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { fmtDateTime } from "@/lib/status";
import { AnnouncementForm } from "@/components/AnnouncementForm";
import { ApiButton } from "@/components/ApiButton";
import { processScheduled } from "@/lib/admin";

export const metadata = { title: "Manage announcements" };
const badge = (s: string) => (s === "published" ? "badge-green" : s === "scheduled" ? "badge-blue" : s === "archived" ? "badge-gray" : "badge-amber");

export default async function AdminAnnouncements() {
  const s = await requirePage(ADMIN_VIEW_ROLES);
  const isAdmin = s.role === "admin";
  await processScheduled();
  const rows = await q<{ id: number; title: string; category: string; audience: string; state: string; publish_at: string | null; published_at: string | null; files: number; reads: number }>(
    `SELECT a.id,a.title,a.category,a.audience,a.state,a.publish_at,a.published_at,
       (SELECT count(*)::int FROM attachments t WHERE t.announcement_id=a.id) AS files,
       (SELECT count(*)::int FROM announcement_reads r WHERE r.announcement_id=a.id) AS reads
     FROM announcements a ORDER BY a.created_at DESC, a.id DESC`);
  return (
    <div className="space-y-6">
      <h1 className="h1">Announcements</h1>
      <div className="table-wrap"><table className="table"><thead><tr><th>Title</th><th>State</th><th>Audience</th><th>When</th><th>Reads</th>{isAdmin && <th>Actions</th>}</tr></thead><tbody>
        {rows.map((a) => (<tr key={a.id}><td className="min-w-56"><span className="font-medium">{a.title}</span><div className="muted">{a.category}{a.files > 0 ? ` · ${a.files} attachment${a.files > 1 ? "s" : ""}` : ""}</div></td>
          <td><span className={badge(a.state)}>{a.state}</span></td><td>{a.audience === "all" ? "All members" : a.audience}</td>
          <td className="whitespace-nowrap">{a.state === "scheduled" && a.publish_at ? fmtDateTime(a.publish_at) : a.published_at ? fmtDateTime(a.published_at) : "—"}</td><td>{a.reads}</td>
          {isAdmin && <td className="space-y-1">
            {(a.state === "draft" || a.state === "scheduled") && <ApiButton url={`/api/admin/announcements/${a.id}`} payload={{ action: "publish" }} label="Publish now" className="btn-primary btn-sm" />}
            {a.state === "published" && <ApiButton url={`/api/admin/announcements/${a.id}`} payload={{ action: "archive" }} label="Archive" />}
            {a.state !== "published" && <ApiButton url={`/api/admin/announcements/${a.id}`} method="DELETE" label="Delete" confirmText="Delete this announcement?" />}
          </td>}</tr>))}
      </tbody></table></div>
      {isAdmin && <><h2 className="h2">Create announcement</h2><AnnouncementForm /></>}
    </div>
  );
}
