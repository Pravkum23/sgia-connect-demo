import Link from "next/link";
import { requirePage } from "@/lib/guard";
import { ADMIN_VIEW_ROLES } from "@/lib/auth";
import { dashboardStats, processScheduled } from "@/lib/admin";
import { q } from "@/lib/db";
import { addDays, daysBetween, fmtDate, fmtDateTime, sgToday } from "@/lib/status";
import { ApiButton } from "@/components/ApiButton";
import { Icon } from "@/components/Icon";

export const metadata = { title: "Admin dashboard" };

export default async function AdminHome() {
  const s = await requirePage(ADMIN_VIEW_ROLES);
  const isAdmin = s.role === "admin";
  await processScheduled();
  const st = await dashboardStats();
  const today = sgToday();
  const [renewals, requests] = await Promise.all([
    q<{ id: number; name: string; membership_id: string; expiry_date: string }>(`SELECT id,name,membership_id,expiry_date FROM members WHERE deactivated=false AND status='active' AND category<>'Life Member' AND expiry_date BETWEEN $1 AND $2 ORDER BY expiry_date LIMIT 15`, [addDays(today, -30), addDays(today, 30)]),
    q<{ id: number; name: string; membership_id: string; note: string | null; created_at: string }>(`SELECT r.id, m.name, m.membership_id, r.note, r.created_at FROM renewal_requests r JOIN members m ON m.id=r.member_id WHERE r.status='requested' ORDER BY r.id`),
  ]);
  const tiles: [string, number, string][] = [
    ["Total demo members", st.total, "users"], ["Active members", st.active, "check"], ["Expired members", st.expired, "x"], ["Upcoming renewals (30 days)", st.renewals, "refresh"],
    ["Published announcements", st.announcements, "megaphone"], ["Upcoming events", st.events, "calendar"], ["Push attempts logged", st.push_attempts, "bell"], ["QR check-ins", st.checkins, "scan"],
  ];
  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div><h1 className="h1">{isAdmin ? "Administration" : "Committee dashboard"}</h1><p className="muted">{isAdmin ? "Demo data only." : "Read-only view of the demonstration administration dashboard."}</p></div>
        {isAdmin && <ApiButton url="/api/admin/run-expiry-check" label="Run expiry reminder check now" busyLabel="Checking…" className="btn-cyan btn-sm" doneText="Expiry check complete." />}
      </div>
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-3" aria-label="Key figures">
        {tiles.map(([k, v, ic]) => (
          <div key={k} className="card p-4"><Icon name={ic} className="text-cyan-700" /><p className="text-3xl font-bold text-navy mt-2" data-testid={`stat-${k}`}>{v}</p><p className="muted">{k}</p></div>
        ))}
      </section>
      <section>
        <h2 className="h2 mb-2">Renewals due (±30 days)</h2>
        <div className="table-wrap"><table className="table"><thead><tr><th>Member</th><th>Expires</th><th>Days</th>{isAdmin && <th></th>}</tr></thead><tbody>
          {renewals.map((r) => { const d = daysBetween(today, r.expiry_date); return (
            <tr key={r.id}><td>{r.name}<div className="muted">{r.membership_id}</div></td><td>{fmtDate(r.expiry_date)}</td><td><span className={d < 0 ? "badge-red" : d <= 7 ? "badge-amber" : "badge-blue"}>{d < 0 ? `${-d}d overdue` : d === 0 ? "today" : `${d}d`}</span></td>{isAdmin && <td><Link className="btn-ghost btn-sm" href={`/admin/members/${r.id}`}>Open</Link></td>}</tr>); })}
          {renewals.length === 0 && <tr><td colSpan={4} className="muted">None.</td></tr>}
        </tbody></table></div>
      </section>
      <section>
        <h2 className="h2 mb-2">Demo renewal requests</h2>
        <div className="table-wrap"><table className="table"><thead><tr><th>Member</th><th>Note</th><th>Requested</th>{isAdmin && <th>Action</th>}</tr></thead><tbody>
          {requests.map((r) => (<tr key={r.id}><td>{r.name}<div className="muted">{r.membership_id}</div></td><td>{r.note ?? "—"}</td><td>{fmtDateTime(r.created_at)}</td>
            {isAdmin && <td className="space-x-2 whitespace-nowrap"><ApiButton url={`/api/admin/renewals/${r.id}`} payload={{ action: "approve" }} label="Approve (+1 year)" className="btn-primary btn-sm" /><ApiButton url={`/api/admin/renewals/${r.id}`} payload={{ action: "decline" }} label="Decline" /></td>}</tr>))}
          {requests.length === 0 && <tr><td colSpan={4} className="muted">No open requests.</td></tr>}
        </tbody></table></div>
      </section>
      <p className="muted">Verification lookups recorded: {st.verifications}. See <Link className="text-cyan-700 underline" href={isAdmin ? "/admin/notifications" : "/admin/notifications"}>notification log</Link>.</p>
    </div>
  );
}
