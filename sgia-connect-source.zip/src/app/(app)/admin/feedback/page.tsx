import { requirePage } from "@/lib/guard";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { fmtDateTime } from "@/lib/status";
import { ApiButton } from "@/components/ApiButton";
export const metadata = { title: "Committee feedback" };
export default async function FeedbackAdmin() {
  await requirePage(ADMIN_ROLES);
  const rows = await q<{ id: number; author: string; kind: string; page: string | null; device: string | null; message: string; resolved: boolean; created_at: string }>(`SELECT * FROM feedback ORDER BY resolved, id DESC`);
  return (
    <div className="space-y-5"><h1 className="h1">Committee feedback</h1>
      <div className="space-y-3">{rows.length === 0 && <p className="card p-6 muted">No feedback submitted yet.</p>}
        {rows.map((f) => (<article key={f.id} className="card p-5 space-y-2"><div className="flex gap-2 flex-wrap items-center"><span className="badge-blue">{f.kind}</span>{f.resolved && <span className="badge-green">Resolved</span>}<span className="muted">{f.author} · {fmtDateTime(f.created_at)}{f.page ? ` · ${f.page}` : ""}</span></div>
          <p className="whitespace-pre-line text-navy">{f.message}</p>{f.device && <p className="text-xs text-slate break-words">{f.device}</p>}
          <ApiButton url={`/api/admin/feedback/${f.id}`} method="PATCH" payload={{ resolved: !f.resolved }} label={f.resolved ? "Reopen" : "Mark resolved"} /></article>))}</div></div>
  );
}
