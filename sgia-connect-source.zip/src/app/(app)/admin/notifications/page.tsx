import { requirePage } from "@/lib/guard";
import { ADMIN_VIEW_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { fmtDateTime } from "@/lib/status";
import { BroadcastForm } from "@/components/BroadcastForm";

export const metadata = { title: "Notification log" };
const tone = (o: string) => (o === "sent" || o === "delivered" ? "badge-green" : o === "no-subscription" || o === "not-sent" || o === "not-configured" ? "badge-gray" : "badge-amber");

export default async function NotifLog() {
  const s = await requirePage(ADMIN_VIEW_ROLES);
  const rows = await q<{ id: number; at: string; member: string | null; channel: string; kind: string; title: string; outcome: string; http_status: number | null; detail: string | null }>(
    `SELECT d.id,d.at,m.membership_id AS member,d.channel,d.kind,d.title,d.outcome,d.http_status,d.detail FROM delivery_log d LEFT JOIN members m ON m.id=d.member_id ORDER BY d.id DESC LIMIT 150`);
  const sum = await q<{ channel: string; outcome: string; n: number }>(`SELECT channel,outcome,count(*)::int AS n FROM delivery_log GROUP BY 1,2 ORDER BY 1,2`);
  return (
    <div className="space-y-6">
      <h1 className="h1">Notification &amp; delivery log</h1>
      <div className="rounded-2xl bg-pale border border-[#cfe9f5] p-4 text-sm text-navy-700">&ldquo;Sent&rdquo; means a push service accepted the message for delivery. It does not prove the notification was displayed, because the device may be offline, in Silent Mode / Do Not Disturb, or have notifications disabled. Members always see alerts in the in-app notification centre.</div>
      <div className="flex gap-2 flex-wrap">{sum.map((x) => <span key={x.channel + x.outcome} className="badge-blue">{x.channel}: {x.outcome} · {x.n}</span>)}</div>
      <div className="table-wrap"><table className="table"><thead><tr><th>Time</th><th>Member</th><th>Channel</th><th>Type</th><th>Title</th><th>Outcome</th><th>Detail</th></tr></thead><tbody>
        {rows.map((r) => (<tr key={r.id}><td className="whitespace-nowrap">{fmtDateTime(r.at)}</td><td className="font-mono text-xs">{r.member ?? "—"}</td><td>{r.channel}</td><td>{r.kind}</td><td className="min-w-44">{r.title}</td><td><span className={tone(r.outcome)}>{r.outcome}</span>{r.http_status ? <span className="muted"> {r.http_status}</span> : null}</td><td className="muted min-w-48">{r.detail}</td></tr>))}
        {rows.length === 0 && <tr><td colSpan={7} className="muted">No delivery attempts yet.</td></tr>}</tbody></table></div>
      {s.role === "admin" && <><h2 className="h2">Send an administrative notice</h2><BroadcastForm /></>}
    </div>
  );
}
