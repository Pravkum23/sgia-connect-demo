import { requirePage } from "@/lib/guard";
import { ADMIN_VIEW_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { fmtDateTime } from "@/lib/status";
import { EventForm } from "@/components/EventForm";
import { ApiButton } from "@/components/ApiButton";

export const metadata = { title: "Manage events" };

export default async function AdminEvents() {
  const s = await requirePage(ADMIN_VIEW_ROLES);
  const isAdmin = s.role === "admin";
  const rows = await q<{ id: number; title: string; starts_at: string; venue: string; capacity: number | null; published: boolean; going: number }>(
    `SELECT e.id,e.title,e.starts_at,e.venue,e.capacity,e.published,(SELECT count(*)::int FROM event_registrations r WHERE r.event_id=e.id) AS going FROM events e ORDER BY e.starts_at`);
  return (
    <div className="space-y-6">
      <h1 className="h1">Events</h1>
      <div className="table-wrap"><table className="table"><thead><tr><th>Event</th><th>When</th><th>Venue</th><th>Registered</th><th>Status</th>{isAdmin && <th></th>}</tr></thead><tbody>
        {rows.map((e) => (<tr key={e.id}><td className="font-medium">{e.title}</td><td className="whitespace-nowrap">{fmtDateTime(e.starts_at)}</td><td>{e.venue}</td><td>{e.going}{e.capacity ? ` / ${e.capacity}` : ""}</td><td><span className={e.published ? "badge-green" : "badge-gray"}>{e.published ? "Published" : "Hidden"}</span></td>
          {isAdmin && <td className="space-x-2 whitespace-nowrap"><ApiButton url={`/api/admin/events/${e.id}`} method="PATCH" payload={{ published: !e.published }} label={e.published ? "Hide" : "Publish"} /><ApiButton url={`/api/admin/events/${e.id}`} method="DELETE" label="Delete" confirmText="Delete this event and its registrations?" /></td>}</tr>))}
      </tbody></table></div>
      {isAdmin && <><h2 className="h2">Create event</h2><EventForm /></>}
    </div>
  );
}
