import Link from "next/link";
import { notFound } from "next/navigation";
import { requirePage } from "@/lib/guard";
import { ADMIN_ROLES } from "@/lib/auth";
import { getMember } from "@/lib/members";
import { fmtDate, fmtDateTime } from "@/lib/status";
import { q } from "@/lib/db";
import { StatusBadge, Avatar } from "@/components/Status";
import { MemberEditor } from "@/components/MemberEditor";
import { Icon } from "@/components/Icon";

export default async function AdminMember({ params }: { params: Promise<{ id: string }> }) {
  await requirePage(ADMIN_ROLES);
  const { id } = await params;
  const m = Number.isInteger(Number(id)) ? await getMember(Number(id)) : null;
  if (!m) notFound();
  const checks = await q<{ at: string; result: string; method: string; checked_in: boolean; staff: string }>(
    `SELECT v.at, v.result, v.method, v.checked_in, a.display_name AS staff FROM verifications v JOIN accounts a ON a.id=v.staff_id WHERE v.member_id=$1 ORDER BY v.at DESC LIMIT 10`, [m.id]);
  return (
    <div className="space-y-6 max-w-3xl">
      <Link href="/admin/members" className="inline-flex items-center gap-1 text-cyan-700 font-medium min-h-11"><Icon name="arrow" className="rotate-180" size={18} />All members</Link>
      <div className="card p-5 flex items-center gap-4 flex-wrap"><Avatar name={m.name} hue={m.avatar_hue} size={64} />
        <div className="flex-1 min-w-48"><h1 className="h1">{m.name}</h1><p className="muted font-mono">{m.membership_id}</p></div><StatusBadge status={m.computed} /></div>
      <dl className="card grid sm:grid-cols-2 gap-4 p-5 text-sm">
        <div><dt className="muted">Joined</dt><dd className="font-medium">{fmtDate(m.join_date)}</dd></div>
        <div><dt className="muted">Expiry</dt><dd className="font-medium">{m.lifetime ? "Lifetime" : `${fmtDate(m.expiry_date)} (${m.days >= 0 ? `${m.days} days left` : `${-m.days} days ago`})`}</dd></div>
        <div><dt className="muted">Email</dt><dd className="font-medium">{m.email}</dd></div>
        <div><dt className="muted">Phone</dt><dd className="font-medium">{m.mobile}</dd></div>
      </dl>
      <MemberEditor m={{ id: m.id, name: m.name, category: m.category, email: m.email, expiry_date: m.expiry_date, status: m.status, deactivated: m.deactivated }} />
      <section><h2 className="h2 mb-2">Recent verifications</h2>
        <div className="table-wrap"><table className="table"><thead><tr><th>Time</th><th>Result</th><th>Method</th><th>Staff</th></tr></thead><tbody>
          {checks.map((c, i) => (<tr key={i}><td>{fmtDateTime(c.at)}</td><td>{c.result}{c.checked_in ? " · checked in" : ""}</td><td>{c.method}</td><td>{c.staff}</td></tr>))}
          {checks.length === 0 && <tr><td colSpan={4} className="muted">None yet.</td></tr>}</tbody></table></div></section>
    </div>
  );
}
