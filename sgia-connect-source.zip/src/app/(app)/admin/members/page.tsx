import Link from "next/link";
import { requirePage } from "@/lib/guard";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { addDays, computeStatus, fmtDate, sgToday } from "@/lib/status";
import { StatusBadge } from "@/components/Status";
import { AddMemberForm } from "@/components/AddMemberForm";
import { ImportExport } from "@/components/ImportExport";
import { CATEGORIES } from "@/lib/members-constants";
import type { MemberRow } from "@/lib/members";

export const metadata = { title: "Members" };

export default async function AdminMembers({ searchParams }: { searchParams: Promise<{ q?: string; status?: string; cat?: string }> }) {
  await requirePage(ADMIN_ROLES);
  const sp = await searchParams;
  const term = (sp.q ?? "").trim().slice(0, 60);
  const rows = await q<MemberRow>(
    `SELECT * FROM members WHERE ($1='' OR name ILIKE '%'||$1||'%' OR membership_id ILIKE '%'||$1||'%' OR email ILIKE '%'||$1||'%') AND ($2::text IS NULL OR category=$2) ORDER BY id`,
    [term, sp.cat && CATEGORIES.includes(sp.cat) ? sp.cat : null]);
  const all = rows.map((m) => ({ m, st: computeStatus(m) })).filter((x) => !sp.status || x.st === sp.status);
  return (
    <div className="space-y-6">
      <h1 className="h1">Demo members</h1>
      <form className="card p-4 grid gap-3 sm:grid-cols-[1fr_auto_auto_auto]" role="search">
        <input name="q" defaultValue={term} className="input" placeholder="Search name, ID or email" aria-label="Search members" />
        <select name="status" defaultValue={sp.status ?? ""} className="input sm:w-44" aria-label="Status"><option value="">All statuses</option>{["active", "expiring", "expired", "suspended", "inactive"].map((s) => <option key={s} value={s}>{s}</option>)}</select>
        <select name="cat" defaultValue={sp.cat ?? ""} className="input sm:w-48" aria-label="Category"><option value="">All categories</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
        <button className="btn-primary">Filter</button>
      </form>
      <p className="muted">{all.length} member{all.length === 1 ? "" : "s"}</p>
      <div className="table-wrap"><table className="table"><thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Status</th><th>Expiry</th><th></th></tr></thead><tbody>
        {all.map(({ m, st }) => (<tr key={m.id}><td className="font-mono whitespace-nowrap">{m.membership_id}</td><td>{m.name}</td><td>{m.category}</td><td><StatusBadge status={st} /></td><td className="whitespace-nowrap">{m.expiry_date >= "2099-01-01" ? "Lifetime" : fmtDate(m.expiry_date)}</td><td><Link className="btn-ghost btn-sm" href={`/admin/members/${m.id}`}>Manage</Link></td></tr>))}
        {all.length === 0 && <tr><td colSpan={6} className="muted">No members match.</td></tr>}
      </tbody></table></div>
      <h2 className="h2">Add a demo member</h2>
      <AddMemberForm today={sgToday()} nextYear={addDays(sgToday(), 365)} />
      <ImportExport />
    </div>
  );
}
