import { requirePage } from "@/lib/guard";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { fmtDateTime } from "@/lib/status";
export const metadata = { title: "Audit log" };
export default async function Audit() {
  await requirePage(ADMIN_ROLES);
  const rows = await q<{ id: number; at: string; actor: string; action: string; target: string | null; detail: string | null }>(`SELECT id,at,actor,action,target,detail FROM audit_log ORDER BY id DESC LIMIT 300`);
  return (
    <div className="space-y-5"><h1 className="h1">Audit log</h1><p className="muted">Sign-ins, administrative changes and verifications. Latest 300 entries.</p>
      <div className="table-wrap"><table className="table"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Target</th><th>Detail</th></tr></thead><tbody>
        {rows.map((r) => (<tr key={r.id}><td className="whitespace-nowrap">{fmtDateTime(r.at)}</td><td className="font-mono text-xs">{r.actor}</td><td><span className="badge-blue">{r.action}</span></td><td>{r.target}</td><td className="muted min-w-56">{r.detail}</td></tr>))}</tbody></table></div></div>
  );
}
