import { requirePage } from "@/lib/guard";
import { upcomingEvents } from "@/lib/content";
import { EventRegister } from "@/components/EventRegister";
import { Icon } from "@/components/Icon";

export const metadata = { title: "Events" };

export default async function EventsPage() {
  const s = await requirePage(["member", "committee"]);
  const events = await upcomingEvents(s.memberId, 30);
  const fmt = new Intl.DateTimeFormat("en-SG", { timeZone: "Asia/Singapore", weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "numeric", minute: "2-digit" });
  return (
    <div className="space-y-5">
      <div><h1 className="h1">Events</h1><p className="muted">Registration is a demonstration only – no payments are taken.</p></div>
      <div className="grid gap-5 md:grid-cols-2">
        {events.map((e) => (
          <article key={e.id} className="card overflow-hidden flex flex-col">
            <div className="h-36 grid place-items-center text-white" style={{ background: `linear-gradient(135deg, hsl(${e.hue} 70% 32%), hsl(${(e.hue + 40) % 360} 75% 45%))` }} role="img" aria-label="Event image placeholder">
              <Icon name="calendar" size={52} stroke={1.4} />
            </div>
            <div className="p-5 flex-1 flex flex-col gap-3">
              <div className="flex items-start justify-between gap-2"><h2 className="text-xl font-bold text-navy">{e.title}</h2>{e.registered && <span className="badge-green shrink-0">Registered</span>}</div>
              <p className="text-sm text-navy-700 flex gap-2"><Icon name="calendar" size={18} className="shrink-0 mt-0.5" />{fmt.format(new Date(e.starts_at))}</p>
              <p className="text-sm text-navy-700 flex gap-2"><Icon name="pin" size={18} className="shrink-0 mt-0.5" />{e.venue}</p>
              <p className="text-slate flex-1">{e.description}</p>
              <p className="muted">{e.going} registered{e.capacity ? ` · ${e.capacity} places` : ""}</p>
              <EventRegister id={e.id} registered={e.registered} full={!!e.capacity && e.going >= e.capacity} />
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
