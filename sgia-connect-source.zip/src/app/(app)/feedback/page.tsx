import { requirePage } from "@/lib/guard";
import { FeedbackForm } from "@/components/FeedbackForm";
export const metadata = { title: "Send feedback" };
export default async function FeedbackPage() {
  await requirePage(["committee", "admin"]);
  return (
    <div className="max-w-xl space-y-5">
      <div><h1 className="h1">Committee feedback</h1><p className="muted">Help improve SGIA Connect before the real apps are built.</p></div>
      <FeedbackForm />
    </div>
  );
}
