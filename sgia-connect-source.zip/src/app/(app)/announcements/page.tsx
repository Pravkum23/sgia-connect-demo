import Link from "next/link";
import { requirePage } from "@/lib/guard";
import { getMember } from "@/lib/members";
import { announcementsFor } from "@/lib/content";
import { fmtDate } from "@/lib/status";
import { Icon } from "@/components/Icon";

export const metadata = { title: "Announcements" };
const TABS = ["All", "Events", "Notices", "Community"];

export default async function Announcements({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const s = await requirePage(["member", "committee"]);
  const { tab } = await searchParams;
  const cat = TABS.includes(tab ?? "") && tab !== "All" ? tab : undefined;
  const m = (await getMember(s.memberId!))!;
  const rows = await announcementsFor(m, 50, cat);
  return (
    <div className="space-y-5 max-w-3xl">
      <h1 className="h1">Announcements</h1>
      <div className="flex gap-2 overflow-x-auto pb-1" role="tablist">
        {TABS.map((t) => {
          const on = (cat ?? "All") === t;
          return <Link key={t} href={t === "All" ? "/announcements" : `/announcements?tab=${t}`} role="tab" aria-selected={on} className={`px-5 min-h-11 grid place-items-center rounded-full font-medium whitespace-nowrap ${on ? "bg-navy text-white" : "bg-white border border-line text-navy"}`}>{t}</Link>;
        })}
      </div>
      <div className="card divide-y divide-line">
        {rows.length === 0 && <p className="p-6 muted">No announcements in this category.</p>}
        {rows.map((a) => (
          <Link key={a.id} href={`/announcements/${a.id}`} className="flex gap-3 p-4 hover:bg-mist">
            <Icon name="megaphone" className="text-navy-600 mt-1 shrink-0" />
            <div className="min-w-0 flex-1">
              <p className={`text-navy ${a.read ? "font-medium" : "font-bold"}`}>{a.title}{!a.read && <span className="badge-blue ml-2 !py-0.5 !text-xs">New</span>}</p>
              <p className="muted">{a.category} · {a.published_at ? fmtDate(new Date(a.published_at).toISOString()) : ""}{a.attachments > 0 && " · 📎 attachment"}</p>
              <p className="text-slate line-clamp-2 mt-1">{a.body}</p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
