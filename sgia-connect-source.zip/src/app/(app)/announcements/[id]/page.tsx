import Link from "next/link";
import { notFound } from "next/navigation";
import { requirePage } from "@/lib/guard";
import { getMember } from "@/lib/members";
import { one, q } from "@/lib/db";
import { VISIBLE_SQL } from "@/lib/content";
import { fmtDate } from "@/lib/status";
import { Icon } from "@/components/Icon";

export default async function AnnouncementPage({ params }: { params: Promise<{ id: string }> }) {
  const s = await requirePage(["member", "committee"]);
  const { id } = await params;
  const aid = Number(id);
  if (!Number.isInteger(aid)) notFound();
  const m = (await getMember(s.memberId!))!;
  const a = await one<{ id: number; title: string; body: string; category: string; published_at: string | null; publish_at: string | null; author: string }>(
    `SELECT a.* FROM announcements a WHERE a.id=$1 AND ${VISIBLE_SQL} AND (a.audience='all' OR a.audience=$2)`, [aid, m.category]);
  if (!a) notFound();
  await q(`INSERT INTO announcement_reads(announcement_id,member_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`, [a.id, m.id]);
  const files = await q<{ id: number; filename: string; mime: string; size: number }>(`SELECT id,filename,mime,size FROM attachments WHERE announcement_id=$1 ORDER BY id`, [a.id]);
  const images = files.filter((f) => f.mime.startsWith("image/"));
  const docs = files.filter((f) => !f.mime.startsWith("image/"));
  const when = a.published_at ?? a.publish_at;
  return (
    <article className="max-w-3xl space-y-5">
      <Link href="/announcements" className="inline-flex items-center gap-1 text-cyan-700 font-medium min-h-11"><Icon name="arrow" className="rotate-180" size={18} />Announcements</Link>
      <div><span className="badge-blue">{a.category}</span><h1 className="h1 mt-2">{a.title}</h1><p className="muted mt-1">{when ? fmtDate(new Date(when).toISOString()) : ""} · {a.author}</p></div>
      {images.map((f) => (
        // eslint-disable-next-line @next/next/no-img-element
        <img key={f.id} src={`/api/attachments/${f.id}`} alt={f.filename} className="rounded-2xl border border-line max-h-96 w-full object-cover" />
      ))}
      <div className="card p-5 whitespace-pre-line text-lg leading-relaxed">{a.body}</div>
      {docs.length > 0 && (
        <div className="card divide-y divide-line">
          {docs.map((f) => (
            <a key={f.id} href={`/api/attachments/${f.id}`} target="_blank" rel="noopener" className="flex items-center gap-3 p-4 min-h-14 hover:bg-mist"><Icon name="file" className="text-navy-600" /><span className="flex-1 font-medium text-navy">{f.filename}</span><span className="muted">{Math.max(1, Math.round(f.size / 1024))} KB</span></a>
          ))}
        </div>
      )}
    </article>
  );
}
