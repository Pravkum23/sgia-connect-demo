import Link from "next/link";
import { requirePage } from "@/lib/guard";
import { getMember, getFamily } from "@/lib/members";
import { fmtDate, STATUS_LABEL } from "@/lib/status";
import { PasswordForm } from "@/components/PasswordForm";
import { LogoutButton } from "@/components/LogoutButton";
import { Avatar } from "@/components/Status";
import { Icon } from "@/components/Icon";
import { PushSettings } from "@/components/PushSettings";
import { navFor } from "@/lib/nav";

export const metadata = { title: "Profile" };

export default async function ProfilePage() {
  const s = await requirePage();
  const m = s.memberId ? await getMember(s.memberId) : null;
  const family = m ? await getFamily(m) : [];
  const nav = navFor(s.role);
  const row = (k: string, v: string) => (<div className="flex justify-between gap-4 p-4"><dt className="muted">{k}</dt><dd className="font-medium text-navy text-right break-words">{v}</dd></div>);
  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="h1">Profile</h1>
      <div className="card p-5 flex items-center gap-4">
        <Avatar name={s.name} hue={m?.avatar_hue ?? 210} size={64} />
        <div><p className="text-xl font-bold text-navy">{s.name}</p><p className="muted">{s.loginId}</p></div>
      </div>
      {m ? (
        <dl className="card divide-y divide-line">
          {row("Full name", m.name)}
          {row("Membership number", m.membership_id)}
          {row("Membership category", m.category)}
          {row("Joining date", fmtDate(m.join_date))}
          {row("Expiry date", m.lifetime ? "Lifetime" : fmtDate(m.expiry_date))}
          {row("Digital membership status", STATUS_LABEL[m.computed])}
          {row("Registered email", m.email)}
          {row("Registered telephone", m.mobile)}
        </dl>
      ) : (
        <div className="card p-5"><p className="muted">Role</p><p className="font-medium text-navy capitalize">{s.role === "staff" ? "Verification staff" : s.role}</p></div>
      )}
      {family.length > 0 && (
        <section><h2 className="h2 mb-2">Family members</h2>
          <ul className="card divide-y divide-line">{family.map((f) => (<li key={f.membership_id} className="p-4 flex justify-between"><span className="font-medium text-navy">{f.name}</span><span className="muted">{f.membership_id}</span></li>))}</ul>
        </section>
      )}
      {nav.extra.length > 0 && s.role === "committee" && (
        <section className="md:hidden"><h2 className="h2 mb-2">More</h2>
          <ul className="card divide-y divide-line">{nav.extra.map((x) => (<li key={x.href}><Link href={x.href} className="flex items-center gap-3 p-4 min-h-14"><Icon name={x.icon} className="text-navy-600" /><span className="flex-1 font-medium text-navy">{x.label}</span><Icon name="arrow" className="text-slate" /></Link></li>))}</ul>
        </section>
      )}
      {s.role === "admin" && (
        <section className="md:hidden"><h2 className="h2 mb-2">More</h2>
          <ul className="card divide-y divide-line">{nav.extra.map((x) => (<li key={x.href}><Link href={x.href} className="flex items-center gap-3 p-4 min-h-14"><Icon name={x.icon} className="text-navy-600" /><span className="flex-1 font-medium text-navy">{x.label}</span><Icon name="arrow" className="text-slate" /></Link></li>))}</ul>
        </section>
      )}
      {m && <PushSettings />}
      <section><h2 className="h2 mb-3">Change password</h2><div className="card p-5"><PasswordForm /></div></section>
      <LogoutButton />
    </div>
  );
}
