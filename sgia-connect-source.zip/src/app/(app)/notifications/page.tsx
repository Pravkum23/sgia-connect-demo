import { requirePage } from "@/lib/guard";
import { q } from "@/lib/db";
import { fmtDateTime } from "@/lib/status";
import { Icon } from "@/components/Icon";
import { PushSettings } from "@/components/PushSettings";
import { MarkAllRead } from "@/components/MarkAllRead";

export const metadata = { title: "Notifications" };

export default async function NotificationsPage() {
  const s = await requirePage(["member", "committee"]);
  const rows = await q<{ id: number; kind: string; title: string; body: string; read: boolean; created_at: string }>(
    `SELECT id,kind,title,body,read,created_at FROM notifications WHERE member_id=$1 ORDER BY created_at DESC LIMIT 100`, [s.memberId]);
  const unread = rows.filter((r) => !r.read).length;
  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between gap-3"><h1 className="h1">Notifications</h1>{unread > 0 && <MarkAllRead />}</div>
      <div className="card divide-y divide-line">
        {rows.length === 0 && <p className="p-6 muted">No notifications yet.</p>}
        {rows.map((n) => (
          <div key={n.id} className="p-4 flex gap-3">
            <span className={`mt-1 h-2.5 w-2.5 rounded-full shrink-0 ${n.read ? "bg-transparent" : "bg-cyan"}`} aria-label={n.read ? "Read" : "Unread"} />
            <Icon name={n.kind === "expiry" ? "refresh" : n.kind === "event" ? "calendar" : "bell"} className="text-navy-600 shrink-0 mt-0.5" />
            <div className="min-w-0"><p className={`text-navy ${n.read ? "font-medium" : "font-bold"}`}>{n.title}</p><p className="text-sm text-slate">{n.body}</p><p className="text-xs text-slate mt-1">{fmtDateTime(n.created_at)}</p></div>
          </div>
        ))}
      </div>
      <h2 className="h2">Notification test</h2>
      <PushSettings showTest />
    </div>
  );
}
