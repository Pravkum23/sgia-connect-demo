import Link from "next/link";
import { redirect } from "next/navigation";
import { requirePage } from "@/lib/guard";
import { getMember } from "@/lib/members";
import { announcementsFor, upcomingEvents } from "@/lib/content";
import { fmtDate } from "@/lib/status";
import { Icon } from "@/components/Icon";
import { StatusBadge, Avatar } from "@/components/Status";
import { RenewalBanner } from "@/components/RenewalBanner";
import { q } from "@/lib/db";

export const metadata = { title: "Home" };

export default async function Home() {
  const s = await requirePage();
  if (s.role === "staff") redirect("/staff/scan");
  if (s.role === "admin") redirect("/admin");
  const m = await getMember(s.memberId!);
  if (!m) redirect("/login");
  const [anns, events, notes] = await Promise.all([
    announcementsFor(m, 3),
    upcomingEvents(m.id, 3),
    q<{ id: number; title: string; body: string; read: boolean }>(`SELECT id,title,body,read FROM notifications WHERE member_id=$1 ORDER BY created_at DESC LIMIT 2`, [m.id]),
  ]);
  const shortcuts = [
    { href: "/membership", label: "Membership card", icon: "card" },
    { href: "/announcements", label: "Announcements", icon: "megaphone" },
    { href: "/events", label: "Events", icon: "calendar" },
    { href: "/facilities", label: "Facilities", icon: "building" },
  ];
  return (
    <div className="space-y-6">
      <section className="card-pale p-5 flex items-center gap-4">
        <Avatar name={m.name} hue={m.avatar_hue} size={64} />
        <div className="min-w-0">
          <p className="text-slate">Hello,</p>
          <h1 className="text-2xl font-bold text-navy truncate">{m.name}</h1>
          <p className="text-sm text-slate">{m.category} · {m.membership_id}</p>
        </div>
      </section>

      <RenewalBanner status={m.computed} days={m.days} expiry={m.expiry_date} />

      <Link href="/membership" className="card p-5 flex items-center gap-4 hover:border-cyan">
        <span className="h-12 w-12 rounded-xl bg-pale grid place-items-center text-navy"><Icon name="crown" /></span>
        <div className="flex-1">
          <div className="flex items-center gap-2 flex-wrap"><StatusBadge status={m.computed} /></div>
          <p className="mt-1 font-medium text-navy">
            {m.lifetime ? "Life membership – no expiry" : <>Valid till {fmtDate(m.expiry_date)}{m.days >= 0 && <span className="text-slate font-normal"> · {m.days} day{m.days === 1 ? "" : "s"} left</span>}</>}
          </p>
        </div>
        <Icon name="arrow" className="text-slate" />
      </Link>

      <section aria-label="Shortcuts" className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {shortcuts.map((x) => (
          <Link key={x.href} href={x.href} className="card p-4 flex flex-col items-center gap-2 text-center min-h-28 justify-center hover:border-cyan">
            <Icon name={x.icon} size={32} className="text-navy-600" />
            <span className="font-medium text-navy">{x.label}</span>
          </Link>
        ))}
      </section>

      <section>
        <div className="flex items-baseline justify-between mb-2"><h2 className="h2">Latest announcements</h2><Link href="/announcements" className="text-cyan-700 font-medium min-h-11 grid place-items-center">View all</Link></div>
        <div className="card divide-y divide-line">
          {anns.length === 0 && <p className="p-5 muted">No announcements yet.</p>}
          {anns.map((a) => (
            <Link key={a.id} href={`/announcements/${a.id}`} className="flex gap-3 p-4 hover:bg-mist">
              <Icon name="megaphone" className="text-navy-600 mt-0.5 shrink-0" />
              <div className="min-w-0 flex-1">
                <p className={`text-navy ${a.read ? "font-medium" : "font-bold"}`}>{a.title}{!a.read && <span className="badge-blue ml-2 !py-0.5 !text-xs">New</span>}</p>
                <p className="muted line-clamp-2">{a.body}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-baseline justify-between mb-2"><h2 className="h2">Upcoming events</h2><Link href="/events" className="text-cyan-700 font-medium min-h-11 grid place-items-center">View all</Link></div>
        <div className="grid gap-3 sm:grid-cols-3">
          {events.map((e) => {
            const d = new Date(e.starts_at);
            return (
              <Link key={e.id} href="/events" className="card p-4 hover:border-cyan">
                <p className="text-xs font-bold text-cyan-700 uppercase">{new Intl.DateTimeFormat("en-SG", { timeZone: "Asia/Singapore", weekday: "short", day: "numeric", month: "short" }).format(d)}</p>
                <p className="font-bold text-navy mt-1">{e.title}</p>
                <p className="muted mt-1">{e.venue}</p>
                {e.registered && <span className="badge-green mt-2 !text-xs">Registered</span>}
              </Link>
            );
          })}
        </div>
      </section>

      <section>
        <div className="flex items-baseline justify-between mb-2"><h2 className="h2">Notification centre</h2><Link href="/notifications" className="text-cyan-700 font-medium min-h-11 grid place-items-center">Open</Link></div>
        <div className="card divide-y divide-line">
          {notes.length === 0 && <p className="p-5 muted">You&apos;re all caught up.</p>}
          {notes.map((n) => (
            <Link key={n.id} href="/notifications" className="flex gap-3 p-4 hover:bg-mist">
              <Icon name="bell" className={n.read ? "text-slate" : "text-cyan-700"} />
              <div><p className={`text-navy ${n.read ? "" : "font-bold"}`}>{n.title}</p><p className="muted line-clamp-1">{n.body}</p></div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
