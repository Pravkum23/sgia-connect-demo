import { requirePage } from "@/lib/guard";
import { q } from "@/lib/db";
import { Icon } from "@/components/Icon";

export const metadata = { title: "Facilities" };
const ICON: Record<string, string> = { "Cricket ground": "ball", "Sports facilities": "ball", "Function & event spaces": "building", "Food & beverage": "building" };

export default async function Facilities() {
  await requirePage(["member", "committee"]);
  const rows = await q<{ id: number; name: string; kind: string; description: string; hours: string | null; contact: string | null; placeholder: boolean }>(`SELECT * FROM facilities ORDER BY id`);
  return (
    <div className="space-y-5">
      <div><h1 className="h1">Facilities</h1><p className="muted">Directory only. Online booking and payments are not part of this prototype.</p></div>
      <div className="grid gap-4 md:grid-cols-2">
        {rows.map((f) => (
          <article key={f.id} className="card p-5 space-y-2">
            <div className="flex items-center gap-3"><span className="h-12 w-12 rounded-xl bg-pale grid place-items-center text-navy"><Icon name={ICON[f.kind] ?? "building"} /></span><div><h2 className="text-lg font-bold text-navy">{f.name}</h2><p className="muted">{f.kind}</p></div></div>
            <p className="text-slate">{f.description}</p>
            {f.hours && <p className="text-sm text-navy-700"><strong>Hours:</strong> {f.hours}</p>}
            {f.contact && <p className="text-sm text-navy-700"><strong>Contact:</strong> {f.contact}</p>}
            {f.placeholder && <span className="badge-gray">Placeholder content</span>}
          </article>
        ))}
      </div>
    </div>
  );
}
