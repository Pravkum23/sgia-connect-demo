import { requirePage } from "@/lib/guard";
import { getMember } from "@/lib/members";
import { q } from "@/lib/db";
import { fmtDate, fmtDateTime } from "@/lib/status";
import { RenewalForm } from "@/components/RenewalForm";
import { StatusBadge } from "@/components/Status";

export const metadata = { title: "Renewal (DEMO)" };

export default async function Renewal() {
  const s = await requirePage(["member", "committee"]);
  const m = (await getMember(s.memberId!))!;
  const reqs = await q<{ id: number; status: string; created_at: string }>(`SELECT id,status,created_at FROM renewal_requests WHERE member_id=$1 ORDER BY id DESC LIMIT 5`, [m.id]);
  return (
    <div className="max-w-xl space-y-5">
      <h1 className="h1">Membership renewal</h1>
      <div className="rounded-2xl bg-warn-bg border border-[#f1d49a] text-warn p-4 text-sm font-medium">DEMONSTRATION ONLY – no payment is collected and no real renewal takes place.</div>
      <div className="card p-5 space-y-2">
        <StatusBadge status={m.computed} />
        <p className="font-medium text-navy">{m.category}</p>
        <p className="muted">{m.lifetime ? "Life membership does not expire." : `Current expiry: ${fmtDate(m.expiry_date)} (${m.days >= 0 ? `${m.days} days remaining` : `expired ${-m.days} days ago`})`}</p>
      </div>
      <RenewalForm disabled={m.lifetime} />
      {reqs.length > 0 && (
        <section><h2 className="h2 mb-2">Your demo requests</h2>
          <ul className="card divide-y divide-line">{reqs.map((r) => (<li key={r.id} className="p-4 flex justify-between"><span className="text-navy font-medium capitalize">{r.status}</span><span className="muted">{fmtDateTime(r.created_at)}</span></li>))}</ul>
        </section>
      )}
    </div>
  );
}
