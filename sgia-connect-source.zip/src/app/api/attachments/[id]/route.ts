import { api, HttpError } from "@/lib/http";
import { one } from "@/lib/db";
import { VISIBLE_SQL } from "@/lib/content";
import { NextResponse } from "next/server";

export const GET = api<{ id: string }>("any", async ({ s, params }) => {
  const id = Number(params.id);
  if (!Number.isInteger(id)) throw new HttpError(400, "Invalid id.");
  const f = await one<{ filename: string; mime: string; data: Buffer; category: string | null }>(
    `SELECT t.filename, t.mime, t.data FROM attachments t JOIN announcements a ON a.id=t.announcement_id
      WHERE t.id=$1 AND ($2 OR (${VISIBLE_SQL} AND (a.audience='all' OR a.audience=(SELECT category FROM members WHERE id=$3))))`,
    [id, s.role === "admin" || s.role === "committee", s.memberId],
  );
  if (!f) throw new HttpError(404, "Not found.");
  return new NextResponse(new Uint8Array(f.data), {
    headers: {
      "content-type": f.mime,
      "content-disposition": `inline; filename="${f.filename.replace(/[^\w.\- ]/g, "_")}"`,
      "x-content-type-options": "nosniff",
      "content-security-policy": "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox",
      "cache-control": "private, max-age=300",
    },
  });
});
