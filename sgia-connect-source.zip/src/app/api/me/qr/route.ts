import QRCode from "qrcode";
import { NextResponse } from "next/server";
import { api, HttpError } from "@/lib/http";
import { one } from "@/lib/db";
import { qrPayload } from "@/lib/members";

export const GET = api(["member", "committee"], async ({ req, s }) => {
  if (!s.memberId) throw new HttpError(404, "No membership record.");
  const m = await one<{ qr_token: string; membership_id: string }>(`SELECT qr_token, membership_id FROM members WHERE id=$1`, [s.memberId]);
  if (!m) throw new HttpError(404, "No membership record.");
  const png = await QRCode.toBuffer(await qrPayload(m.qr_token), { width: 720, margin: 3, errorCorrectionLevel: "M", color: { dark: "#001f3d", light: "#ffffff" } });
  const dl = new URL(req.url).searchParams.get("download");
  return new NextResponse(new Uint8Array(png), {
    headers: {
      "content-type": "image/png",
      "cache-control": "private, no-store",
      ...(dl ? { "content-disposition": `attachment; filename="${m.membership_id}-DEMO-QR.png"` } : {}),
    },
  });
});
