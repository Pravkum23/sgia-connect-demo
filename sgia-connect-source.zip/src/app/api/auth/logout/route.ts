import { api } from "@/lib/http";
import { destroySession } from "@/lib/auth";
import { audit } from "@/lib/audit";

export const POST = api("any", async ({ s }) => {
  await destroySession();
  await audit({ id: s.accountId, name: s.loginId }, "logout");
  return { ok: true };
});
