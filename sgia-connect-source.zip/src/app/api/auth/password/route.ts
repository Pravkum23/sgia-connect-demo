import { z } from "zod";
import bcrypt from "bcryptjs";
import { api, body, HttpError } from "@/lib/http";
import { one, q } from "@/lib/db";
import { hashPassword, passwordProblem } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { allow } from "@/lib/rate";
import { cookies } from "next/headers";
import { COOKIE } from "@/lib/auth";
import { sha256 } from "@/lib/tokens";

const Schema = z.object({ current: z.string().min(1).max(128), next: z.string().min(1).max(128) });

export const POST = api("any", async ({ req, s }) => {
  if (!(await allow(`pw:${s.accountId}`, 8, 900))) throw new HttpError(429, "Too many attempts. Please wait and try again.");
  const { current, next } = await body(req, Schema);
  const acc = await one<{ password_hash: string }>(`SELECT password_hash FROM accounts WHERE id=$1`, [s.accountId]);
  if (!acc || !(await bcrypt.compare(current, acc.password_hash))) throw new HttpError(400, "Your current password is incorrect.");
  const problem = passwordProblem(next, s.loginId);
  if (problem) throw new HttpError(400, problem);
  await q(`UPDATE accounts SET password_hash=$2 WHERE id=$1`, [s.accountId, await hashPassword(next)]);
  // Sign out every other session for this account, keep this one.
  const token = (await cookies()).get(COOKIE)?.value;
  await q(`DELETE FROM sessions WHERE account_id=$1 AND token_hash <> $2`, [s.accountId, token ? sha256(token) : ""]);
  await audit({ id: s.accountId, name: s.loginId }, "password.changed");
  return { ok: true };
});
