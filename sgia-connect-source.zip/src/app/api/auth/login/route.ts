import { z } from "zod";
import { NextResponse } from "next/server";
import { publicApi, body } from "@/lib/http";
import { login } from "@/lib/auth";

const Schema = z.object({ loginId: z.string().min(3).max(40), password: z.string().min(1).max(128) });

export const POST = publicApi(async ({ req }) => {
  const { loginId, password } = await body(req as never, Schema);
  const r = await login(loginId, password, req);
  if (!r.ok) return NextResponse.json({ error: r.error }, { status: r.status });
  const next = r.role === "staff" ? "/staff/scan" : r.role === "admin" ? "/admin" : "/";
  return { ok: true, next };
});
