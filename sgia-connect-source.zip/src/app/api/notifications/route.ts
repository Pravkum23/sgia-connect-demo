import { api, HttpError } from "@/lib/http";
import { q } from "@/lib/db";

export const POST = api(["member", "committee"], async ({ s }) => {
  if (!s.memberId) throw new HttpError(400, "No membership record.");
  await q(`UPDATE notifications SET read=true WHERE member_id=$1`, [s.memberId]);
  return { ok: true };
});
