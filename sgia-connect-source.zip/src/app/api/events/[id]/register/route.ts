import { api, HttpError } from "@/lib/http";
import { one, q, tx } from "@/lib/db";
import { notifyMember } from "@/lib/notify";
import { allow } from "@/lib/rate";
import { computeStatus } from "@/lib/status";

async function ctx(s: { memberId: number | null; accountId: number }, id: string) {
  const eid = Number(id);
  if (!Number.isInteger(eid) || !s.memberId) throw new HttpError(400, "Invalid request.");
  if (!(await allow(`evreg:${s.accountId}`, 30, 600))) throw new HttpError(429, "Too many requests.");
  const ev = await one<{ id: number; title: string; capacity: number | null; starts_at: string }>(`SELECT id,title,capacity,starts_at FROM events WHERE id=$1 AND published=true`, [eid]);
  if (!ev) throw new HttpError(404, "Event not found.");
  return { ev, mid: s.memberId };
}

export const POST = api<{ id: string }>(["member", "committee"], async ({ s, params }) => {
  const { ev, mid } = await ctx(s, params.id);
  const m = await one<{ status: string; expiry_date: string; deactivated: boolean }>(`SELECT status,expiry_date,deactivated FROM members WHERE id=$1`, [mid]);
  const st = computeStatus(m!);
  if (st === "suspended" || st === "inactive") throw new HttpError(403, "Your membership status does not allow event registration. Please contact the SGIA office.");
  await tx(async (t) => {
    const cnt = (await t<{ n: number }>(`SELECT count(*)::int AS n FROM event_registrations WHERE event_id=$1`, [ev.id]))[0].n;
    const already = await t(`SELECT 1 FROM event_registrations WHERE event_id=$1 AND member_id=$2`, [ev.id, mid]);
    if (already.length) return;
    if (ev.capacity && cnt >= ev.capacity) throw new HttpError(409, "Sorry, this event is full.");
    await t(`INSERT INTO event_registrations(event_id,member_id) VALUES ($1,$2)`, [ev.id, mid]);
  });
  await notifyMember(mid, "event", { title: `Registered: ${ev.title}`, body: "Your demonstration registration is confirmed.", url: "/events" });
  return { ok: true };
});

export const DELETE = api<{ id: string }>(["member", "committee"], async ({ s, params }) => {
  const { ev, mid } = await ctx(s, params.id);
  await q(`DELETE FROM event_registrations WHERE event_id=$1 AND member_id=$2`, [ev.id, mid]);
  return { ok: true };
});
