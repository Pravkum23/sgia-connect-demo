import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { one, q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { publishAnnouncement } from "@/lib/admin";

const Schema = z.object({
  action: z.enum(["publish", "archive", "draft", "schedule", "save"]),
  title: z.string().trim().min(3).max(120).optional(),
  body: z.string().trim().min(3).max(5000).optional(),
  publish_at: z.string().optional(),
});

export const PATCH = api<{ id: string }>(ADMIN_ROLES, async ({ req, s, params }) => {
  const id = Number(params.id);
  const b = await body(req, Schema);
  const a = await one<{ id: number; state: string }>(`SELECT id,state FROM announcements WHERE id=$1`, [id]);
  if (!a) throw new HttpError(404, "Announcement not found.");
  if (b.title) await q(`UPDATE announcements SET title=$2 WHERE id=$1`, [id, b.title]);
  if (b.body) await q(`UPDATE announcements SET body=$2 WHERE id=$1`, [id, b.body]);
  let delivery = null;
  if (b.action === "publish") {
    if (a.state === "published") throw new HttpError(409, "Already published.");
    delivery = await publishAnnouncement(id, { id: s.accountId, name: s.loginId });
  } else if (b.action === "archive") await q(`UPDATE announcements SET state='archived' WHERE id=$1`, [id]);
  else if (b.action === "draft") await q(`UPDATE announcements SET state='draft', publish_at=NULL WHERE id=$1`, [id]);
  else if (b.action === "schedule") {
    const at = b.publish_at ? new Date(b.publish_at.length === 16 ? b.publish_at + ":00+08:00" : b.publish_at) : null;
    if (!at || Number.isNaN(+at) || +at < Date.now() - 60000) throw new HttpError(400, "Choose a future date and time.");
    await q(`UPDATE announcements SET state='scheduled', publish_at=$2 WHERE id=$1`, [id, at]);
  }
  await audit({ id: s.accountId, name: s.loginId }, `announcement.${b.action}`, `#${id}`);
  return { ok: true, delivery };
});

export const DELETE = api<{ id: string }>(ADMIN_ROLES, async ({ s, params }) => {
  const id = Number(params.id);
  const a = await one<{ state: string }>(`SELECT state FROM announcements WHERE id=$1`, [id]);
  if (!a) throw new HttpError(404, "Not found.");
  if (a.state === "published") throw new HttpError(409, "Archive a published announcement instead of deleting it.");
  await q(`DELETE FROM announcements WHERE id=$1`, [id]);
  await audit({ id: s.accountId, name: s.loginId }, "announcement.deleted", `#${id}`);
  return { ok: true };
});
