import { api, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { saveFiles } from "@/lib/uploads";
import { audit } from "@/lib/audit";

export const POST = api<{ id: string }>(ADMIN_ROLES, async ({ req, s, params }) => {
  const fd = await req.formData();
  const files = fd.getAll("files").filter((x): x is File => typeof x !== "string" && x.size > 0);
  if (!files.length) throw new HttpError(400, "Choose a file.");
  await saveFiles(Number(params.id), files);
  await audit({ id: s.accountId, name: s.loginId }, "announcement.attachment-added", `#${params.id}`);
  return { ok: true };
});
