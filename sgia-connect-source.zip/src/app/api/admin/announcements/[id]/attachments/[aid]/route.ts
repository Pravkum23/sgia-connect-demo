import { api } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { audit } from "@/lib/audit";

export const DELETE = api<{ id: string; aid: string }>(ADMIN_ROLES, async ({ s, params }) => {
  await q(`DELETE FROM attachments WHERE id=$1 AND announcement_id=$2`, [Number(params.aid), Number(params.id)]);
  await audit({ id: s.accountId, name: s.loginId }, "announcement.attachment-removed", `#${params.id}`);
  return { ok: true };
});
