import { z } from "zod";
import { api, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { one } from "@/lib/db";
import { audit } from "@/lib/audit";
import { publishAnnouncement } from "@/lib/admin";
import { saveFiles } from "@/lib/uploads";
import { CATEGORIES } from "@/lib/members";

export const Fields = z.object({
  title: z.string().trim().min(3, "Title is too short.").max(120),
  body: z.string().trim().min(3, "Please add a description.").max(5000),
  category: z.enum(["Events", "Notices", "Community"]),
  audience: z.string().refine((a) => a === "all" || CATEGORIES.includes(a), "Unknown audience."),
  action: z.enum(["draft", "publish", "schedule"]),
  publish_at: z.string().optional(),
});

export const POST = api(ADMIN_ROLES, async ({ req, s }) => {
  const fd = await req.formData();
  const f = Fields.parse(Object.fromEntries([...fd.entries()].filter(([, v]) => typeof v === "string")));
  const files = fd.getAll("files").filter((x): x is File => typeof x !== "string" && x.size > 0);
  let publishAt: Date | null = null;
  if (f.action === "schedule") {
    publishAt = f.publish_at ? new Date(f.publish_at.length === 16 ? f.publish_at + ":00+08:00" : f.publish_at) : null;
    if (!publishAt || Number.isNaN(+publishAt) || publishAt.getTime() < Date.now() - 60000) throw new HttpError(400, "Choose a future date and time to schedule.");
  }
  const state = f.action === "schedule" ? "scheduled" : "draft";
  const row = await one<{ id: number }>(
    `INSERT INTO announcements(title,body,category,audience,state,publish_at,author) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [f.title, f.body, f.category, f.audience, state, publishAt, s.name],
  );
  try { await saveFiles(row!.id, files); } catch (e) { await one(`DELETE FROM announcements WHERE id=$1`, [row!.id]); throw e; }
  await audit({ id: s.accountId, name: s.loginId }, "announcement.created", `#${row!.id}`, `${f.action}: ${f.title}`);
  let result = null;
  if (f.action === "publish") result = await publishAnnouncement(row!.id, { id: s.accountId, name: s.loginId });
  return { ok: true, id: row!.id, delivery: result };
});
