import { z } from "zod";
import { api, body } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
export const PATCH = api<{ id: string }>(ADMIN_ROLES, async ({ req, params }) => {
  const { resolved } = await body(req, z.object({ resolved: z.boolean() }));
  await q(`UPDATE feedback SET resolved=$2 WHERE id=$1`, [Number(params.id), resolved]);
  return { ok: true };
});
