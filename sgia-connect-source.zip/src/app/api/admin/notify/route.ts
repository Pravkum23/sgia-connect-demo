import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { audienceMembers } from "@/lib/admin";
import { notifyMany } from "@/lib/notify";
import { audit } from "@/lib/audit";
import { allow } from "@/lib/rate";
import { CATEGORIES } from "@/lib/members";

const Schema = z.object({ title: z.string().trim().min(3).max(80), body: z.string().trim().min(3).max(240), audience: z.string().refine((a) => a === "all" || CATEGORIES.includes(a)) });

export const POST = api(ADMIN_ROLES, async ({ req, s }) => {
  if (!(await allow(`broadcast:${s.accountId}`, 10, 3600))) throw new HttpError(429, "Too many broadcasts. Please wait.");
  const b = await body(req, Schema);
  const ids = await audienceMembers(b.audience);
  const res = await notifyMany(ids, "admin", { title: b.title, body: b.body, url: "/notifications" });
  await audit({ id: s.accountId, name: s.loginId }, "notice.broadcast", b.audience, `${res.recipients} recipients, ${res.pushSent} push accepted: ${b.title}`);
  return { ok: true, ...res };
});
