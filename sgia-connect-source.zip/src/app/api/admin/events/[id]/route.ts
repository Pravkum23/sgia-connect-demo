import { api, body, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { EventSchema, sgt } from "../route";

export const PATCH = api<{ id: string }>(ADMIN_ROLES, async ({ req, s, params }) => {
  const e = await body(req, EventSchema.partial());
  const id = Number(params.id);
  const cols = Object.entries(e).filter(([, v]) => v !== undefined).map(([k, v]) => [k, k === "starts_at" ? sgt(v as string) : v] as const);
  if (!cols.length) throw new HttpError(400, "Nothing to update.");
  await q(`UPDATE events SET ${cols.map(([k], i) => `${k}=$${i + 2}`).join(", ")} WHERE id=$1`, [id, ...cols.map(([, v]) => v)]);
  await audit({ id: s.accountId, name: s.loginId }, "event.updated", `#${id}`);
  return { ok: true };
});

export const DELETE = api<{ id: string }>(ADMIN_ROLES, async ({ s, params }) => {
  await q(`DELETE FROM events WHERE id=$1`, [Number(params.id)]);
  await audit({ id: s.accountId, name: s.loginId }, "event.deleted", `#${params.id}`);
  return { ok: true };
});
