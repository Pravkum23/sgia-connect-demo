import { z } from "zod";
import { api, body } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { one } from "@/lib/db";
import { audit } from "@/lib/audit";

export const EventSchema = z.object({
  title: z.string().trim().min(3).max(120),
  starts_at: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "Choose a date and time."),
  venue: z.string().trim().min(2).max(120),
  description: z.string().trim().min(3).max(2000),
  capacity: z.number().int().min(1).max(5000).nullable().optional(),
  hue: z.number().int().min(0).max(360).optional(),
  published: z.boolean().optional(),
});
export const sgt = (s: string) => (s.length === 16 ? s + ":00+08:00" : s);

export const POST = api(ADMIN_ROLES, async ({ req, s }) => {
  const e = await body(req, EventSchema);
  const r = await one<{ id: number }>(`INSERT INTO events(title,starts_at,venue,description,capacity,hue,published) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [e.title, sgt(e.starts_at), e.venue, e.description, e.capacity ?? null, e.hue ?? Math.floor(Math.random() * 360), e.published ?? true]);
  await audit({ id: s.accountId, name: s.loginId }, "event.created", `#${r!.id}`, e.title);
  return { ok: true, id: r!.id };
});
