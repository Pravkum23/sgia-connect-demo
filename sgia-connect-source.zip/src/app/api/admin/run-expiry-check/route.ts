import { api } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { runExpiryCheck } from "@/lib/admin";
export const POST = api(ADMIN_ROLES, async ({ s }) => runExpiryCheck({ id: s.accountId, name: s.loginId }));
