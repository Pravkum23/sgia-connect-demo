import { z } from "zod";
import { api, body } from "@/lib/http";
import { ADMIN_ROLES, hashPassword } from "@/lib/auth";
import { createMember } from "@/lib/admin";
import { q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { newPassword } from "@/lib/tokens";
import { category, isoDate, mobile, personName, syntheticEmail } from "@/lib/validate";

const Schema = z.object({ name: personName, category, email: syntheticEmail, mobile, join_date: isoDate, expiry_date: isoDate });

export const POST = api(ADMIN_ROLES, async ({ req, s }) => {
  const b = await body(req, Schema);
  const m = await createMember(b);
  const pw = newPassword();
  await q(`INSERT INTO accounts(login_id,password_hash,role,member_id,display_name) VALUES ($1,$2,'member',$3,$4)`, [m.membership_id, await hashPassword(pw), m.id, b.name]);
  await audit({ id: s.accountId, name: s.loginId }, "member.created", m.membership_id);
  return { ok: true, id: m.id, membership_id: m.membership_id, temporaryPassword: pw };
});
