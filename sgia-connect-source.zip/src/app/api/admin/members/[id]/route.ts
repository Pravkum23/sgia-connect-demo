import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { one, q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { category, isoDate, mobile, personName, syntheticEmail } from "@/lib/validate";

const Schema = z.object({
  name: personName.optional(), category: category.optional(), email: syntheticEmail.optional(), mobile,
  expiry_date: isoDate.optional(), status: z.enum(["active", "suspended"]).optional(), deactivated: z.boolean().optional(),
});

export const PATCH = api<{ id: string }>(ADMIN_ROLES, async ({ req, s, params }) => {
  const id = Number(params.id);
  if (!Number.isInteger(id)) throw new HttpError(400, "Invalid id.");
  const b = await body(req, Schema);
  const before = await one<Record<string, unknown>>(`SELECT * FROM members WHERE id=$1`, [id]);
  if (!before) throw new HttpError(404, "Member not found.");
  const cols = Object.entries(b).filter(([, v]) => v !== undefined);
  if (cols.length === 0) throw new HttpError(400, "Nothing to update.");
  const set = cols.map(([k], i) => `${k}=$${i + 2}`).join(", ");
  await q(`UPDATE members SET ${set} WHERE id=$1`, [id, ...cols.map(([, v]) => v)]);
  if (b.name) await q(`UPDATE accounts SET display_name=$2 WHERE member_id=$1 AND role='member'`, [id, b.name]);
  if (b.deactivated === true) await q(`DELETE FROM sessions WHERE account_id IN (SELECT id FROM accounts WHERE member_id=$1)`, [id]);
  const changes = cols.map(([k, v]) => `${k}: ${String(before[k] ?? "")} → ${String(v)}`).join("; ");
  await audit({ id: s.accountId, name: s.loginId }, "member.updated", String(before.membership_id), changes);
  return { ok: true };
});
