import { api, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { one } from "@/lib/db";
import { audit } from "@/lib/audit";
import { newToken } from "@/lib/tokens";

export const POST = api<{ id: string }>(ADMIN_ROLES, async ({ s, params }) => {
  const r = await one<{ membership_id: string }>(`UPDATE members SET qr_token=$2 WHERE id=$1 RETURNING membership_id`, [Number(params.id), newToken()]);
  if (!r) throw new HttpError(404, "Member not found.");
  await audit({ id: s.accountId, name: s.loginId }, "member.qr-rotated", r.membership_id, "old QR code no longer valid");
  return { ok: true };
});
