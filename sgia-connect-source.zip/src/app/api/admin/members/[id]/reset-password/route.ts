import { api, HttpError } from "@/lib/http";
import { ADMIN_ROLES, hashPassword } from "@/lib/auth";
import { one, q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { newPassword } from "@/lib/tokens";

export const POST = api<{ id: string }>(ADMIN_ROLES, async ({ s, params }) => {
  const id = Number(params.id);
  const acc = await one<{ id: number; login_id: string }>(`SELECT id, login_id FROM accounts WHERE member_id=$1 AND role='member'`, [id]);
  if (!acc) throw new HttpError(404, "Account not found.");
  const pw = newPassword();
  await q(`UPDATE accounts SET password_hash=$2, failed_attempts=0, locked_until=NULL WHERE id=$1`, [acc.id, await hashPassword(pw)]);
  await q(`DELETE FROM sessions WHERE account_id=$1`, [acc.id]);
  await audit({ id: s.accountId, name: s.loginId }, "member.password-reset", acc.login_id);
  return { ok: true, temporaryPassword: pw };
});
