import Papa from "papaparse";
import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { ADMIN_ROLES, hashPassword } from "@/lib/auth";
import { createMember } from "@/lib/admin";
import { q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { newPassword } from "@/lib/tokens";
import { category, isoDate, mobile, personName, syntheticEmail } from "@/lib/validate";

const Row = z.object({ name: personName, category, email: syntheticEmail, mobile, join_date: isoDate, expiry_date: isoDate });

export const POST = api(ADMIN_ROLES, async ({ req, s }) => {
  const { csv } = await body(req, z.object({ csv: z.string().max(60_000) }));
  const parsed = Papa.parse<Record<string, string>>(csv.trim(), { header: true, skipEmptyLines: true, transformHeader: (h) => h.trim().toLowerCase() });
  if (parsed.data.length === 0) throw new HttpError(400, "The CSV has no rows. Expected columns: name, category, email, mobile, join_date, expiry_date.");
  if (parsed.data.length > 200) throw new HttpError(400, "Import is limited to 200 rows at a time.");
  const errors: string[] = [];
  const ok: z.infer<typeof Row>[] = [];
  parsed.data.forEach((r, i) => {
    const res = Row.safeParse({ ...r, mobile: r.mobile || undefined });
    if (res.success) ok.push(res.data); else errors.push(`Row ${i + 2}: ${res.error.issues[0].message}`);
  });
  if (errors.length) return { ok: false, created: 0, errors: errors.slice(0, 20) }; // all-or-nothing
  for (const r of ok) {
    const m = await createMember(r);
    await q(`INSERT INTO accounts(login_id,password_hash,role,member_id,display_name) VALUES ($1,$2,'member',$3,$4)`, [m.membership_id, await hashPassword(newPassword()), m.id, r.name]);
  }
  await audit({ id: s.accountId, name: s.loginId }, "member.imported", undefined, `${ok.length} synthetic records`);
  return { ok: true, created: ok.length, errors: [] };
});
