import { NextResponse } from "next/server";
import { api } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { csvCell } from "@/lib/validate";
import { computeStatus } from "@/lib/status";

// Deliberately excludes passwords, password hashes and QR tokens.
export const GET = api(ADMIN_ROLES, async ({ s }) => {
  const rows = await q<{ membership_id: string; name: string; category: string; status: "active" | "suspended"; join_date: string; expiry_date: string; email: string; mobile: string; deactivated: boolean }>(
    `SELECT membership_id,name,category,status,join_date,expiry_date,email,mobile,deactivated FROM members ORDER BY id`);
  const head = ["membership_id", "name", "category", "status", "join_date", "expiry_date", "email", "mobile"];
  const lines = [head.join(",")];
  for (const r of rows) lines.push([r.membership_id, r.name, r.category, computeStatus(r), r.join_date, r.expiry_date, r.email, r.mobile].map(csvCell).join(","));
  await audit({ id: s.accountId, name: s.loginId }, "member.exported", undefined, `${rows.length} rows`);
  return new NextResponse(lines.join("\n") + "\n", { headers: { "content-type": "text/csv; charset=utf-8", "content-disposition": 'attachment; filename="sgia-demo-members.csv"', "cache-control": "no-store" } });
});
