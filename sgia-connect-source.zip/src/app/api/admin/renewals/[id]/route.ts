import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { ADMIN_ROLES } from "@/lib/auth";
import { one, q } from "@/lib/db";
import { audit } from "@/lib/audit";
import { addDays, sgToday } from "@/lib/status";
import { notifyMember } from "@/lib/notify";

export const POST = api<{ id: string }>(ADMIN_ROLES, async ({ req, s, params }) => {
  const { action } = await body(req, z.object({ action: z.enum(["approve", "decline"]) }));
  const r = await one<{ id: number; member_id: number; status: string }>(`SELECT * FROM renewal_requests WHERE id=$1`, [Number(params.id)]);
  if (!r || r.status !== "requested") throw new HttpError(404, "Open request not found.");
  const m = (await one<{ expiry_date: string; membership_id: string }>(`SELECT expiry_date, membership_id FROM members WHERE id=$1`, [r.member_id]))!;
  if (action === "approve") {
    const base = m.expiry_date > sgToday() ? m.expiry_date : sgToday();
    await q(`UPDATE members SET expiry_date=$2 WHERE id=$1`, [r.member_id, addDays(base, 365)]);
    await q(`UPDATE renewal_requests SET status='approved' WHERE id=$1`, [r.id]);
    await notifyMember(r.member_id, "admin", { title: "Renewal approved (DEMO)", body: "Your demonstration membership has been extended by one year.", url: "/membership" });
  } else {
    await q(`UPDATE renewal_requests SET status='declined' WHERE id=$1`, [r.id]);
    await notifyMember(r.member_id, "admin", { title: "Renewal request declined (DEMO)", body: "Please contact the SGIA office.", url: "/renewal" });
  }
  await audit({ id: s.accountId, name: s.loginId }, `renewal.${action}`, m.membership_id);
  return { ok: true };
});
