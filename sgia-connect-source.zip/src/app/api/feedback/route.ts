import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { q } from "@/lib/db";
import { allow } from "@/lib/rate";

const Schema = z.object({
  kind: z.enum(["Bug", "Design suggestion", "Missing feature", "Accessibility problem", "Notification issue"]),
  page: z.string().max(120).optional(),
  device: z.string().max(400).optional(),
  message: z.string().min(5).max(2000),
});

export const POST = api(["committee", "admin"], async ({ req, s }) => {
  if (!(await allow(`fb:${s.accountId}`, 20, 3600))) throw new HttpError(429, "Too many submissions. Please try again later.");
  const f = await body(req, Schema);
  await q(`INSERT INTO feedback(account_id,author,kind,page,device,message) VALUES ($1,$2,$3,$4,$5,$6)`, [s.accountId, s.name, f.kind, f.page || null, f.device || null, f.message]);
  return { ok: true };
});
