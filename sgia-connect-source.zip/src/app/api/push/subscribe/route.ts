import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { q } from "@/lib/db";
import { allow } from "@/lib/rate";

const Sub = z.object({ endpoint: z.string().url().max(1000).startsWith("https://"), keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }) });

export const POST = api("any", async ({ req, s }) => {
  if (!(await allow(`sub:${s.accountId}`, 20, 3600))) throw new HttpError(429, "Too many requests.");
  const sub = await body(req, Sub);
  await q(
    `INSERT INTO push_subscriptions(account_id,endpoint,p256dh,auth,user_agent) VALUES ($1,$2,$3,$4,$5)
     ON CONFLICT (endpoint) DO UPDATE SET account_id=$1, p256dh=$3, auth=$4, user_agent=$5`,
    [s.accountId, sub.endpoint, sub.keys.p256dh, sub.keys.auth, req.headers.get("user-agent")?.slice(0, 200) ?? null],
  );
  return { ok: true };
});

export const DELETE = api("any", async ({ req, s }) => {
  const { endpoint } = await body(req, z.object({ endpoint: z.string().max(1000) }));
  await q(`DELETE FROM push_subscriptions WHERE endpoint=$1 AND account_id=$2`, [endpoint, s.accountId]);
  return { ok: true };
});

export const GET = api("any", async ({ s }) => {
  const r = await q<{ n: number }>(`SELECT count(*)::int AS n FROM push_subscriptions WHERE account_id=$1`, [s.accountId]);
  return { devices: r[0].n };
});
