import { api, HttpError } from "@/lib/http";
import { notifyMember } from "@/lib/notify";
import { allow } from "@/lib/rate";

export const POST = api(["member", "committee"], async ({ s }) => {
  if (!s.memberId) throw new HttpError(400, "No membership record.");
  if (!(await allow(`pushtest:${s.accountId}`, 6, 600))) throw new HttpError(429, "Too many test notifications. Please wait a few minutes.");
  const attempts = await notifyMember(s.memberId, "test", { title: "SGIA Connect test notification", body: "If you can see this outside the app, push notifications work on this device.", url: "/notifications", tag: "sgia-test" });
  return { attempts };
});
