import { api } from "@/lib/http";
import { pushConfigured } from "@/lib/push";
export const GET = api("any", async () => ({ configured: pushConfigured(), key: process.env.VAPID_PUBLIC_KEY ?? null }));
