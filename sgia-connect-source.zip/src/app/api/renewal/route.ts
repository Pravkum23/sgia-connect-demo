import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { q } from "@/lib/db";
import { allow } from "@/lib/rate";
import { notifyMember } from "@/lib/notify";

export const POST = api(["member", "committee"], async ({ req, s }) => {
  if (!s.memberId) throw new HttpError(400, "No membership record.");
  if (!(await allow(`renew:${s.accountId}`, 5, 3600))) throw new HttpError(429, "Too many requests. Please try again later.");
  const { note } = await body(req, z.object({ note: z.string().max(300).optional() }));
  const open = await q(`SELECT 1 FROM renewal_requests WHERE member_id=$1 AND status='requested'`, [s.memberId]);
  if (open.length) throw new HttpError(409, "You already have an open demo renewal request.");
  await q(`INSERT INTO renewal_requests(member_id,note) VALUES ($1,$2)`, [s.memberId, note ?? null]);
  await notifyMember(s.memberId, "admin", { title: "Renewal request received (DEMO)", body: "No payment was taken. An administrator can approve this demonstration request.", url: "/renewal" });
  return { ok: true };
});
