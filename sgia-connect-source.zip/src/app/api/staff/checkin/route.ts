import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { one, q } from "@/lib/db";
import { allow } from "@/lib/rate";
import { computeStatus } from "@/lib/status";
import { STAFF_ROLES } from "@/lib/auth";
import type { MemberRow } from "@/lib/members";

export const POST = api(STAFF_ROLES, async ({ req, s }) => {
  if (!(await allow(`checkin:${s.accountId}`, 60, 60))) throw new HttpError(429, "Too many requests.");
  const { memberId } = await body(req, z.object({ memberId: z.number().int().positive() }));
  const m = await one<MemberRow>(`SELECT * FROM members WHERE id=$1`, [memberId]);
  if (!m) throw new HttpError(404, "Member not found.");
  const st = computeStatus(m);
  if (st === "expired" || st === "suspended" || st === "inactive") {
    await q(`INSERT INTO verifications(staff_id,member_id,method,result,checked_in,note) VALUES ($1,$2,'checkin',$3,false,'check-in refused')`, [s.accountId, m.id, st]);
    throw new HttpError(409, `Check-in refused: membership is ${st}.`);
  }
  const recent = await one(`SELECT 1 FROM verifications WHERE member_id=$1 AND checked_in AND at > now() - interval '2 minutes'`, [m.id]);
  if (recent) throw new HttpError(409, "This member was already checked in a moment ago.");
  const v = await one<{ at: string }>(`INSERT INTO verifications(staff_id,member_id,method,result,checked_in) VALUES ($1,$2,'checkin',$3,true) RETURNING at`, [s.accountId, m.id, st]);
  return { ok: true, at: new Date(v!.at).toISOString() };
});
