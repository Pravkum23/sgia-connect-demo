import { z } from "zod";
import { api, body, HttpError } from "@/lib/http";
import { allow } from "@/lib/rate";
import { verifyLookup } from "@/lib/verify";
import { STAFF_ROLES } from "@/lib/auth";

const Schema = z.object({ token: z.string().max(200).optional(), membershipId: z.string().max(40).optional(), method: z.enum(["qr", "manual"]).default("qr") })
  .refine((v) => v.token || v.membershipId, { message: "Provide a QR code or membership ID." });

export const POST = api(STAFF_ROLES, async ({ req, s }) => {
  if (!(await allow(`verify:${s.accountId}`, 90, 60))) throw new HttpError(429, "Too many lookups. Please wait a moment.");
  const b = await body(req, Schema);
  return verifyLookup(s.accountId, { token: b.token, membershipId: b.membershipId }, b.method);
});
