import { NextRequest, NextResponse } from "next/server";
import { ZodError, type ZodType } from "zod";
import { currentSession, type Role, type Session } from "./auth";

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

function sameOrigin(req: NextRequest) {
  const origin = req.headers.get("origin");
  if (!origin) return true; // non-browser clients; cookies are SameSite=Lax so cross-site browsers can't ride a session
  try {
    return new URL(origin).host === req.headers.get("host");
  } catch {
    return false;
  }
}

type Ctx<P> = { req: NextRequest; s: Session; params: P };

/** Authenticated JSON endpoint. Authorization is enforced HERE, on the server, for every call. */
export function api<P = Record<string, string>>(roles: Role[] | "any", fn: (c: Ctx<P>) => Promise<unknown>) {
  return async (req: NextRequest, ctx: { params: Promise<P> }) => {
    try {
      if (!["GET", "HEAD"].includes(req.method) && !sameOrigin(req)) throw new HttpError(403, "Cross-site request blocked.");
      const s = await currentSession();
      if (!s) throw new HttpError(401, "Please sign in.");
      if (roles !== "any" && !roles.includes(s.role)) throw new HttpError(403, "You do not have permission to do that.");
      const out = await fn({ req, s, params: await (ctx?.params ?? Promise.resolve({} as P)) });
      if (out instanceof Response) return out;
      return NextResponse.json(out ?? { ok: true });
    } catch (e) {
      return errorResponse(e);
    }
  };
}

export function publicApi<P = Record<string, string>>(fn: (c: { req: NextRequest; params: P }) => Promise<unknown>) {
  return async (req: NextRequest, ctx: { params: Promise<P> }) => {
    try {
      if (!["GET", "HEAD"].includes(req.method) && !sameOrigin(req)) throw new HttpError(403, "Cross-site request blocked.");
      const out = await fn({ req, params: await (ctx?.params ?? Promise.resolve({} as P)) });
      if (out instanceof Response) return out;
      return NextResponse.json(out ?? { ok: true });
    } catch (e) {
      return errorResponse(e);
    }
  };
}

function errorResponse(e: unknown) {
  if (e instanceof HttpError) return NextResponse.json({ error: e.message }, { status: e.status });
  if (e instanceof ZodError) {
    return NextResponse.json({ error: e.issues[0]?.message || "Invalid input.", field: e.issues[0]?.path.join(".") }, { status: 400 });
  }
  console.error(e);
  return NextResponse.json({ error: "Something went wrong. Please try again." }, { status: 500 });
}

export async function body<T>(req: NextRequest, schema: ZodType<T>): Promise<T> {
  const text = await req.text();
  if (text.length > 100_000) throw new HttpError(413, "Request too large.");
  let raw: unknown;
  try {
    raw = JSON.parse(text || "{}");
  } catch {
    throw new HttpError(400, "Invalid JSON.");
  }
  return schema.parse(raw);
}
