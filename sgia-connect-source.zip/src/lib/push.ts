import webpush from "web-push";
import { q } from "./db";

let configured = false;
export function pushConfigured() {
  return !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}
function setup() {
  if (configured || !pushConfigured()) return;
  webpush.setVapidDetails(process.env.VAPID_SUBJECT || "mailto:admin@sgia.sg", process.env.VAPID_PUBLIC_KEY!, process.env.VAPID_PRIVATE_KEY!);
  configured = true;
}

export interface Payload { title: string; body: string; url?: string; tag?: string }
export interface Attempt { outcome: "sent" | "failed" | "expired" | "no-subscription" | "not-configured"; status?: number; detail?: string }

/** Sends a web push to every subscription belonging to the member's account(s). Returns the attempts; each is also logged. */
export async function pushToMember(memberId: number, kind: string, p: Payload): Promise<Attempt[]> {
  const out: Attempt[] = [];
  const log = (a: Attempt) =>
    q(`INSERT INTO delivery_log(member_id,channel,kind,title,outcome,http_status,detail) VALUES ($1,'webpush',$2,$3,$4,$5,$6)`, [memberId, kind, p.title, a.outcome, a.status ?? null, a.detail ?? null]);
  if (!pushConfigured()) {
    const a: Attempt = { outcome: "not-configured", detail: "VAPID keys not configured on server" };
    await log(a);
    return [a];
  }
  setup();
  const subs = await q<{ id: number; endpoint: string; p256dh: string; auth: string }>(
    `SELECT s.id, s.endpoint, s.p256dh, s.auth FROM push_subscriptions s JOIN accounts a ON a.id=s.account_id WHERE a.member_id=$1`,
    [memberId],
  );
  if (subs.length === 0) {
    const a: Attempt = { outcome: "no-subscription", detail: "Member has not enabled push on any device" };
    await log(a);
    return [a];
  }
  for (const s of subs) {
    let a: Attempt;
    try {
      const r = await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, JSON.stringify(p), { TTL: 60 * 60 * 24, urgency: "normal" });
      a = { outcome: "sent", status: r.statusCode, detail: "Accepted by push service (does not guarantee display)" };
    } catch (e) {
      const err = e as { statusCode?: number; body?: string; message?: string };
      if (err.statusCode === 404 || err.statusCode === 410) {
        await q(`DELETE FROM push_subscriptions WHERE id=$1`, [s.id]);
        a = { outcome: "expired", status: err.statusCode, detail: "Subscription no longer valid; removed" };
      } else a = { outcome: "failed", status: err.statusCode, detail: (err.body || err.message || "error").slice(0, 200) };
    }
    await log(a);
    out.push(a);
  }
  return out;
}
