export type MemberStatus = "active" | "expiring" | "expired" | "suspended" | "inactive";

/** Today's date in Singapore as YYYY-MM-DD. */
export function sgToday(d: Date = new Date()): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Singapore", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
}

export function daysBetween(fromISO: string, toISO: string): number {
  const a = Date.UTC(+fromISO.slice(0, 4), +fromISO.slice(5, 7) - 1, +fromISO.slice(8, 10));
  const b = Date.UTC(+toISO.slice(0, 4), +toISO.slice(5, 7) - 1, +toISO.slice(8, 10));
  return Math.round((b - a) / 86400000);
}

export function addDays(iso: string, n: number): string {
  const d = new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10) + n));
  return d.toISOString().slice(0, 10);
}

export const EXPIRING_SOON_DAYS = 30;

export function daysRemaining(expiry: string, today = sgToday()): number {
  return daysBetween(today, expiry);
}

export function computeStatus(
  m: { status: string; expiry_date: string; deactivated?: boolean },
  today = sgToday(),
): MemberStatus {
  if (m.deactivated) return "inactive";
  if (m.status === "suspended") return "suspended";
  const d = daysRemaining(m.expiry_date, today);
  if (d < 0) return "expired";
  if (d <= EXPIRING_SOON_DAYS) return "expiring";
  return "active";
}

export const STATUS_LABEL: Record<MemberStatus, string> = {
  active: "Active",
  expiring: "Expiring Soon",
  expired: "Expired",
  suspended: "Suspended",
  inactive: "Deactivated",
};

/** green / amber / red indicator for staff scanning */
export const STATUS_TONE: Record<MemberStatus, "green" | "amber" | "red"> = {
  active: "green",
  expiring: "amber",
  expired: "red",
  suspended: "red",
  inactive: "red",
};

export function fmtDate(iso: string): string {
  const d = new Date(iso.length === 10 ? iso + "T00:00:00Z" : iso);
  return new Intl.DateTimeFormat("en-SG", { timeZone: iso.length === 10 ? "UTC" : "Asia/Singapore", day: "numeric", month: "short", year: "numeric" }).format(d);
}

export function fmtDateTime(v: string | Date): string {
  const d = typeof v === "string" ? new Date(v) : v;
  return new Intl.DateTimeFormat("en-SG", { timeZone: "Asia/Singapore", day: "numeric", month: "short", year: "numeric", hour: "numeric", minute: "2-digit" }).format(d);
}
