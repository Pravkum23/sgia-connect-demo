// Placeholder categories – configurable to match SGIA's real membership structure later.
export const CATEGORIES = ["Ordinary Member", "Life Member", "Family Member", "Senior Member"];
