import { q } from "./db";

export async function audit(actor: { id?: number | null; name: string }, action: string, target?: string, detail?: string) {
  await q(`INSERT INTO audit_log(actor_id, actor, action, target, detail) VALUES ($1,$2,$3,$4,$5)`, [
    actor.id ?? null,
    actor.name,
    action,
    target ?? null,
    detail ? detail.slice(0, 500) : null,
  ]);
}
