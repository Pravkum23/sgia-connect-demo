import { q } from "./db";
import type { MemberRow } from "./members";

export interface AnnouncementRow {
  id: number; title: string; body: string; category: string; audience: string; state: string;
  publish_at: string | null; published_at: string | null; author: string; created_at: string; read: boolean; attachments: number;
}

const VISIBLE = `(a.state='published' OR (a.state='scheduled' AND a.publish_at <= now()))`;

export async function announcementsFor(m: MemberRow, limit = 50, category?: string): Promise<AnnouncementRow[]> {
  return q<AnnouncementRow>(
    `SELECT a.*, COALESCE(a.published_at, a.publish_at) AS published_at,
            (r.member_id IS NOT NULL) AS read,
            (SELECT count(*)::int FROM attachments t WHERE t.announcement_id=a.id) AS attachments
       FROM announcements a
       LEFT JOIN announcement_reads r ON r.announcement_id=a.id AND r.member_id=$1
      WHERE ${VISIBLE} AND (a.audience='all' OR a.audience=$2) AND ($4::text IS NULL OR a.category=$4)
      ORDER BY COALESCE(a.published_at, a.publish_at) DESC LIMIT $3`,
    [m.id, m.category, limit, category ?? null],
  );
}

export interface EventRow {
  id: number; title: string; starts_at: string; ends_at: string | null; venue: string; description: string; hue: number;
  capacity: number | null; registered: boolean; going: number;
}

export async function upcomingEvents(memberId: number | null, limit = 20): Promise<EventRow[]> {
  return q<EventRow>(
    `SELECT e.*, (SELECT count(*)::int FROM event_registrations r WHERE r.event_id=e.id) AS going,
            EXISTS(SELECT 1 FROM event_registrations r WHERE r.event_id=e.id AND r.member_id=$1) AS registered
       FROM events e WHERE e.published=true AND e.starts_at >= now() - interval '6 hours'
      ORDER BY e.starts_at ASC LIMIT $2`,
    [memberId, limit],
  );
}
export { VISIBLE as VISIBLE_SQL };
