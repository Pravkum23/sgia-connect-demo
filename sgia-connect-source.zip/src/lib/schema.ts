// Postgres schema. Runs identically on PGlite (local) and managed Postgres (Supabase/Neon).
export const SCHEMA_VERSION = 1;

export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS meta (key text PRIMARY KEY, value text NOT NULL);

CREATE TABLE IF NOT EXISTS members (
  id            serial PRIMARY KEY,
  membership_id text UNIQUE NOT NULL,
  name          text NOT NULL,
  category      text NOT NULL,
  status        text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  join_date     date NOT NULL,
  expiry_date   date NOT NULL,
  email         text NOT NULL,
  mobile        text NOT NULL,
  qr_token      text UNIQUE NOT NULL,
  avatar_hue    int  NOT NULL DEFAULT 210,
  family_head_id int REFERENCES members(id) ON DELETE SET NULL,
  deactivated   boolean NOT NULL DEFAULT false,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS accounts (
  id            serial PRIMARY KEY,
  login_id      text UNIQUE NOT NULL,
  password_hash text NOT NULL,
  role          text NOT NULL CHECK (role IN ('member','staff','admin','committee')),
  member_id     int REFERENCES members(id) ON DELETE CASCADE,
  display_name  text NOT NULL,
  active        boolean NOT NULL DEFAULT true,
  failed_attempts int NOT NULL DEFAULT 0,
  locked_until  timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sessions (
  id          serial PRIMARY KEY,
  token_hash  text UNIQUE NOT NULL,
  account_id  int NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  expires_at  timestamptz NOT NULL,
  user_agent  text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rate_limits (
  key          text PRIMARY KEY,
  count        int NOT NULL,
  window_start timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id         serial PRIMARY KEY,
  at         timestamptz NOT NULL DEFAULT now(),
  actor_id   int,
  actor      text NOT NULL,
  action     text NOT NULL,
  target     text,
  detail     text
);

CREATE TABLE IF NOT EXISTS verifications (
  id          serial PRIMARY KEY,
  at          timestamptz NOT NULL DEFAULT now(),
  staff_id    int NOT NULL REFERENCES accounts(id),
  member_id   int REFERENCES members(id),
  method      text NOT NULL,
  result      text NOT NULL,
  checked_in  boolean NOT NULL DEFAULT false,
  note        text
);

CREATE TABLE IF NOT EXISTS announcements (
  id           serial PRIMARY KEY,
  title        text NOT NULL,
  body         text NOT NULL,
  category     text NOT NULL DEFAULT 'Notices',
  audience     text NOT NULL DEFAULT 'all',
  state        text NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','scheduled','published','archived')),
  publish_at   timestamptz,
  published_at timestamptz,
  author       text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS attachments (
  id              serial PRIMARY KEY,
  announcement_id int NOT NULL REFERENCES announcements(id) ON DELETE CASCADE,
  filename        text NOT NULL,
  mime            text NOT NULL,
  size            int NOT NULL,
  data            bytea NOT NULL
);

CREATE TABLE IF NOT EXISTS announcement_reads (
  announcement_id int NOT NULL REFERENCES announcements(id) ON DELETE CASCADE,
  member_id       int NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  read_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (announcement_id, member_id)
);

CREATE TABLE IF NOT EXISTS events (
  id          serial PRIMARY KEY,
  title       text NOT NULL,
  starts_at   timestamptz NOT NULL,
  ends_at     timestamptz,
  venue       text NOT NULL,
  description text NOT NULL,
  hue         int NOT NULL DEFAULT 200,
  capacity    int,
  published   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS event_registrations (
  event_id   int NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  member_id  int NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (event_id, member_id)
);

CREATE TABLE IF NOT EXISTS facilities (
  id          serial PRIMARY KEY,
  name        text NOT NULL,
  kind        text NOT NULL,
  description text NOT NULL,
  hours       text,
  contact     text,
  placeholder boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS notifications (
  id         serial PRIMARY KEY,
  member_id  int NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  kind       text NOT NULL,
  title      text NOT NULL,
  body       text NOT NULL,
  url        text,
  read       boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id         serial PRIMARY KEY,
  account_id int NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  endpoint   text UNIQUE NOT NULL,
  p256dh     text NOT NULL,
  auth       text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS delivery_log (
  id          serial PRIMARY KEY,
  at          timestamptz NOT NULL DEFAULT now(),
  member_id   int,
  channel     text NOT NULL,
  kind        text NOT NULL,
  title       text NOT NULL,
  outcome     text NOT NULL,
  http_status int,
  detail      text
);

CREATE TABLE IF NOT EXISTS reminder_log (
  member_id   int NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  expiry_date date NOT NULL,
  threshold   int NOT NULL,
  sent_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (member_id, expiry_date, threshold)
);

CREATE TABLE IF NOT EXISTS renewal_requests (
  id         serial PRIMARY KEY,
  member_id  int NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  note       text,
  status     text NOT NULL DEFAULT 'requested',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS feedback (
  id         serial PRIMARY KEY,
  account_id int NOT NULL REFERENCES accounts(id),
  author     text NOT NULL,
  kind       text NOT NULL,
  page       text,
  device     text,
  message    text NOT NULL,
  resolved   boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sessions_exp ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_notif_member ON notifications(member_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_members_expiry ON members(expiry_date);
`;
