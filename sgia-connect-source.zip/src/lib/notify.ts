import { q } from "./db";
import { pushToMember, type Payload } from "./push";

/** In-app notice (always) + web push (if enabled) + simulated email fallback record. */
export async function notifyMember(memberId: number, kind: "announcement" | "expiry" | "event" | "admin" | "test", p: Payload, opts: { email?: boolean } = {}) {
  await q(`INSERT INTO notifications(member_id,kind,title,body,url) VALUES ($1,$2,$3,$4,$5)`, [memberId, kind, p.title, p.body, p.url ?? "/notifications"]);
  await q(`INSERT INTO delivery_log(member_id,channel,kind,title,outcome,detail) VALUES ($1,'in-app',$2,$3,'delivered','Visible in notification centre')`, [memberId, kind, p.title]);
  const attempts = await pushToMember(memberId, kind, p);
  if (opts.email) {
    await q(`INSERT INTO delivery_log(member_id,channel,kind,title,outcome,detail) VALUES ($1,'email',$2,$3,'not-sent','Demo: no email provider configured (fallback shown for design only)')`, [memberId, kind, p.title]);
  }
  return attempts;
}

export async function notifyMany(memberIds: number[], kind: Parameters<typeof notifyMember>[1], p: Payload, opts: { email?: boolean } = {}) {
  let sent = 0;
  for (const id of memberIds) {
    const a = await notifyMember(id, kind, p, opts);
    if (a.some((x) => x.outcome === "sent")) sent++;
  }
  return { recipients: memberIds.length, pushSent: sent };
}
