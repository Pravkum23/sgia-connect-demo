import { q } from "./db";

/** DB-backed fixed-window rate limiter (works across serverless instances). Returns true if allowed. */
export async function allow(key: string, limit: number, windowSec: number): Promise<boolean> {
  const rows = await q<{ count: number }>(
    `INSERT INTO rate_limits(key,count,window_start) VALUES ($1,1,now())
     ON CONFLICT (key) DO UPDATE SET
       count = CASE WHEN rate_limits.window_start < now() - make_interval(secs => $2) THEN 1 ELSE rate_limits.count + 1 END,
       window_start = CASE WHEN rate_limits.window_start < now() - make_interval(secs => $2) THEN now() ELSE rate_limits.window_start END
     RETURNING count`,
    [key, windowSec],
  );
  return rows[0].count <= limit;
}

export function clientIp(req: Request): string {
  const xf = req.headers.get("x-forwarded-for");
  return (xf?.split(",")[0] || req.headers.get("x-real-ip") || "unknown").trim();
}
