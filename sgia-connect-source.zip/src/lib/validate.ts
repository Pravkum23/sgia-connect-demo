import { z } from "zod";
import { CATEGORIES } from "./members";

export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Use the date format YYYY-MM-DD.").refine((s) => !Number.isNaN(Date.parse(s + "T00:00:00Z")), "Invalid date.");
export const syntheticEmail = z.string().email("Enter a valid email address.").max(120)
  .refine((e) => /@example\.(com|org|net)$/i.test(e), "Demo records must use a fictional @example.com email address. Do not enter real personal data.");
export const category = z.string().refine((c) => CATEGORIES.includes(c), "Unknown category.");
export const personName = z.string().trim().min(2, "Name is too short.").max(80).regex(/^[\p{L} .'-]+$/u, "Names may contain letters, spaces, . ' and - only.");
export const mobile = z.string().trim().max(40).regex(/^[0-9+() \-a-z]*$/i, "Invalid phone placeholder.").optional();

export function csvCell(v: unknown): string {
  let s = v == null ? "" : String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralise spreadsheet formula injection
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
