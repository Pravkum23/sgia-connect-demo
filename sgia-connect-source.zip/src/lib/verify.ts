import { one, q } from "./db";
import { computeStatus, daysRemaining, type MemberStatus } from "./status";
import type { MemberRow } from "./members";

export interface VerifyData {
  found: boolean;
  member?: {
    id: number; name: string; membership_id: string; category: string; join_date: string; expiry_date: string;
    lifetime: boolean; avatar_hue: number; status: MemberStatus; days: number;
  };
  lastCheckin: string | null;
  lastVerified: string | null;
  verificationId?: number;
}

export const TOKEN_RE = /^[A-Za-z0-9_-]{20,64}$/;
export const MID_RE = /^[A-Za-z0-9-]{3,30}$/;

/** Looks up a member by QR token or membership ID, logs the attempt (who/when/result) and returns CURRENT backend status. */
export async function verifyLookup(staffId: number, by: { token?: string; membershipId?: string }, method: "qr" | "manual" | "qr-link"): Promise<VerifyData> {
  let m: MemberRow | null = null;
  if (by.token && TOKEN_RE.test(by.token)) m = await one<MemberRow>(`SELECT * FROM members WHERE qr_token=$1`, [by.token]);
  else if (by.membershipId && MID_RE.test(by.membershipId)) m = await one<MemberRow>(`SELECT * FROM members WHERE membership_id=$1`, [by.membershipId.toUpperCase()]);
  if (!m) {
    const v = await one<{ id: number }>(`INSERT INTO verifications(staff_id,method,result,note) VALUES ($1,$2,'not_found',$3) RETURNING id`, [staffId, method, by.token ? "unknown token" : "unknown id"]);
    return { found: false, lastCheckin: null, lastVerified: null, verificationId: v!.id };
  }
  const status = computeStatus(m);
  const last = await one<{ checkin: string | null; verified: string | null }>(
    `SELECT max(at) FILTER (WHERE checked_in) AS checkin, max(at) AS verified FROM verifications WHERE member_id=$1`, [m.id]);
  const v = await one<{ id: number }>(`INSERT INTO verifications(staff_id,member_id,method,result) VALUES ($1,$2,$3,$4) RETURNING id`, [staffId, m.id, method, status]);
  return {
    found: true,
    verificationId: v!.id,
    lastCheckin: last?.checkin ? new Date(last.checkin).toISOString() : null,
    lastVerified: last?.verified ? new Date(last.verified).toISOString() : null,
    member: {
      id: m.id, name: m.name, membership_id: m.membership_id, category: m.category, join_date: m.join_date, expiry_date: m.expiry_date,
      lifetime: m.category === "Life Member" && m.expiry_date >= "2099-01-01", avatar_hue: m.avatar_hue, status, days: daysRemaining(m.expiry_date),
    },
  };
}

export async function recentVerifications(limit = 100) {
  return q<{ id: number; at: string; staff: string; member: string | null; membership_id: string | null; method: string; result: string; checked_in: boolean }>(
    `SELECT v.id, v.at, a.display_name AS staff, m.name AS member, m.membership_id, v.method, v.result, v.checked_in
       FROM verifications v JOIN accounts a ON a.id=v.staff_id LEFT JOIN members m ON m.id=v.member_id ORDER BY v.at DESC LIMIT $1`, [limit]);
}
