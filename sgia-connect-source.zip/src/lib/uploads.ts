import { q } from "./db";
import { HttpError } from "./http";

export const MAX_FILE = 2 * 1024 * 1024;
export const MAX_FILES = 4;

function sniff(b: Uint8Array): string | null {
  const s = (i: number, ...v: number[]) => v.every((x, k) => b[i + k] === x);
  if (s(0, 0x89, 0x50, 0x4e, 0x47)) return "image/png";
  if (s(0, 0xff, 0xd8, 0xff)) return "image/jpeg";
  if (s(0, 0x47, 0x49, 0x46, 0x38)) return "image/gif";
  if (s(0, 0x52, 0x49, 0x46, 0x46) && s(8, 0x57, 0x45, 0x42, 0x50)) return "image/webp";
  if (s(0, 0x25, 0x50, 0x44, 0x46)) return "application/pdf";
  return null;
}

/** Validates by file CONTENT (magic bytes), not by the client-supplied type or extension. Only PNG/JPEG/GIF/WebP/PDF allowed. */
export async function saveFiles(announcementId: number, files: File[]) {
  const have = (await q<{ n: number }>(`SELECT count(*)::int AS n FROM attachments WHERE announcement_id=$1`, [announcementId]))[0].n;
  if (have + files.length > MAX_FILES) throw new HttpError(400, `At most ${MAX_FILES} attachments per announcement.`);
  for (const f of files) {
    if (f.size === 0) continue;
    if (f.size > MAX_FILE) throw new HttpError(400, `${f.name} is larger than 2 MB.`);
    const buf = new Uint8Array(await f.arrayBuffer());
    const mime = sniff(buf);
    if (!mime) throw new HttpError(400, `${f.name}: only PNG, JPEG, GIF, WebP images and PDF documents are allowed.`);
    const ext = { "image/png": "png", "image/jpeg": "jpg", "image/gif": "gif", "image/webp": "webp", "application/pdf": "pdf" }[mime];
    const base = f.name.replace(/\.[^.]*$/, "").replace(/[^\w\- ]/g, "_").slice(0, 60) || "attachment";
    await q(`INSERT INTO attachments(announcement_id,filename,mime,size,data) VALUES ($1,$2,$3,$4,$5)`, [announcementId, `${base}.${ext}`, mime, buf.length, Buffer.from(buf)]);
  }
}
