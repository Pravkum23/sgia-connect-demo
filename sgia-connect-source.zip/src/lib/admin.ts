import { one, q } from "./db";
import { newToken } from "./tokens";
import { addDays, daysBetween, sgToday } from "./status";
import { notifyMember, notifyMany } from "./notify";
import { audit } from "./audit";

export async function nextMembershipId(): Promise<string> {
  const r = await one<{ n: number }>(`SELECT COALESCE(max(substring(membership_id from 'SGIA-DEMO-(\\d+)$')::int),0) AS n FROM members`);
  return `SGIA-DEMO-${String((r?.n ?? 0) + 1).padStart(4, "0")}`;
}

export interface NewMember { name: string; category: string; email: string; mobile?: string; join_date: string; expiry_date: string }

export async function createMember(m: NewMember): Promise<{ id: number; membership_id: string }> {
  // Retry on the (unlikely) race of two admins generating the same ID.
  for (let i = 0; i < 3; i++) {
    const mid = await nextMembershipId();
    try {
      const r = await one<{ id: number }>(
        `INSERT INTO members(membership_id,name,category,join_date,expiry_date,email,mobile,qr_token,avatar_hue) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
        [mid, m.name, m.category, m.join_date, m.expiry_date, m.email, m.mobile || "+65 0000 0000 (fictional)", newToken(), Math.floor(Math.random() * 360)],
      );
      return { id: r!.id, membership_id: mid };
    } catch (e) {
      if (i === 2 || !String(e).includes("unique")) throw e;
    }
  }
  throw new Error("unreachable");
}

export async function audienceMembers(audience: string): Promise<number[]> {
  const rows = await q<{ id: number }>(
    `SELECT id FROM members WHERE deactivated=false AND ($1='all' OR category=$1)`, [audience]);
  return rows.map((r) => r.id);
}

export async function publishAnnouncement(id: number, actor: { id: number | null; name: string }) {
  const a = await one<{ id: number; title: string; body: string; audience: string; state: string }>(`SELECT id,title,body,audience,state FROM announcements WHERE id=$1`, [id]);
  if (!a) return null;
  await q(`UPDATE announcements SET state='published', published_at=now() WHERE id=$1`, [id]);
  const ids = await audienceMembers(a.audience);
  const res = await notifyMany(ids, "announcement", { title: a.title, body: a.body.slice(0, 140), url: `/announcements/${a.id}`, tag: `ann-${a.id}` });
  await audit(actor, "announcement.published", `#${id}`, `${res.recipients} recipients, ${res.pushSent} push accepted`);
  return res;
}

/** Publishes scheduled announcements whose time has arrived, and notifies audiences. */
export async function processScheduled() {
  const due = await q<{ id: number }>(`SELECT id FROM announcements WHERE state='scheduled' AND publish_at <= now() ORDER BY publish_at`);
  for (const d of due) await publishAnnouncement(d.id, { id: null, name: "scheduler" });
  return due.length;
}

const THRESHOLDS = [30, 15, 7, 0, -1];

/** Sends renewal reminders independent of members opening the app. Idempotent per (member, expiry date, threshold). */
export async function runExpiryCheck(actor: { id: number | null; name: string }) {
  const today = sgToday();
  const rows = await q<{ id: number; name: string; expiry_date: string }>(
    `SELECT id,name,expiry_date FROM members
      WHERE deactivated=false AND status='active' AND category <> 'Life Member' AND expiry_date BETWEEN $1 AND $2`,
    [addDays(today, -7), addDays(today, 30)],
  );
  let sent = 0, skipped = 0;
  const detail: string[] = [];
  for (const m of rows) {
    const days = daysBetween(today, m.expiry_date);
    const applicable = THRESHOLDS.filter((t) => t >= days);
    if (applicable.length === 0) continue;
    const t = Math.min(...applicable);
    const already = await q(`SELECT 1 FROM reminder_log WHERE member_id=$1 AND expiry_date=$2 AND threshold=$3`, [m.id, m.expiry_date, t]);
    if (already.length) { skipped++; continue; }
    // Mark this and all larger thresholds as handled so a late first run doesn't send a burst.
    for (const x of THRESHOLDS.filter((x) => x >= t)) await q(`INSERT INTO reminder_log(member_id,expiry_date,threshold) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`, [m.id, m.expiry_date, x]);
    const title = days < 0 ? "Your SGIA membership has expired" : days === 0 ? "Your SGIA membership expires today" : `Your SGIA membership expires in ${days} day${days === 1 ? "" : "s"}`;
    await notifyMember(m.id, "expiry", { title, body: "Open SGIA Connect to request renewal (demonstration – no payment is taken).", url: "/renewal", tag: "expiry" }, { email: true });
    sent++;
    detail.push(`${m.name}: ${days}d`);
  }
  const sched = await processScheduled();
  await audit(actor, "expiry-check.run", undefined, `checked ${rows.length}, sent ${sent}, already-sent ${skipped}, scheduled published ${sched}`);
  return { checked: rows.length, sent, skipped, scheduledPublished: sched, detail };
}

export async function dashboardStats() {
  const today = sgToday();
  const s = await one<Record<string, number>>(
    `SELECT
       (SELECT count(*)::int FROM members WHERE deactivated=false) AS total,
       (SELECT count(*)::int FROM members WHERE deactivated=false AND status='active' AND expiry_date >= $1) AS active,
       (SELECT count(*)::int FROM members WHERE deactivated=false AND expiry_date < $1) AS expired,
       (SELECT count(*)::int FROM members WHERE deactivated=false AND status='suspended') AS suspended,
       (SELECT count(*)::int FROM members WHERE deactivated=false AND status='active' AND expiry_date BETWEEN $1 AND $2) AS renewals,
       (SELECT count(*)::int FROM announcements WHERE state='published') AS announcements,
       (SELECT count(*)::int FROM events WHERE published=true AND starts_at >= now()) AS events,
       (SELECT count(*)::int FROM delivery_log WHERE channel='webpush') AS push_attempts,
       (SELECT count(*)::int FROM verifications WHERE checked_in) AS checkins,
       (SELECT count(*)::int FROM verifications) AS verifications`,
    [today, addDays(today, 30)],
  );
  return s!;
}
