import { headers } from "next/headers";
import QRCode from "qrcode";
import { one, q } from "./db";
import { computeStatus, daysRemaining, type MemberStatus } from "./status";

export interface MemberRow {
  id: number; membership_id: string; name: string; category: string; status: "active" | "suspended";
  join_date: string; expiry_date: string; email: string; mobile: string; qr_token: string;
  avatar_hue: number; family_head_id: number | null; deactivated: boolean;
}
export interface MemberView extends MemberRow { computed: MemberStatus; days: number; lifetime: boolean }

export function view(m: MemberRow): MemberView {
  return { ...m, computed: computeStatus(m), days: daysRemaining(m.expiry_date), lifetime: m.category === "Life Member" && m.expiry_date >= "2099-01-01" };
}

export async function getMember(id: number): Promise<MemberView | null> {
  const m = await one<MemberRow>(`SELECT * FROM members WHERE id=$1`, [id]);
  return m ? view(m) : null;
}

export async function getFamily(m: MemberRow) {
  const headId = m.family_head_id ?? m.id;
  return q<{ name: string; membership_id: string; category: string }>(
    `SELECT name, membership_id, category FROM members WHERE (id=$1 OR family_head_id=$1) AND id<>$2 AND deactivated=false ORDER BY id`,
    [headId, m.id],
  );
}

export async function appBase(): Promise<string> {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  const h = await headers();
  const host = h.get("x-forwarded-host") || h.get("host") || "localhost:3000";
  const proto = h.get("x-forwarded-proto") || (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

/** The QR carries ONLY an opaque random token inside a verification URL – never member details. */
export async function qrPayload(token: string) {
  return `${await appBase()}/verify/${token}`;
}
export async function qrSvg(token: string) {
  return QRCode.toString(await qrPayload(token), { type: "svg", margin: 1, errorCorrectionLevel: "M", color: { dark: "#001f3d", light: "#ffffff" } });
}

export { CATEGORIES } from "./members-constants";
