import { cache } from "react";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { one, q } from "./db";
import { newToken, sha256 } from "./tokens";
import { allow, clientIp } from "./rate";
import { audit } from "./audit";

export type Role = "member" | "staff" | "admin" | "committee";
export interface Session {
  accountId: number;
  loginId: string;
  role: Role;
  name: string;
  memberId: number | null;
}

export const COOKIE = "sgia_session";
const LOCK_AFTER = 5;
const LOCK_MINUTES = 15;
// Valid hash used to equalise timing when the account does not exist.
const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 10);

export const hashPassword = (pw: string) => bcrypt.hash(pw, 10);

export function passwordProblem(pw: string, loginId: string): string | null {
  if (pw.length < 10) return "Password must be at least 10 characters.";
  if (pw.length > 128) return "Password is too long.";
  if (pw.toLowerCase().includes(loginId.toLowerCase())) return "Password must not contain your Membership ID.";
  if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return "Password must include letters and numbers.";
  return null;
}

function sessionDays(role: Role) {
  return role === "member" || role === "committee" ? 30 : 0.5; // staff & admin: 12 hours
}

function secureCookies() {
  return (process.env.APP_URL || "").startsWith("https://");
}

export async function startSession(accountId: number, role: Role, ua: string | null) {
  const token = newToken();
  const days = sessionDays(role);
  await q(
    `INSERT INTO sessions(token_hash, account_id, expires_at, user_agent) VALUES ($1,$2, now() + make_interval(secs => $3), $4)`,
    [sha256(token), accountId, Math.round(days * 86400), ua?.slice(0, 200) ?? null],
  );
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    secure: secureCookies(),
    sameSite: "lax",
    path: "/",
    maxAge: Math.round(days * 86400),
  });
}

export type LoginResult = { ok: true; role: Role } | { ok: false; status: number; error: string };

export async function login(loginIdRaw: string, password: string, req: Request): Promise<LoginResult> {
  const loginId = loginIdRaw.trim().toUpperCase();
  const ip = clientIp(req);
  if (!(await allow(`login-ip:${ip}`, 30, 900))) {
    return { ok: false, status: 429, error: "Too many sign-in attempts from this device. Please wait 15 minutes and try again." };
  }
  const acc = await one<{
    id: number; password_hash: string; role: Role; active: boolean; failed_attempts: number; locked_until: string | null; display_name: string; deactivated: boolean | null;
  }>(
    `SELECT a.id, a.password_hash, a.role, a.active, a.failed_attempts, a.locked_until, a.display_name, m.deactivated
       FROM accounts a LEFT JOIN members m ON m.id = a.member_id WHERE a.login_id = $1`,
    [loginId],
  );
  if (acc?.locked_until && new Date(acc.locked_until) > new Date()) {
    await bcrypt.compare(password, DUMMY_HASH);
    return { ok: false, status: 429, error: `This account is temporarily locked after repeated failed attempts. Try again in ${LOCK_MINUTES} minutes.` };
  }
  const valid = await bcrypt.compare(password, acc?.password_hash ?? DUMMY_HASH);
  if (!acc || !valid || !acc.active || acc.deactivated) {
    if (acc) {
      const n = acc.failed_attempts + 1;
      if (n >= LOCK_AFTER) {
        await q(`UPDATE accounts SET failed_attempts=0, locked_until = now() + make_interval(mins => $2) WHERE id=$1`, [acc.id, LOCK_MINUTES]);
        await audit({ name: loginId }, "login.locked", loginId);
      } else {
        await q(`UPDATE accounts SET failed_attempts=$2 WHERE id=$1`, [acc.id, n]);
      }
    }
    await audit({ name: loginId }, "login.failed", loginId);
    return { ok: false, status: 401, error: "Membership ID or password is incorrect." };
  }
  await q(`UPDATE accounts SET failed_attempts=0, locked_until=NULL WHERE id=$1`, [acc.id]);
  await startSession(acc.id, acc.role, req.headers.get("user-agent"));
  await audit({ id: acc.id, name: loginId }, "login.ok", loginId);
  return { ok: true, role: acc.role };
}

export const currentSession = cache(async (): Promise<Session | null> => {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const r = await one<{ id: number; login_id: string; role: Role; display_name: string; member_id: number | null }>(
    `SELECT a.id, a.login_id, a.role, a.display_name, a.member_id
       FROM sessions s JOIN accounts a ON a.id = s.account_id
      WHERE s.token_hash = $1 AND s.expires_at > now() AND a.active = true`,
    [sha256(token)],
  );
  if (!r) return null;
  return { accountId: r.id, loginId: r.login_id, role: r.role, name: r.display_name, memberId: r.member_id };
});

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE)?.value;
  if (token) await q(`DELETE FROM sessions WHERE token_hash=$1`, [sha256(token)]);
  jar.delete(COOKIE);
}

export const STAFF_ROLES: Role[] = ["staff", "admin"];
export const ADMIN_ROLES: Role[] = ["admin"];
export const ADMIN_VIEW_ROLES: Role[] = ["admin", "committee"];
