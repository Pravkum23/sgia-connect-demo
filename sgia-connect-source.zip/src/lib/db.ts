import path from "node:path";
import { SCHEMA_SQL } from "./schema";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Row = Record<string, any>;
export type Q = <T = Row>(sql: string, params?: unknown[]) => Promise<T[]>;

interface Db {
  q: Q;
  exec: (sql: string) => Promise<void>;
  tx: <T>(fn: (q: Q) => Promise<T>) => Promise<T>;
  kind: "pglite" | "postgres";
}

const DATE_OID = 1082;
const g = globalThis as unknown as { __sgiaDb?: Promise<Db> };

async function open(): Promise<Db> {
  const url = process.env.DATABASE_URL;
  if (url) {
    const pg = await import("pg");
    pg.types.setTypeParser(DATE_OID, (v: string) => v);
    pg.types.setTypeParser(20, (v: string) => parseInt(v, 10)); // bigint -> number
    const ssl = /localhost|127\.0\.0\.1/.test(url) ? undefined : { rejectUnauthorized: false };
    const pool = new pg.Pool({ connectionString: url, ssl, max: 5 });
    await pool.query(SCHEMA_SQL);
    const q: Q = async (sql, params) => (await pool.query(sql, params as unknown[])).rows;
    return {
      kind: "postgres",
      q,
      exec: async (sql) => void (await pool.query(sql)),
      tx: async (fn) => {
        const c = await pool.connect();
        try {
          await c.query("BEGIN");
          const r = await fn(async (sql, params) => (await c.query(sql, params as unknown[])).rows);
          await c.query("COMMIT");
          return r;
        } catch (e) {
          await c.query("ROLLBACK");
          throw e;
        } finally {
          c.release();
        }
      },
    };
  }
  const { PGlite } = await import("@electric-sql/pglite");
  const dir = process.env.PGLITE_DIR || path.join(process.cwd(), "data", "pglite");
  const lite = new PGlite(dir, { parsers: { [DATE_OID]: (v: string) => v, 20: (v: string) => parseInt(v, 10) } });
  await lite.waitReady;
  await lite.exec(SCHEMA_SQL);
  const q: Q = async (sql, params) => (await lite.query(sql, params as unknown[])).rows as never;
  return {
    kind: "pglite",
    q,
    exec: async (sql) => void (await lite.exec(sql)),
    tx: (fn) => lite.transaction(async (t) => fn(async (sql, params) => (await t.query(sql, params as unknown[])).rows as never)),
  };
}

export function db(): Promise<Db> {
  if (!g.__sgiaDb) g.__sgiaDb = open();
  return g.__sgiaDb;
}

export async function q<T = Row>(sql: string, params?: unknown[]): Promise<T[]> {
  return (await db()).q<T>(sql, params);
}
export async function one<T = Row>(sql: string, params?: unknown[]): Promise<T | null> {
  const rows = await q<T>(sql, params);
  return rows[0] ?? null;
}
export async function tx<T>(fn: (q: Q) => Promise<T>): Promise<T> {
  return (await db()).tx(fn);
}

/** Danger: wipes every table and recreates the schema. Used only by the seed script with --reset. */
export async function resetDb(): Promise<void> {
  const d = await db();
  await d.exec("DROP SCHEMA public CASCADE; CREATE SCHEMA public;");
  await d.exec(SCHEMA_SQL);
}
export async function dbKind() {
  return (await db()).kind;
}
