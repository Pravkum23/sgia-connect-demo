import { redirect } from "next/navigation";
import { currentSession, type Role, type Session } from "./auth";

/** Server-component guard: redirects unauthenticated users to /login and others to their own home. */
export async function requirePage(roles?: Role[]): Promise<Session> {
  const s = await currentSession();
  if (!s) redirect("/login");
  if (roles && !roles.includes(s.role)) redirect(s.role === "staff" ? "/staff/scan" : s.role === "admin" ? "/admin" : "/");
  return s;
}
