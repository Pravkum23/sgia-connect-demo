import type { Role } from "./auth";
export interface NavItem { href: string; label: string; icon: string }
export interface NavSet { primary: NavItem[]; extra: NavItem[]; home: string }

const memberPrimary: NavItem[] = [
  { href: "/", label: "Home", icon: "home" },
  { href: "/membership", label: "Membership", icon: "card" },
  { href: "/events", label: "Events", icon: "calendar" },
  { href: "/notifications", label: "Notifications", icon: "bell" },
  { href: "/profile", label: "Profile", icon: "user" },
];
const memberExtra: NavItem[] = [
  { href: "/announcements", label: "Announcements", icon: "megaphone" },
  { href: "/facilities", label: "Facilities", icon: "building" },
];

export function navFor(role: Role): NavSet {
  switch (role) {
    case "staff":
      return {
        home: "/staff/scan",
        primary: [
          { href: "/staff/scan", label: "Scan", icon: "scan" },
          { href: "/staff/history", label: "Check-ins", icon: "list" },
          { href: "/profile", label: "Profile", icon: "user" },
        ],
        extra: [],
      };
    case "admin":
      return {
        home: "/admin",
        primary: [
          { href: "/admin", label: "Dashboard", icon: "chart" },
          { href: "/admin/members", label: "Members", icon: "users" },
          { href: "/admin/announcements", label: "Announce", icon: "megaphone" },
          { href: "/admin/events", label: "Events", icon: "calendar" },
          { href: "/profile", label: "Profile", icon: "user" },
        ],
        extra: [
          { href: "/admin/notifications", label: "Notification log", icon: "bell" },
          { href: "/admin/audit", label: "Audit log", icon: "shield" },
          { href: "/admin/feedback", label: "Feedback", icon: "chat" },
          { href: "/staff/scan", label: "Scanner", icon: "scan" },
        ],
      };
    case "committee":
      return {
        home: "/",
        primary: memberPrimary,
        extra: [...memberExtra, { href: "/admin", label: "Admin dashboard (view)", icon: "chart" }, { href: "/feedback", label: "Send feedback", icon: "chat" }],
      };
    default:
      return { home: "/", primary: memberPrimary, extra: memberExtra };
  }
}
