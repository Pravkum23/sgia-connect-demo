import { randomBytes, createHash, randomInt } from "node:crypto";

/** 256-bit random, URL-safe, non-guessable token */
export function newToken(bytes = 32): string {
  return randomBytes(bytes).toString("base64url");
}
export function sha256(s: string): string {
  return createHash("sha256").update(s).digest("hex");
}
/** Readable random password for demo credentials (no ambiguous chars). */
export function newPassword(len = 12): string {
  const alphabet = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < len; i++) out += alphabet[randomInt(alphabet.length)];
  return out;
}
